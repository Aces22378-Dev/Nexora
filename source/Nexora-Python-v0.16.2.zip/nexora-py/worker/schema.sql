CREATE TABLE IF NOT EXISTS users (name TEXT PRIMARY KEY COLLATE NOCASE, salt TEXT, hash TEXT, created INTEGER, avatar TEXT,
                                  balance INTEGER DEFAULT 0, last_daily INTEGER DEFAULT 0, algo TEXT);
CREATE TABLE IF NOT EXISTS tokens (hash TEXT PRIMARY KEY, user TEXT COLLATE NOCASE, expires INTEGER);
CREATE TABLE IF NOT EXISTS games (id TEXT PRIMARY KEY, owner TEXT COLLATE NOCASE, name TEXT, description TEXT, emoji TEXT,
                                  thumb TEXT, data TEXT, plays INTEGER DEFAULT 0, created INTEGER, updated INTEGER);
CREATE TABLE IF NOT EXISTS likes (game TEXT, user TEXT COLLATE NOCASE, PRIMARY KEY (game, user));
CREATE TABLE IF NOT EXISTS items (id TEXT PRIMARY KEY, kind TEXT, game TEXT, name TEXT, description TEXT, price INTEGER,
                                  color TEXT, creator TEXT COLLATE NOCASE, created INTEGER, payload TEXT,
                                  status TEXT DEFAULT 'approved');
CREATE TABLE IF NOT EXISTS purchases (user TEXT COLLATE NOCASE, item TEXT, price INTEGER, at INTEGER,
                                      PRIMARY KEY (user, item));
CREATE TABLE IF NOT EXISTS limits (key TEXT PRIMARY KEY, n INTEGER, reset INTEGER);
CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, game TEXT, name TEXT, players INTEGER DEFAULT 0, updated INTEGER);
CREATE TABLE IF NOT EXISTS room_counters (game TEXT PRIMARY KEY, n INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS plays (game TEXT, user TEXT COLLATE NOCASE, at INTEGER, PRIMARY KEY (game, user));
CREATE INDEX IF NOT EXISTS idx_rooms_game ON rooms (game);
CREATE INDEX IF NOT EXISTS idx_items_kind ON items (kind, status);
CREATE INDEX IF NOT EXISTS idx_tokens_exp ON tokens (expires);
CREATE TABLE IF NOT EXISTS bans (user TEXT PRIMARY KEY COLLATE NOCASE, until INTEGER, reason TEXT, by TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS mutes (user TEXT PRIMARY KEY COLLATE NOCASE, until INTEGER, reason TEXT, by TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS modlog (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, staff TEXT, action TEXT, target TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS notice (id INTEGER PRIMARY KEY CHECK (id = 1), text TEXT, by TEXT, at INTEGER);
