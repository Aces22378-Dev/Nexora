# Nexora server on Cloudflare (Workers + D1 + Durable Objects)

The same server as `nexora_server.py`, same API, so Nexora and Nexora Studio work with it unchanged.
Accounts, Nexei, shop, games and likes live in **D1**; each live game room is a **Durable Object**. No sleeping, no disk to wipe.

## Deploy (about 10 minutes, free Cloudflare account)
1. Install Node.js LTS from https://nodejs.org
2. In PowerShell, in this `worker` folder:
   ```
   npm install
   npx wrangler login
   npx wrangler d1 create nexora
   ```
   Copy the `database_id` it prints into `wrangler.toml` (replace `PUT-YOUR-D1-DATABASE-ID-HERE`).
3. Create the tables, set your staff secret, deploy:
   ```
   npx wrangler d1 execute nexora --remote --file=schema.sql
   npx wrangler secret put NEXORA_STAFF_CODE
   npx wrangler deploy
   ```
   (`NEXORA_STAFF_CODE` = a long secret; without it nobody can register the staff names in `wrangler.toml`.)
4. It prints `https://nexora-server.<your-name>.workers.dev`. In Nexora click **Server...** and paste that address.

## Staff accounts
Names in `NEXORA_STAFF` (wrangler.toml, default `Aces22378,Ivy`) have unlimited Nexei. To create them, set the same secret on your PC and sign up:
`$env:NEXORA_STAFF_CODE="your-secret"; py main.py`

## Moving the accounts you already have
Accounts made by the Python server or in local mode use scrypt passwords. The Worker accepts them and upgrades each to a faster hash the first time that person logs in (this one login is slow: see "Limits"). To copy local-mode accounts into D1, set these on your PC, then run the import script from `nexora-py`:
```
$env:CF_ACCOUNT_ID="..."; $env:CF_D1_DATABASE_ID="..."; $env:CF_API_TOKEN="..."   # token with D1 Edit permission
py import_local_accounts.py
```

## Limits (be aware)
- **CPU time.** The free Workers plan gives 10 ms of CPU per request. Hashing a password (PBKDF2, 100,000 rounds) may go over that on login/sign-up; if you see "Error 1102 / exceeded CPU", you need the Workers Paid plan (about $5 a month). The one-time scrypt check for imported accounts is much heavier and will not fit the free plan.
- **Durable Objects free tier.** Each message from a player counts toward 100,000 free requests a day (billed 20 messages = 1 request). A full room sends ~15 messages per second per player, so a busy server can use up the free allowance in a few hours of play. Past it, rooms stop working until the next day, or you pay.
- **Game size.** A published game must be under about 1.8 MB (D1 row limit).
- **Rate limits** use D1 and count each check as a database write.

## Local testing
```
npm install
npm run db:local
npm run dev        # http://localhost:8787, staff code "dev-code"
```
In Nexora: Server... > `127.0.0.1:8787`.
