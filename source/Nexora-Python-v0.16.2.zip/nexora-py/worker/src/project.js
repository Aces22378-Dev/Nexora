// Port of project.py's clean_project: checks a game a creator publishes. Keep the two in step.
const FORMAT = 1, MAX_PARTS = 2000, MAX_SCRIPTS = 100, MAX_NAME = 40, MAX_DEVS = 10, MAX_THUMBS = 3, MAX_THUMB_CHARS = 300000;
const KINDS = ["part", "coin", "spawn", "goal"], SHAPES = ["box", "sphere", "cylinder", "cone", "wedge"];
const HEX = /^#[0-9a-fA-F]{6}$/, ID = /^[A-Za-z0-9_\-]{1,24}$/, USER = /^[A-Za-z0-9_]{3,20}$/, B64 = /^[A-Za-z0-9+/=]*$/;
const LIMIT = 100000;
const DEFAULT_SKY = "#7fb8ff";
const WORLD = { fog: [0, 0, 1], gravity: [1, 0.1, 3], walk_speed: [9, 2, 40], jump_height: [2.2, 0.5, 8] };
const KIND_DEFAULTS = {
  part: { name: "Part", shape: "box", size: [4, 1, 4], color: "#a3a3a3", collide: true },
  coin: { name: "Coin", shape: "sphere", size: [1, 1, 0.25], color: "#facc15", collide: false },
  spawn: { name: "Spawn", shape: "box", size: [4, 0.4, 4], color: "#22d3ee", collide: true },
  goal: { name: "Goal", shape: "box", size: [3, 0.3, 3], color: "#facc15", collide: true },
};
const cps = (s) => Array.from(s);
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const r3 = (x) => Math.round(x * 1000) / 1000;
const pyMod = (a, n) => ((a % n) + n) % n;

function num(v, what, lo = -LIMIT, hi = LIMIT) {
  if (typeof v !== "number" || !Number.isFinite(v)) throw new Error(`${what} must be a number`);
  return Math.min(hi, Math.max(lo, v));
}
function vec(v, what, lo = -LIMIT, hi = LIMIT) {
  if (!Array.isArray(v) || v.length !== 3) throw new Error(`${what} must be three numbers`);
  return v.map((c) => r3(num(c, what, lo, hi)));
}
function text(v, what, def = "", limit = MAX_NAME) {
  if (v === null || v === undefined) return def;
  if (typeof v !== "string") throw new Error(`${what} must be text`);
  return cps(v.trim()).slice(0, limit).join("") || def;
}
export function cleanPart(d) {
  if (!isObj(d)) throw new Error("a part is malformed");
  const kind = d.kind ?? "part";
  if (!KINDS.includes(kind)) throw new Error(`unknown part kind '${kind}'`);
  const base = KIND_DEFAULTS[kind];
  if (typeof d.id !== "string" || !ID.test(d.id)) throw new Error("a part has a bad id");
  const shape = d.shape ?? base.shape;
  if (!SHAPES.includes(shape)) throw new Error(`unknown shape '${shape}'`);
  const color = d.color ?? base.color;
  if (typeof color !== "string" || !HEX.test(color)) throw new Error("a part has a bad color");
  const out = {
    id: d.id, name: text(d.name, "name", base.name), kind, shape,
    pos: vec(d.pos ?? [0, 0, 0], "position"), size: vec(d.size ?? base.size, "size", 0.05, 10000),
    rot_y: r3(pyMod(num(d.rot_y ?? 0, "rotation"), 360)), color: color.toLowerCase(),
    collide: "collide" in d ? Boolean(d.collide) : base.collide, visible: "visible" in d ? Boolean(d.visible) : true,
  };
  if (kind === "coin") out.value = Math.trunc(num(d.value ?? 1, "coin value", 1, 1000));
  return out;
}
export function cleanScript(d) {
  if (!isObj(d)) throw new Error("a script is malformed");
  if (typeof d.id !== "string" || !ID.test(d.id)) throw new Error("a script has a bad id");
  const src = d.source ?? "";
  if (typeof src !== "string") throw new Error("a script's code must be text");
  const target = d.target ?? null;
  if (target !== null && (typeof target !== "string" || !ID.test(target))) throw new Error("a script has a bad target");
  return { id: d.id, name: text(d.name, "name", "Script"), target, source: cps(src).slice(0, 60000).join("") };
}
export function cleanProject(d) {
  if (!isObj(d)) throw new Error("This isn't a Nexora game file.");
  const fmt = d.format ?? FORMAT;
  if (!Number.isInteger(fmt) || fmt > FORMAT) throw new Error("This game was made with a newer version of Nexora Studio. Update Nexora to open it.");
  const partsIn = d.parts ?? [], scriptsIn = d.scripts ?? [];
  if (!Array.isArray(partsIn) || !Array.isArray(scriptsIn)) throw new Error("This game file is damaged.");
  if (partsIn.length > MAX_PARTS) throw new Error(`Too many parts (the limit is ${MAX_PARTS}).`);
  if (scriptsIn.length > MAX_SCRIPTS) throw new Error(`Too many scripts (the limit is ${MAX_SCRIPTS}).`);
  const parts = [], seen = new Set();
  for (const p of partsIn) { const c = cleanPart(p); if (seen.has(c.id)) throw new Error("Two parts share the same id."); seen.add(c.id); parts.push(c); }
  const scripts = [], sseen = new Set();
  for (const s of scriptsIn) { const c = cleanScript(s); if (sseen.has(c.id)) throw new Error("Two scripts share the same id."); sseen.add(c.id); scripts.push(c); }
  if (typeof d.id !== "string" || !ID.test(d.id)) throw new Error("This game has no valid id.");
  const sky = d.sky ?? DEFAULT_SKY, thumb = d.thumb ?? "#4f46e5";
  if (typeof sky !== "string" || !HEX.test(sky) || typeof thumb !== "string" || !HEX.test(thumb)) throw new Error("This game has a bad color.");
  const emoji = d.emoji ?? "🧱";
  const thumbsIn = d.thumbs ?? [];
  if (!Array.isArray(thumbsIn) || thumbsIn.length > MAX_THUMBS) throw new Error(`A game can have at most ${MAX_THUMBS} thumbnails.`);
  const thumbs = [];
  for (const t of thumbsIn) {
    if (typeof t !== "string" || t.length > MAX_THUMB_CHARS || !B64.test(t)) throw new Error("A thumbnail is not a valid image.");
    thumbs.push(t);
  }
  const owner = text(d.owner, "owner", "", 20);
  const devsIn = d.devs ?? [];
  if (!Array.isArray(devsIn) || devsIn.length > MAX_DEVS) throw new Error(`A game can have at most ${MAX_DEVS} developers.`);
  const devs = [];
  for (const n of devsIn) {
    if (typeof n !== "string" || !USER.test(n)) throw new Error("A developer name is invalid.");
    if (n.toLowerCase() !== owner.toLowerCase() && !devs.some((x) => x.toLowerCase() === n.toLowerCase())) devs.push(n);
  }
  return {
    format: FORMAT, id: d.id, name: text(d.name, "name", "Untitled game"), desc: text(d.desc, "description", "", 140),
    owner, devs, thumbs, author: owner || text(d.author, "author", "", 20),
    emoji: typeof emoji === "string" && emoji ? cps(emoji).slice(0, 4).join("") : "🧱",
    sky: sky.toLowerCase(), thumb: thumb.toLowerCase(), kill_y: r3(num(d.kill_y ?? -50, "kill height", -10000, 10000)),
    world: cleanWorld(d.world),
    parts, scripts, modified: Math.trunc(num(d.modified ?? 0, "time", 0, 4e12)),
  };
}
function cleanWorld(d) {
  d = isObj(d) ? d : {};
  const out = {};
  for (const [k, [dv, lo, hi]] of Object.entries(WORLD)) out[k] = r3(num(d[k] ?? dv, k, lo, hi));
  out.fog_color = typeof d.fog_color === "string" && HEX.test(d.fog_color) ? d.fog_color.toLowerCase() : null;
  return out;
}
export function isDev(game, username) {
  const n = (username || "").toLowerCase();
  return Boolean(n) && (n === (game.owner || "").toLowerCase() || (game.devs || []).some((d) => d.toLowerCase() === n));
}
export const ID_RE = ID;
