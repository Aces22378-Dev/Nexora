// One live game room = one Durable Object. Same messages as the Python server (join, state, chat, bye).
import { cleanChat, coord, now } from "./util.js";

const PROTOCOL = 1, TICK_MS = 66, HEARTBEAT_MS = 20000, EMPTY_MS = 30000;
const dec = (b64) => decodeURIComponent(escape(atob(b64)));

export class Room {
  constructor(state, env) {
    this.state = state; this.env = env;
    this.players = new Map();   // id -> player
    this.byUser = new Map();    // lowercase name -> websocket
    this.nextId = 1;
    this.tick = null; this.beat = null; this.emptyTimer = null;
    this.meta = null;
  }

  pub(p) { return { id: p.id, user: p.user, avatar: p.avatar, pos: p.pos, rot: p.rot, walk: p.walk }; }
  broadcast(obj, skip = null) {
    const text = JSON.stringify(obj);
    for (const [id, p] of this.players) if (id !== skip) { try { p.ws.send(text); } catch { /* it will be cleaned up on close */ } }
  }
  async publish() { // tell D1 how many players are here, so the lobby and Play can find this room
    if (!this.meta) return;
    try {
      await this.env.DB.prepare("UPDATE rooms SET players = ?, updated = ? WHERE id = ?").bind(this.players.size, now(), this.meta.room).run();
    } catch (e) { console.error("room publish failed", String(e)); }
  }
  startTimers() {
    if (!this.tick) this.tick = setInterval(() => {
      if (this.players.size >= 2) {
        const s = {};
        for (const [id, p] of this.players) s[String(id)] = [...p.pos, p.rot, p.walk];
        this.broadcast({ t: "states", s });
      }
    }, TICK_MS);
    if (!this.beat) this.beat = setInterval(() => this.publish(), HEARTBEAT_MS);
    if (this.emptyTimer) { clearTimeout(this.emptyTimer); this.emptyTimer = null; }
  }
  stopTimersSoon() {
    if (this.players.size) return;
    clearInterval(this.tick); this.tick = null;
    this.emptyTimer = setTimeout(() => { clearInterval(this.beat); this.beat = null; }, EMPTY_MS);
  }

  dropByWs(ws) { // remove a player whose socket we closed ourselves (the close event may never come)
    for (const [id, p] of this.players) if (p.ws === ws) { this.players.delete(id); this.broadcast({ t: "left", id }); }
    for (const [k, v] of this.byUser) if (v === ws) this.byUser.delete(k);
  }

  async fetch(request) {
    const h = request.headers;
    if (h.get("x-nx-kick")) { // staff: remove this person from the room
      const ws = this.byUser.get(h.get("x-nx-kick").toLowerCase());
      if (ws) {
        try { for (const p of this.players.values()) if (p.ws === ws) ws.send(JSON.stringify({ t: "chat", id: 0, user: "Nexora", m: dec(h.get("x-nx-msg") || btoa("You were removed by staff.")) })); } catch { /* gone */ }
        try { ws.close(1000, "removed by staff"); } catch { /* gone */ }
        this.dropByWs(ws); this.publish(); this.stopTimersSoon();
      }
      return new Response(ws ? "1" : "0");
    }
    this.meta = { room: h.get("x-nx-room"), game: h.get("x-nx-game"), name: dec(h.get("x-nx-name")), max: Number(h.get("x-nx-max") || 12) };
    const user = h.get("x-nx-user");
    const avatar = JSON.parse(dec(h.get("x-nx-avatar")));  // from the account, never from the game client
    const pair = new WebSocketPair();
    const ws = pair[1];
    ws.accept();
    this.session(ws, user, avatar);
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  session(ws, user, avatar) {
    let me = null, joined = false, bucket = 60, stamp = Date.now();
    const deny = (reason) => { try { ws.send(JSON.stringify({ t: "deny", reason })); ws.close(1000, "denied"); } catch { /* gone */ } };
    const timer = setTimeout(() => { if (!joined) { try { ws.close(1000, "no join"); } catch { /* gone */ } } }, 8000);
    const leave = () => {
      clearTimeout(timer);
      if (me && this.players.get(me.id) === me) {
        this.players.delete(me.id);
        this.broadcast({ t: "left", id: me.id });
        if (this.byUser.get(user.toLowerCase()) === ws) this.byUser.delete(user.toLowerCase());
        this.publish();
        this.stopTimersSoon();
      }
    };
    const drop = (code, reason) => { try { ws.close(code, reason); } catch { /* gone */ } leave(); }; // don't wait for the peer to answer
    ws.addEventListener("close", leave);
    ws.addEventListener("error", leave);
    ws.addEventListener("message", async (ev) => {
      try {
        if (typeof ev.data !== "string" || ev.data.length > 16 * 1024) return drop(1009, "too big");
        const t0 = Date.now();                      // at most ~60 messages per second per player
        bucket = Math.min(60, bucket + ((t0 - stamp) / 1000) * 60); stamp = t0; bucket -= 1;
        if (bucket < 0) return drop(1008, "too fast");
        const m = JSON.parse(ev.data);
        if (!joined) {
          if (m.t !== "join" || m.v !== PROTOCOL) return deny("Version mismatch - update Nexora.");
          const old = this.byUser.get(user.toLowerCase());
          if (old) { try { old.close(1000, "signed in elsewhere"); } catch { /* gone */ } this.dropByWs(old); }
          if (this.players.size >= this.meta.max) return deny("Server is full.");
          joined = true; clearTimeout(timer);
          me = { id: this.nextId++, user, avatar, pos: [0, 0, 0], rot: 0, walk: false, ws, lastChat: 0 };
          this.byUser.set(user.toLowerCase(), ws);
          ws.send(JSON.stringify({ t: "welcome", id: me.id, game: this.meta.game, name: this.meta.name, max: this.meta.max,
                                   players: [...this.players.values()].map((p) => this.pub(p)) }));
          this.players.set(me.id, me);
          this.broadcast({ t: "joined", p: this.pub(me) }, me.id);
          this.startTimers();
          this.publish();
          return;
        }
        if (m.t === "state") {
          const [x, y, z] = m.p.map((v) => coord(v));
          me.pos = [Math.round(x * 100) / 100, Math.round(y * 100) / 100, Math.round(z * 100) / 100];
          me.rot = Math.round(coord(m.r ?? 0, 100000) * 10) / 10;
          me.walk = Boolean(m.w);
        } else if (m.t === "chat") {
          const text = cleanChat(m.m);
          if (text && (t0 - me.lastChat) / 1000 >= 0.6) {
            me.lastChat = t0;
            let mute = null;
            try { mute = await this.env.DB.prepare("SELECT until, reason FROM mutes WHERE user = ? AND (until = 0 OR until > ?)").bind(user, now()).first(); } catch { /* no mute table yet */ }
            if (mute) {
              const left = mute.until === 0 ? "permanently" : `for about ${Math.max(1, Math.ceil((mute.until - now()) / 60))} more minute(s)`;
              ws.send(JSON.stringify({ t: "chat", id: 0, user: "Nexora", m: `You are muted ${left}.` + (mute.reason ? ` ${mute.reason}` : "") }));
            } else this.broadcast({ t: "chat", id: me.id, user: me.user, m: text });
          }
        } else if (m.t === "bye") {
          drop(1000, "bye");
        }
      } catch { drop(1007, "bad data"); }  // bad data: drop this player only
    });
  }
}
