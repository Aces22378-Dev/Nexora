// Nexora server for Cloudflare Workers: the same API as nexora_server.py (accounts, games, Nexei, shop, rooms).
// Data lives in D1 (schema.sql). Live rooms are Durable Objects (room.js).
import * as av from "./avatar.js";
import { cleanProject, isDev, ID_RE } from "./project.js";
import MANIFEST from "./manifest.json";
import { ADMIN_HTML } from "./admin_page.js";
import { MOD_TABLES, activeBan, banMessage, deleteAccount, makeAdmin, noteCheck } from "./admin.js";
import { hashPassword, now, randomHex, randomUrlToken, safeEqual, sha256Hex, cps } from "./util.js";

export { Room } from "./room.js";

const ROOM_MAX = 12, MAX_ROOMS = 200, TOKEN_DAYS = 30, MAX_GAMES_PER_USER = 30, PLAY_COUNT_GAP = 300, ROOM_FRESH = 90;
const DAILY_NEXEI = 100, DAILY_GAP = 86400, SELLER_SHARE = 0.7, MAX_PRICE = 1000000, MAX_PASSES_PER_GAME = 20;
const MAX_PENDING_PER_USER = 10, MAX_ITEMS_PER_USER = 100;
const FREE_SHIRT = new Set(["#7c5cff", "#22d3ee", "#ef4444", "#f59e0b", "#4ade80", "#ec4899", "#f8fafc", "#1f2937"]);
const FREE_PANTS = new Set(["#2b2b4a", "#1d4ed8", "#374151", "#7f1d1d", "#14532d", "#78350f", "#f8fafc", "#0f172a"]);
const RESERVED = new Set(["nexora", "admin", "administrator", "moderator", "staff", "support", "system", "creator"]);
const NAME_RE = /^[A-Za-z0-9_]{3,20}$/;
const BUILTIN = [ // the built-in games exist on every PC; the server only keeps their numbers (same rows as games.py)
  ["plaza", "Nexora Plaza", "A chill open plaza. Collect every coin.", "🏙️", "#4f46e5"],
  ["skyrun", "Sky Run", "An obby above the clouds. Reach the gold pad.", "☁️", "#db2777"],
];

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json" } });
const ok = (extra = {}) => json({ ok: true, ...extra });
const fail = (msg, status = 400) => json({ ok: false, error: msg }, status);
const bad = (status, msg) => { throw new HttpError(status, msg); };

// ------------------------------------------------------------ helpers
class Ctx {
  constructor(request, env, ctx, params, url) {
    Object.assign(this, { request, env, ctx, params, url });
    this.db = env.DB;
    this._user = undefined;
    this.verifiedList = new Set((env.NEXORA_VERIFIED ?? "Aces22378,Ivy").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean));
    this.staffList = new Set((env.NEXORA_STAFF ?? "Aces22378,Ivy").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean));
  }
  q(sql, ...p) { return this.db.prepare(sql).bind(...p); }
  first(sql, ...p) { return this.q(sql, ...p).first(); }
  async all(sql, ...p) { return (await this.q(sql, ...p).all()).results ?? []; }
  run(sql, ...p) { return this.q(sql, ...p).run(); }
  isStaff(name) { return this.staffList.has((name || "").toLowerCase()); }
  ip() { return this.request.headers.get("CF-Connecting-IP") || "?"; }
  async body() {
    const len = Number(this.request.headers.get("content-length") || 0);
    if (len > 2 * 1024 * 1024) bad(413, "That's too big.");
    let d;
    try { d = await this.request.json(); } catch { bad(400, "Bad request."); }
    if (d === null || typeof d !== "object" || Array.isArray(d)) bad(400, "Bad request.");
    return d;
  }
  bearer() {
    const h = this.request.headers.get("Authorization") || "";
    return h.startsWith("Bearer ") ? h.slice(7) : "";
  }
  async userForToken(token) {
    if (!token) return null;
    return this.first("SELECT u.* FROM tokens t JOIN users u ON u.name = t.user WHERE t.hash = ? AND t.expires > ?",
                      await sha256Hex(token), now());
  }
  async user() { // optional
    if (this._user === undefined) {
      const u = await this.userForToken(this.bearer());
      const ban = u && !this.isStaff(u.name) && await activeBan(this, u.name);
      if (ban) bad(403, banMessage(ban));
      this._user = u;
    }
    return this._user;
  }
  async me() {
    const u = await this.user();
    if (!u) bad(401, "Please sign in again.");
    return u;
  }
  // Rate limits live in D1 so they hold across Worker instances. (NEXORA_DISABLE_LIMITS is for automated tests only.)
  async allow(key, limit, windowSecs) {
    if (this.env.NEXORA_DISABLE_LIMITS === "1") return true;
    const t = now();
    const row = await this.first("SELECT n, reset FROM limits WHERE key = ?", key);
    if (!row || row.reset <= t) {
      await this.run("INSERT OR REPLACE INTO limits (key, n, reset) VALUES (?, 1, ?)", key, t + windowSecs);
      return true;
    }
    if (row.n >= limit) return false;
    await this.run("UPDATE limits SET n = n + 1 WHERE key = ?", key);
    return true;
  }
}

async function publicUser(c, u) {
  return { username: u.name, avatar: av.clean(JSON.parse(u.avatar || "{}")), staff: c.isStaff(u.name) };
}
async function newToken(c, name) {
  const token = randomUrlToken(32);
  await c.db.batch([
    c.q("DELETE FROM tokens WHERE expires < ?", now()),
    c.q("INSERT INTO tokens (hash, user, expires) VALUES (?, ?, ?)", await sha256Hex(token), name, now() + TOKEN_DAYS * 86400),
  ]);
  return token;
}

// ------------------------------------------------------------ accounts
async function register(c) {
  const d = await c.body();
  const name = String(d.username ?? "").trim(), pw = String(d.password ?? "");
  if (!NAME_RE.test(name)) return fail("Username must be 3-20 letters, numbers or underscores.");
  if (cps(pw).length < 6 || cps(pw).length > 128) return fail("Password must be 6-128 characters.");
  if (!(await c.allow(`reg:${c.ip()}`, 6, 3600))) return fail("Too many new accounts from this network. Try again later.", 429);
  const code = c.env.NEXORA_STAFF_CODE || "";
  if (c.isStaff(name) && !(code && safeEqual(String(d.staff_code ?? ""), code))) return fail("That username is reserved for Nexora staff.");
  if (RESERVED.has(name.toLowerCase()) || (await c.first("SELECT 1 AS x FROM users WHERE name = ?", name))) return fail("That username is taken.");
  const salt = randomHex(16);
  const hash = await hashPassword(pw, salt, "pbkdf2");
  try {
    await c.run("INSERT INTO users (name, salt, hash, created, avatar, algo) VALUES (?, ?, ?, ?, ?, 'pbkdf2')", name, salt, hash, now(), "{}");
  } catch { return fail("That username is taken."); }
  const u = await c.first("SELECT * FROM users WHERE name = ?", name);
  return ok({ token: await newToken(c, u.name), user: await publicUser(c, u) });
}

async function login(c) {
  const d = await c.body();
  const name = String(d.username ?? "").trim(), pw = String(d.password ?? "");
  if (!(await c.allow(`login:${c.ip()}:${name.toLowerCase()}`, 10, 300))) return fail("Too many tries. Wait a few minutes.", 429);
  const u = await c.first("SELECT * FROM users WHERE name = ?", name);
  const algo = u ? (u.algo || "scrypt") : "pbkdf2";
  const h = await hashPassword(pw.slice(0, 128), u ? u.salt : "00".repeat(16), algo);
  if (!u || !safeEqual(h, u.hash)) return fail("Wrong username or password.", 401);
  if (algo === "scrypt") { // upgrade an old (Python server) password hash to the fast kind
    const salt = randomHex(16);
    await c.run("UPDATE users SET salt = ?, hash = ?, algo = 'pbkdf2' WHERE name = ?", salt, await hashPassword(pw, salt, "pbkdf2"), u.name);
  }
  const ban = !c.isStaff(u.name) && await activeBan(c, u.name);
  if (ban) return fail(banMessage(ban), 403);
  return ok({ token: await newToken(c, u.name), user: await publicUser(c, u) });
}

// Delete your own account (needs the password again). Staff accounts can't be deleted this way.
async function deleteSelf(c) {
  const u = await c.me(), d = await c.body();
  if (c.isStaff(u.name)) return fail("Staff accounts can't be deleted here.", 403);
  if (!(await c.allow(`del:${u.name.toLowerCase()}`, 5, 600))) return fail("Too many tries. Wait a few minutes.", 429);
  const algo = u.algo || "scrypt";
  if (!safeEqual(await hashPassword(String(d.password ?? "").slice(0, 128), u.salt, algo), u.hash)) return fail("Wrong password.", 401);
  await deleteAccount(c, u.name);
  report(c, `Punishment: Account Deletion\nModerator: Self (${u.name})\nAffected: ${u.name}\nReason: Deleted by the player\nNotes: None`);
  return ok();
}

async function logout(c) {
  const t = c.bearer();
  if (t) await c.run("DELETE FROM tokens WHERE hash = ?", await sha256Hex(t));
  return ok();
}
async function me(c) { return ok({ user: await publicUser(c, await c.me()) }); }
// Badges by names: "verified" and "staff" (staff is the higher one: someone with both shows only the staff badge).
// Silent modified-client check: the client sends its file hashes; a mismatch is reported to staff on Discord.
// The answer is always the same, so a modified client learns nothing. Staff accounts are ignored.
const HEX64 = /^[0-9a-f]{64}$/, VER_RE = /^[A-Za-z0-9._-]{1,30}$/;
async function integrity(c) {
  const u = await c.me();
  let ver = "?";
  try {
    const d = await c.body(), files = d.files;
    ver = typeof d.version === "string" ? d.version.slice(0, 30) : "?";
    if (c.isStaff(u.name)) { await noteCheck(c, u.name, ver, "staff account (ignored)"); return ok(); }
    if (typeof d.version !== "string" || !VER_RE.test(d.version) || !Object.hasOwn(MANIFEST, d.version)) { await noteCheck(c, u.name, ver, "version not in the server's manifest (ignored)"); return ok(); }
    if (!files || typeof files !== "object" || Array.isArray(files) || Object.keys(files).length > 200) { await noteCheck(c, u.name, ver, "bad data (ignored)"); return ok(); }
    for (const [k, v] of Object.entries(files)) if (k.length >= 80 || typeof v !== "string" || !HEX64.test(v)) { await noteCheck(c, u.name, ver, "bad data (ignored)"); return ok(); }
    if (!(await c.allow(`integrity:${u.name.toLowerCase()}`, 6, 3600))) { await noteCheck(c, u.name, ver, "too many checks (ignored)"); return ok(); }
    const official = MANIFEST[ver];
    if (Object.entries(official).every(([k, h]) => files[k] === h) && Object.keys(files).every((k) => k in official)) { await noteCheck(c, u.name, ver, "clean"); return ok(); }
    // once per person per version per week
    if (!(await c.allow(`integrity-hit:${u.name.toLowerCase()}:${ver}`, 1, 7 * 86400))) { await noteCheck(c, u.name, ver, "modified (already reported this week)"); return ok(); }
    const hook = c.env.NEXORA_TAMPER_WEBHOOK || "";
    if (hook.startsWith(c.env.NEXORA_WEBHOOK_PREFIX || "https://discord.com/api/webhooks/")) {
      await noteCheck(c, u.name, ver, "modified (reported to Discord)");
      c.ctx.waitUntil(fetch(hook, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ content: `Modified client: ${u.name}\nVersion: Nexora ${ver}`, allowed_mentions: { parse: [] } }),
      }).then((r) => { if (!r.ok) console.error("tamper webhook answered", r.status); }).catch((e) => console.error("tamper webhook failed", String(e))));
    } else await noteCheck(c, u.name, ver, "modified (NO webhook set, nothing sent)");
  } catch (e) { if (e instanceof HttpError && e.status === 401) throw e; await noteCheck(c, u.name, ver, "error"); }
  return ok();
}

async function badges(c) {
  const out = {};
  for (const n of c.verifiedList) out[n] = "verified";
  for (const n of c.staffList) out[n] = "staff";
  return ok({ badges: out });
}
async function userExists(c) {
  await c.me();
  const row = await c.first("SELECT name FROM users WHERE name = ?", c.params.name);
  return ok({ username: row ? row.name : null });
}

// Which of these usernames still exist? The launcher uses it to drop deleted accounts from its lists.
async function usersExist(c) {
  await c.me();
  const d = await c.body();
  const names = [...new Set((Array.isArray(d.names) ? d.names : []).map(String).filter((n) => NAME_RE.test(n)))].slice(0, 60);
  if (!names.length) return ok({ exist: [] });
  const rows = await c.all(`SELECT name FROM users WHERE name IN (${names.map(() => "?").join(",")})`, ...names);
  return ok({ exist: rows.map((r) => r.name) });
}

async function setAvatar(c) {
  const u = await c.me();
  let d = (await c.body()).avatar;
  d = d && typeof d === "object" && !Array.isArray(d) ? d : {};
  const a = av.clean(d);
  const staff = c.isStaff(u.name);
  const owned = new Map();
  for (const r of await c.all("SELECT i.* FROM items i JOIN purchases p ON p.item = i.id WHERE p.user = ? AND COALESCE(i.status,'approved') = 'approved'", u.name)) owned.set(r.id, r);
  if (staff) for (const r of await c.all("SELECT * FROM items WHERE kind IN ('shirt','pants','acc') AND COALESCE(status,'approved') = 'approved'")) if (!owned.has(r.id)) owned.set(r.id, r);
  const ownedColors = new Set([...owned.values()].map((r) => r.color).filter(Boolean));
  const free = { shirt: FREE_SHIRT, pants: FREE_PANTS };
  a.sleeve_tex = null;  // sleeves only ever come from a shirt you own
  for (const part of ["shirt", "pants"]) {
    const iid = a[part + "_item"];
    a[part + "_tex"] = null; a[part + "_item"] = null;
    if (iid) {
      const r = owned.get(iid);
      if (!r || r.kind !== part) return fail(`You don't own that ${part}. Buy it in the Shop first.`, 403);
      const payload = r.payload ? JSON.parse(r.payload) : {};
      a[part] = r.color; a[part + "_tex"] = payload.tex ?? null; a[part + "_item"] = r.id;
      if (part === "shirt") a.sleeve_tex = payload.sleeve ?? null;
    } else if (!free[part].has(a[part]) && !ownedColors.has(a[part]) && !staff) {
      return fail(`You don't own that ${part}. Buy it in the Shop first.`, 403);
    }
  }
  const raw = Array.isArray(d.acc) ? d.acc : [];
  const wanted = raw.slice(0, 4).filter((x) => x && typeof x === "object" && x.id).map((x) => cps(String(x.id)).slice(0, 20).join(""));
  const acc = [];
  for (const iid of wanted) {
    const r = owned.get(iid);
    if (!r || r.kind !== "acc") return fail("You don't own that accessory. Buy it in the Shop first.", 403);
    const whole = r.payload ? JSON.parse(r.payload) : {};
    if (whole.bundle) continue;   // a bundle only hands out its parts; it isn't worn itself
    const p = whole.acc ?? {};
    const item = av.cleanAcc({ id: r.id, name: r.name, slot: p.slot, boxes: p.boxes, mesh: p.mesh });
    if (item && acc.every((x) => x.slot !== item.slot)) acc.push(item);
  }
  const legs = acc.filter((x) => av.LEG_SLOTS.includes(x.slot));
  for (const x of legs.slice(0, -1)) acc.splice(acc.indexOf(x), 1);   // one leg item at a time: the last one stays
  a.acc = acc;
  await c.run("UPDATE users SET avatar = ? WHERE name = ?", JSON.stringify(a), u.name);
  return ok({ avatar: a });
}

// ------------------------------------------------------------ games
async function liveRooms(c, gameId) {
  return c.all("SELECT * FROM rooms WHERE game = ? AND updated > ? ORDER BY players DESC", gameId, now() - ROOM_FRESH);
}
async function gameSummary(c, row) {
  const data = row.data ? JSON.parse(row.data) : {};
  const likes = (await c.first("SELECT COUNT(*) AS n FROM likes WHERE game = ?", row.id)).n;
  const playing = (await c.first("SELECT COALESCE(SUM(players),0) AS n FROM rooms WHERE game = ? AND updated > ?", row.id, now() - ROOM_FRESH)).n;
  return { id: row.id, name: row.name, desc: row.description, emoji: row.emoji, thumb: row.thumb, owner: row.owner,
           devs: data.devs ?? [], plays: row.plays, likes, playing, official: row.data === null, updated: row.updated,
           has_scripts: Boolean((data.scripts ?? []).length) };
}
async function getRow(c) {
  const row = await c.first("SELECT * FROM games WHERE id = ?", c.params.id.slice(0, 40));
  if (!row) bad(404, "That game doesn't exist.");
  return row;
}
const roomList = async (c, gid) => (await liveRooms(c, gid)).map((r) => ({ id: r.id, name: r.name, players: r.players, max: ROOM_MAX }));

async function listGames(c) {
  const q = (c.url.searchParams.get("q") || "").trim().toLowerCase().slice(0, 40);
  const rows = await c.all("SELECT * FROM games ORDER BY plays DESC, updated DESC LIMIT 300");
  const out = [];
  for (const r of rows) {
    if (!q || r.name.toLowerCase().includes(q) || (r.description || "").toLowerCase().includes(q) || r.owner.toLowerCase().includes(q)) out.push(await gameSummary(c, r));
  }
  return ok({ games: out });
}
async function gameDetail(c) {
  const row = await getRow(c);
  const s = await gameSummary(c, row);
  const data = row.data ? JSON.parse(row.data) : {};
  s.thumbs = data.thumbs ?? [];
  const u = await c.user();
  s.liked = Boolean(u && (await c.first("SELECT 1 AS x FROM likes WHERE game = ? AND user = ?", row.id, u.name)));
  s.servers = await roomList(c, row.id);
  return ok({ game: s });
}
async function gameData(c) {
  const row = await getRow(c);
  if (!row.data) return fail("That's a built-in game; it's already on your PC.", 404);
  return new Response(row.data, { headers: { "content-type": "application/json" } });
}
async function publish(c) {
  const u = await c.me();
  const gid = c.params.id;
  if (!ID_RE.test(gid)) return fail("Bad game id.");
  let d;
  try { d = cleanProject(await c.body()); } catch (e) { if (e instanceof HttpError) throw e; return fail(e.message); }
  if (d.id !== gid) return fail("The game id doesn't match.");
  const old = await c.first("SELECT * FROM games WHERE id = ?", gid);
  if (old) {
    if (old.data === null) return fail("That id belongs to a built-in game.", 403);
    const oldData = JSON.parse(old.data);
    if (!isDev(oldData, u.name)) return fail(`This game belongs to ${old.owner}.`, 403);
    d.owner = old.owner;
    if (u.name.toLowerCase() !== old.owner.toLowerCase()) d.devs = oldData.devs ?? [];
  } else {
    d.owner = u.name;
    if ((await c.first("SELECT COUNT(*) AS n FROM games WHERE owner = ?", u.name)).n >= MAX_GAMES_PER_USER) return fail(`You can publish at most ${MAX_GAMES_PER_USER} games.`);
  }
  const realDevs = [];
  for (const n of d.devs) {
    const row = await c.first("SELECT name FROM users WHERE name = ?", n);
    if (!row) return fail(`There's no Nexora account called ${n}.`);
    realDevs.push(row.name);
  }
  d.devs = realDevs;
  d.author = d.owner;
  const text = JSON.stringify(d), t = now();
  if (text.length > 1800000) return fail("This game is too big to publish (the limit is about 1.8 MB). Use fewer or smaller thumbnails.");
  if (old) await c.run("UPDATE games SET name=?, description=?, emoji=?, thumb=?, data=?, updated=? WHERE id=?", d.name, d.desc, d.emoji, d.thumb, text, t, gid);
  else await c.run("INSERT INTO games (id, owner, name, description, emoji, thumb, data, created, updated) VALUES (?,?,?,?,?,?,?,?,?)", gid, d.owner, d.name, d.desc, d.emoji, d.thumb, text, t, t);
  return ok({ game: await gameSummary(c, await c.first("SELECT * FROM games WHERE id = ?", gid)) });
}
async function unpublish(c) {
  const u = await c.me();
  const row = await getRow(c);
  if (row.data === null || row.owner.toLowerCase() !== u.name.toLowerCase()) return fail("Only the owner can remove a game.", 403);
  await c.db.batch([c.q("DELETE FROM games WHERE id = ?", row.id), c.q("DELETE FROM likes WHERE game = ?", row.id)]);
  return ok();
}
async function toggleLike(c) {
  const u = await c.me();
  const row = await getRow(c);
  let liked;
  if (await c.first("SELECT 1 AS x FROM likes WHERE game = ? AND user = ?", row.id, u.name)) {
    await c.run("DELETE FROM likes WHERE game = ? AND user = ?", row.id, u.name); liked = false;
  } else {
    await c.run("INSERT OR IGNORE INTO likes (game, user) VALUES (?, ?)", row.id, u.name); liked = true;
  }
  const n = (await c.first("SELECT COUNT(*) AS n FROM likes WHERE game = ?", row.id)).n;
  return ok({ liked, likes: n });
}
async function servers(c) { return ok({ servers: await roomList(c, (await getRow(c)).id) }); }

async function join(c) {
  const u = await c.me();
  const row = await getRow(c);
  let d = {};
  if (c.request.headers.get("content-length") && c.request.headers.get("content-length") !== "0") d = await c.body();
  let room;
  if (d.room !== undefined && d.room !== null) {
    room = await c.first("SELECT * FROM rooms WHERE id = ? AND updated > ?", String(d.room), now() - ROOM_FRESH);
    if (!room || room.game !== row.id) return fail("That server doesn't exist any more.", 404);
    if (room.players >= ROOM_MAX) return fail("That server is full.", 409);
  } else {
    room = await c.first("SELECT * FROM rooms WHERE game = ? AND players < ? AND updated > ? ORDER BY players DESC LIMIT 1", row.id, ROOM_MAX, now() - ROOM_FRESH);
    if (!room) {
      await c.run("DELETE FROM rooms WHERE updated < ?", now() - 600);
      if ((await c.first("SELECT COUNT(*) AS n FROM rooms WHERE updated > ?", now() - ROOM_FRESH)).n >= MAX_ROOMS) return fail("Nexora is very busy right now. Try again in a minute.", 503);
      const n = (await c.first("INSERT INTO room_counters (game, n) VALUES (?, 1) ON CONFLICT(game) DO UPDATE SET n = n + 1 RETURNING n", row.id)).n;
      room = { id: randomUrlToken(6), game: row.id, name: `${row.name} #${n}`, players: 0, updated: now() };
      await c.run("INSERT INTO rooms (id, game, name, players, updated) VALUES (?, ?, ?, 0, ?)", room.id, room.game, room.name, room.updated);
    }
  }
  const last = await c.first("SELECT at FROM plays WHERE game = ? AND user = ?", row.id, u.name);
  if (!last || now() - last.at > PLAY_COUNT_GAP) {
    await c.db.batch([c.q("INSERT OR REPLACE INTO plays (game, user, at) VALUES (?, ?, ?)", row.id, u.name, now()),
                      c.q("UPDATE games SET plays = plays + 1 WHERE id = ?", row.id)]);
  }
  return ok({ room: room.id, name: room.name, players: room.players, max: ROOM_MAX, game: row.id, official: row.data === null });
}

// ------------------------------------------------------------ Nexei: wallet, shop, gamepasses
async function walletOf(c, u) {
  const row = await c.first("SELECT balance, last_daily FROM users WHERE name = ?", u.name);
  const wait = Math.max(0, Math.trunc(row.last_daily + DAILY_GAP - now()));
  const staff = c.isStaff(u.name);
  return { balance: staff ? null : (row.balance || 0), infinite: staff, daily_in: wait, daily: DAILY_NEXEI };
}
async function itemJson(r, owned, me) {
  const payload = r.payload ? JSON.parse(r.payload) : {};
  return { id: r.id, kind: r.kind, game: r.game, name: r.name, desc: r.description, price: r.price, color: r.color,
           creator: r.creator, owned: owned.has(r.id), status: r.status || "approved",
           mine: Boolean(me && r.creator && r.creator.toLowerCase() === me.toLowerCase()),
           tex: payload.tex ?? null, sleeve: payload.sleeve ?? null, acc: payload.acc ?? null,
           bundle: payload.bundle ?? null, hidden: Boolean(payload.hidden) };
}
const ownedIds = async (c, u) => new Set((await c.all("SELECT item FROM purchases WHERE user = ?", u.name)).map((r) => r.item));

function cleanItem(d, kind) {
  const name = cps(String(d.name ?? "").split(/\s+/).filter(Boolean).join(" ")).slice(0, 40).join("");
  const desc = cps(String(d.desc ?? "").split(/\s+/).filter(Boolean).join(" ")).slice(0, 200).join("");
  const price = d.price;
  if (!name) throw new Error("Give it a name.");
  if (!Number.isInteger(price) || price < 1 || price > MAX_PRICE) throw new Error(`The price must be a whole number from 1 to ${MAX_PRICE.toLocaleString("en-US")} Nexei.`);
  let color = null;
  if (kind === "shirt" || kind === "pants") {
    color = String(d.color ?? "").toLowerCase();
    if (!av.HEX.test(color)) throw new Error("Pick a colour like #ff8800.");
  }
  return { name, desc, price, color };
}
function cleanPayload(d, kind) {
  if (kind === "acc") {
    const a = av.cleanAcc({ slot: d.slot, name: d.name, boxes: d.boxes, mesh: d.mesh });
    if (!a) throw new Error(`An accessory needs a place to wear it (head, face, back or neck) and 1-8 boxes or a 3D model (up to ${av.MAX_TRIS} triangles).`);
    const acc = { slot: a.slot, boxes: a.boxes };
    if (a.mesh) acc.mesh = a.mesh;
    return { acc };
  }
  const tex = d.tex ? av.cleanTex(d.tex) : null;
  if (d.tex && !tex) throw new Error("That picture isn't valid. Use a 32x32 (or 8x8) grid with at most 16 colours.");
  const out = tex ? { tex } : {};
  if (kind === "shirt" && d.sleeve) {
    const sl = av.cleanSleeve(d.sleeve);
    if (!sl) throw new Error("That sleeve picture isn't valid. Use a 16x32 (or 8x16) grid with at most 16 colours.");
    out.sleeve = sl;
  }
  return out;
}
async function canManage(c, u, row) {
  const data = row.data ? JSON.parse(row.data) : {};
  const me = u.name.toLowerCase();
  return me === (row.owner || "").toLowerCase() || (data.devs ?? []).some((x) => String(x).toLowerCase() === me);
}

const wallet = async (c) => ok({ wallet: await walletOf(c, await c.me()) });
async function claimDaily(c) {
  const u = await c.me();
  const w = await walletOf(c, u);
  if (w.infinite) return fail("Staff accounts already have unlimited Nexei.");
  if (w.daily_in > 0) return fail(`Come back in ${Math.floor(w.daily_in / 3600)}h ${Math.floor((w.daily_in % 3600) / 60)}m for your next free Nexei.`);
  await c.run("UPDATE users SET balance = balance + ?, last_daily = ? WHERE name = ?", DAILY_NEXEI, now(), u.name);
  return ok({ wallet: await walletOf(c, u) });
}
// Looks-only body items sold by Nexora itself: id, name, description, price, slot, extra payload, earlier default price.
// "Legless" is a bundle: buying it gives you the Left and Right leg item (no price of their own, only shown once you own
// them); you can wear one at a time. Created once; a price changed in the database sticks, one still at an earlier
// default is moved to the current default.
const OFFICIAL_ITEMS = [
  ["o-headless", "Headless", "Take your head off. Just for looks.", 31000, "nohead", {}, 200],
  ["o-legless-b", "Legless", "Get the Left and Right leg items: take a leg off. You can wear one at a time. Just for looks.", 17000, "noleftleg", { bundle: ["o-legless-l", "o-legless-r"] }, null],
  ["o-legless-l", "Legless (Left)", "Included with Legless. Takes your left leg off. Just for looks.", 0, "noleftleg", { hidden: true }, 100],
  ["o-legless-r", "Legless (Right)", "Included with Legless. Takes your right leg off. Just for looks.", 0, "norightleg", { hidden: true }, 100],
];
let officialSeeded = false;
async function seedOfficial(c) {
  if (officialSeeded) return;
  const stmts = [];
  for (const [id, name, desc, price, slot, extra, old] of OFFICIAL_ITEMS) {
    const payload = JSON.stringify({ acc: { slot, boxes: [] }, ...extra });
    stmts.push(c.q("INSERT OR IGNORE INTO items (id, kind, game, name, description, price, color, creator, created, payload, status) VALUES (?, 'acc', NULL, ?, ?, ?, NULL, NULL, ?, ?, 'approved')",
        id, name, desc, price, now(), payload));
    if (old !== null) stmts.push(c.q("UPDATE items SET price = ?, payload = ?, description = ?, name = ? WHERE id = ? AND price = ?", price, payload, desc, name, id, old));
  }
  await c.db.batch(stmts);
  officialSeeded = true;
}
async function shop(c) {
  await seedOfficial(c);
  const u = await c.me();
  const owned = await ownedIds(c, u);
  const rows = await c.all("SELECT * FROM items WHERE kind IN ('shirt','pants','acc') AND (COALESCE(status,'approved') = 'approved' OR creator = ?) ORDER BY created DESC", u.name);
  const items = await Promise.all(rows.map((r) => itemJson(r, owned, u.name)));
  return ok({ items: items.filter((i) => !i.hidden || i.owned) });   // bundle parts only show once you own them
}
async function shopReviewList(c) {
  const u = await c.me();
  if (!c.isStaff(u.name)) return fail("Only Nexora staff can review items.", 403);
  const rows = await c.all("SELECT * FROM items WHERE status = 'pending' ORDER BY created");
  return ok({ items: await Promise.all(rows.map((r) => itemJson(r, new Set(), u.name))) });
}
async function shopAdd(c) {
  const u = await c.me();
  if (!(await c.allow(`make:${u.name.toLowerCase()}`, 10, 3600))) return fail("You're making items too fast. Try again in a while.", 429);
  const d = await c.body();
  const kind = d.kind;
  if (!["shirt", "pants", "acc"].includes(kind)) return fail("Make a shirt, pants or accessory.");
  if (kind === "acc" && av.HIDE_SLOTS.includes(d.slot) && !c.isStaff(u.name)) return fail("Only Nexora staff can make body items (Headless, Legless).", 403);
  let item, payload;
  try { item = cleanItem(d, kind); payload = cleanPayload(d, kind); } catch (e) { return fail(e.message); }
  const staff = c.isStaff(u.name);
  const mine = await c.first("SELECT COUNT(*) AS n, COALESCE(SUM(status = 'pending'),0) AS p FROM items WHERE creator = ? AND kind IN ('shirt','pants','acc')", u.name);
  if (mine.n >= MAX_ITEMS_PER_USER) return fail(`You can have up to ${MAX_ITEMS_PER_USER} items.`);
  if (!staff && mine.p >= MAX_PENDING_PER_USER) return fail(`You already have ${MAX_PENDING_PER_USER} items waiting for review. Wait for those first.`);
  const iid = randomHex(6), status = staff ? "approved" : "pending";
  await c.db.batch([
    c.q("INSERT INTO items (id, kind, game, name, description, price, color, creator, created, payload, status) VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?)",
        iid, kind, item.name, item.desc, item.price, item.color, u.name, now(), JSON.stringify(payload), status),
    c.q("INSERT OR IGNORE INTO purchases (user, item, price, at) VALUES (?, ?, 0, ?)", u.name, iid, now()),
  ]);
  return ok({ id: iid, status });
}
async function shopReview(c) {
  const u = await c.me();
  if (!c.isStaff(u.name)) return fail("Only Nexora staff can review items.", 403);
  const r = await c.first("SELECT * FROM items WHERE id = ?", c.params.id.slice(0, 20));
  if (!r || r.kind === "pass") return fail("That item doesn't exist.", 404);
  const approve = Boolean((await c.body()).approve);
  const status = approve ? "approved" : "rejected";
  await c.run("UPDATE items SET status = ? WHERE id = ?", status, r.id);
  return ok({ status });
}
async function itemDelete(c) {
  const u = await c.me();
  const r = await c.first("SELECT * FROM items WHERE id = ?", c.params.id.slice(0, 20));
  if (!r) return fail("That item doesn't exist.", 404);
  let allowed;
  if (r.kind === "pass") { const g = await c.first("SELECT * FROM games WHERE id = ?", r.game); allowed = Boolean(g && (await canManage(c, u, g))); }
  else allowed = c.isStaff(u.name) || (r.creator || "").toLowerCase() === u.name.toLowerCase();
  if (!allowed) return fail("You can't remove that.", 403);
  await c.run("DELETE FROM items WHERE id = ?", r.id);
  return ok();
}
async function gamePasses(c) {
  const u = await c.me();
  const row = await getRow(c);
  const owned = await ownedIds(c, u);
  const rows = await c.all("SELECT * FROM items WHERE kind = 'pass' AND game = ? ORDER BY created", row.id);
  return ok({ passes: await Promise.all(rows.map((r) => itemJson(r, owned, u.name))), can_manage: await canManage(c, u, row) });
}
async function passAdd(c) {
  const u = await c.me();
  const row = await getRow(c);
  if (row.data === null || !(await canManage(c, u, row))) return fail("Only the creator or a developer of this game can add gamepasses.", 403);
  const d = await c.body();
  let item;
  try { item = cleanItem(d, "pass"); } catch (e) { return fail(e.message); }
  if ((await c.first("SELECT COUNT(*) AS n FROM items WHERE kind = 'pass' AND game = ?", row.id)).n >= MAX_PASSES_PER_GAME) return fail(`A game can have up to ${MAX_PASSES_PER_GAME} gamepasses.`);
  if (await c.first("SELECT 1 AS x FROM items WHERE kind = 'pass' AND game = ? AND name = ? COLLATE NOCASE", row.id, item.name)) return fail("This game already has a gamepass with that name.");
  const iid = randomHex(6);
  await c.run("INSERT INTO items (id, kind, game, name, description, price, color, creator, created, status) VALUES (?, 'pass', ?, ?, ?, ?, NULL, ?, ?, 'approved')",
              iid, row.id, item.name, item.desc, item.price, row.owner, now());
  return ok({ id: iid });
}
async function buy(c) {
  const u = await c.me();
  if (!(await c.allow(`buy:${u.name.toLowerCase()}`, 30, 60))) return fail("Slow down a little.", 429);
  const r = await c.first("SELECT * FROM items WHERE id = ?", c.params.id.slice(0, 20));
  if (!r) return fail("That item isn't for sale any more.", 404);
  if ((r.status || "approved") !== "approved") return fail("That item isn't for sale.", 404);
  if ((await ownedIds(c, u)).has(r.id)) return fail("You already own this.");
  const staff = c.isStaff(u.name), price = r.price, t = now();
  const parts = ((r.payload ? JSON.parse(r.payload) : {}).bundle ?? []).map((x) => String(x).slice(0, 20));
  const grant = parts.map((id) => c.q("INSERT OR IGNORE INTO purchases (user, item, price, at) VALUES (?, ?, 0, ?)", u.name, id, t));
  const payout = r.creator && r.creator.toLowerCase() !== u.name.toLowerCase() ? Math.trunc(price * SELLER_SHARE) : 0;
  let stmts;
  if (staff) {
    stmts = [c.q("INSERT INTO purchases (user, item, price, at) VALUES (?, ?, 0, ?)", u.name, r.id, t)];
    if (payout) stmts.push(c.q("UPDATE users SET balance = balance + ? WHERE name = ?", payout, r.creator));
    stmts.push(...grant);
  } else {
    // All three run together or not at all: charge only if there's enough, record the purchase only if charged,
    // pay the creator only if the purchase was recorded.
    stmts = [
      c.q("UPDATE users SET balance = balance - ?1 WHERE name = ?2 AND balance >= ?1", price, u.name),
      c.q("INSERT INTO purchases (user, item, price, at) SELECT ?, ?, ?, ? WHERE changes() > 0", u.name, r.id, price, t),
    ];
    if (payout) stmts.push(c.q("UPDATE users SET balance = balance + ? WHERE name = ? AND changes() > 0", payout, r.creator));
    // the parts of a bundle: only if the purchase row above went in (the purchase table's key stops doubles)
    for (const id of parts) stmts.push(c.q("INSERT OR IGNORE INTO purchases (user, item, price, at) SELECT ?, ?, 0, ? WHERE EXISTS (SELECT 1 FROM purchases WHERE user = ? AND item = ?)", u.name, id, t, u.name, r.id));
  }
  let res;
  try { res = await c.db.batch(stmts); } catch { return fail("The purchase didn't go through. You were not charged.", 500); }
  if (!staff && res[0].meta.changes === 0) {
    const bal = (await c.first("SELECT balance FROM users WHERE name = ?", u.name)).balance || 0;
    return fail(`You need ${(price - bal).toLocaleString("en-US")} more Nexei.`, 402);
  }
  return ok({ wallet: await walletOf(c, u), item: await itemJson(r, new Set([r.id]), u.name) });
}
async function myPasses(c) {
  const u = await c.me();
  const row = await getRow(c);
  const rows = await c.all("SELECT i.name FROM items i JOIN purchases p ON p.item = i.id WHERE p.user = ? AND i.game = ? AND i.kind = 'pass'", u.name, row.id);
  return ok({ passes: rows.map((r) => r.name) });
}

// ------------------------------------------------------------ live rooms (Durable Objects)
async function wsRoom(c) {
  const { request, env } = c;
  if (request.headers.get("Upgrade") !== "websocket") return new Response("Expected a WebSocket.", { status: 426 });
  const user = await c.userForToken(c.url.searchParams.get("token") || "");
  const room = await c.first("SELECT * FROM rooms WHERE id = ?", c.params.room);
  const ban = user && !c.isStaff(user.name) && await activeBan(c, user.name);
  if (!user || !room || ban) { // say why over the socket, like the Python server
    const pair = new WebSocketPair();
    pair[1].accept();
    pair[1].send(JSON.stringify({ t: "deny", reason: ban ? banMessage(ban) : !user ? "Please sign in again." : "That server is gone." }));
    pair[1].close(1000, "denied");
    return new Response(null, { status: 101, webSocket: pair[0] });
  }
  const stub = env.ROOMS.get(env.ROOMS.idFromName(room.id));
  const h = new Headers(request.headers);
  h.set("x-nx-user", user.name);
  h.set("x-nx-avatar", btoa(unescape(encodeURIComponent(JSON.stringify(av.clean(JSON.parse(user.avatar || "{}")))))));
  h.set("x-nx-room", room.id);
  h.set("x-nx-game", room.game);
  h.set("x-nx-name", btoa(unescape(encodeURIComponent(room.name))));
  h.set("x-nx-max", String(ROOM_MAX));
  return stub.fetch(new Request(request.url, { headers: h }));
}

// ------------------------------------------------------------ staff tools (see admin.js)
function report(c, text) { // moderation actions go to a staff Discord channel when a webhook secret is set
  const hook = c.env.NEXORA_MOD_WEBHOOK || "";
  if (!hook.startsWith(c.env.NEXORA_WEBHOOK_PREFIX || "https://discord.com/api/webhooks/")) return;
  c.ctx.waitUntil(fetch(hook, { method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ content: text.slice(0, 1800), allowed_mentions: { parse: [] } }) }).catch(() => {}));
}
async function kickEverywhere(c, name, message) { // close the person's connection in whichever live room they are in
  let n = 0;
  for (const r of await c.all("SELECT id FROM rooms WHERE players > 0 AND updated > ?", now() - ROOM_FRESH)) {
    try {
      const res = await c.env.ROOMS.get(c.env.ROOMS.idFromName(r.id)).fetch("https://room/kick", { headers: { "x-nx-kick": name, "x-nx-msg": btoa(unescape(encodeURIComponent(message))) } });
      if ((await res.text()) === "1") n++;
    } catch { /* that room is gone */ }
  }
  return n;
}
const admin = makeAdmin({ ok, fail, bad, kickEverywhere, report });

// ------------------------------------------------------------ router
const ROUTES = [];
const route = (method, path, fn) => ROUTES.push([method, new RegExp("^" + path.replace(/\{(\w+)\}/g, "(?<$1>[^/]+)") + "$"), fn]);
route("GET", "/", () => new Response("Nexora server is running.\n"));
route("GET", "/health", () => new Response("Nexora server is running.\n"));
route("POST", "/api/register", register); route("POST", "/api/login", login); route("POST", "/api/logout", logout);
route("POST", "/api/integrity", integrity); route("GET", "/api/badges", badges); route("GET", "/api/me", me); route("PUT", "/api/avatar", setAvatar); route("GET", "/api/users/{name}", userExists); route("POST", "/api/users/exist", usersExist);
route("GET", "/api/games", listGames); route("GET", "/api/games/{id}", gameDetail);
route("GET", "/api/games/{id}/data", gameData); route("PUT", "/api/games/{id}", publish);
route("DELETE", "/api/games/{id}", unpublish); route("POST", "/api/games/{id}/like", toggleLike);
route("GET", "/api/games/{id}/servers", servers); route("POST", "/api/games/{id}/join", join);
route("GET", "/api/wallet", wallet); route("POST", "/api/daily", claimDaily);
route("GET", "/api/shop", shop); route("POST", "/api/shop", shopAdd); route("GET", "/api/shop/review", shopReviewList);
route("POST", "/api/items/{id}/review", shopReview); route("DELETE", "/api/items/{id}", itemDelete);
route("POST", "/api/items/{id}/buy", buy);
route("GET", "/api/games/{id}/passes", gamePasses); route("POST", "/api/games/{id}/passes", passAdd);
route("GET", "/api/games/{id}/mypasses", myPasses);
route("GET", "/ws/{room}", wsRoom);
route("POST", "/api/delete-account", deleteSelf); route("GET", "/api/notice", admin.notice);
route("GET", "/api/admin/overview", admin.overview); route("GET", "/api/admin/users", admin.users);
route("GET", "/api/admin/restrictions", admin.restrictions); route("GET", "/api/admin/checks", admin.checks); route("POST", "/api/admin/webhook-test", admin.webhookTest); route("GET", "/api/admin/log", admin.log);
route("POST", "/api/admin/ban", admin.ban); route("POST", "/api/admin/unban", admin.unban);
route("POST", "/api/admin/mute", admin.mute); route("POST", "/api/admin/unmute", admin.unmute);
route("POST", "/api/admin/kick", admin.kick); route("POST", "/api/admin/nexei", admin.nexei);
route("POST", "/api/admin/delete", admin.remove); route("POST", "/api/admin/notice", admin.setNotice);
route("GET", "/admin", () => new Response(ADMIN_HTML, { headers: {
  "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-frame-options": "DENY", "referrer-policy": "no-referrer",
  "content-security-policy": "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" } }));

let seeded = false;
async function seed(env) { // the built-in games need a row for their numbers (plays, likes)
  if (seeded) return;
  const t = now();
  await env.DB.batch(BUILTIN.map(([id, name, desc, emoji, thumb]) => env.DB.prepare(
    "INSERT OR IGNORE INTO games (id, owner, name, description, emoji, thumb, data, created, updated) VALUES (?, 'Nexora', ?, ?, ?, ?, NULL, ?, ?)")
    .bind(id, name, desc, emoji, thumb, t, t)));
  await env.DB.batch(MOD_TABLES.map((sql) => env.DB.prepare(sql)));
  seeded = true;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    try {
      await seed(env);
      for (const [method, rx, fn] of ROUTES) {
        if (request.method !== method) continue;
        const m = rx.exec(url.pathname);
        if (m) return await fn(new Ctx(request, env, ctx, { ...m.groups }, url));
      }
      return fail("Not found.", 404);
    } catch (e) {
      if (e instanceof HttpError) return fail(e.message, e.status);
      console.error(e && e.stack ? e.stack : String(e));
      return fail("Something went wrong on the server.", 500);
    }
  },
};
