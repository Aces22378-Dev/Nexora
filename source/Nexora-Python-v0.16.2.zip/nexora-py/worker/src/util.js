import { scrypt } from "scrypt-js";

const enc = new TextEncoder();
export const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
export const fromHex = (h) => Uint8Array.from(h.match(/../g) ?? [], (x) => parseInt(x, 16));

export async function sha256Hex(text) {
  return toHex(await crypto.subtle.digest("SHA-256", enc.encode(text)));
}
export function randomHex(bytes) {
  return toHex(crypto.getRandomValues(new Uint8Array(bytes)));
}
export function randomUrlToken(bytes) {
  const b = crypto.getRandomValues(new Uint8Array(bytes));
  return btoa(String.fromCharCode(...b)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// Passwords. New accounts use PBKDF2-SHA256 (built into Workers). Accounts made by the Python server use scrypt;
// those are still accepted (slower, pure JavaScript) and are upgraded to PBKDF2 the first time they log in.
export const PBKDF2_ITER = 100000; // the most Workers allow
export async function hashPassword(password, saltHex, algo) {
  if (algo === "scrypt" || !algo) {
    const out = await scrypt(enc.encode(password), fromHex(saltHex), 2 ** 14, 8, 1, 64);
    return toHex(out);
  }
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: fromHex(saltHex), iterations: PBKDF2_ITER }, key, 256);
  return toHex(bits);
}
export function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

export const now = () => Math.floor(Date.now() / 1000);
export const cps = (s) => Array.from(s);

export function cleanChat(t) {
  if (typeof t !== "string") return "";
  const kept = cps(t).filter((ch) => ch === " " || !/[\p{C}\p{Z}]/u.test(ch)).join("").trim();
  return cps(kept).slice(0, 120).join("");
}
export function coord(v, limit = 5000) {
  if (typeof v !== "number" || !Number.isFinite(v)) throw new Error("bad number");
  return Math.max(-limit, Math.min(limit, v));
}
