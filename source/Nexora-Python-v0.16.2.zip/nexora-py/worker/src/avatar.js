// Port of avatar.py: what an avatar is and the one function that cleans it. Keep the two in step.
export const HEX = /^#[0-9a-fA-F]{6}$/;
export const DEFAULT = { skin: "#f1c27d", shirt: "#7c5cff", pants: "#2b2b4a" };
export const SLOTS = ["head", "face", "back", "neck"];
export const HIDE_SLOTS = ["nohead", "noleftleg", "norightleg"];
export const BODIES = ["male", "female"];
export const SIZE_RANGE = [0.85, 1.15];
export const LEG_SLOTS = ["noleftleg", "norightleg"];   // "Headless" / "Legless": hide a body part, looks only
export const ALL_SLOTS = [...SLOTS, ...HIDE_SLOTS];
const MAX_PAL = 16, MAX_BOXES = 8, NAME_MAX = 30;
const TEX_SIZES = new Set([64, 1024]);      // a shirt front / pants picture: 8x8 (old) or 32x32 pixels
const SLEEVE_SIZES = new Set([128, 512]);   // sleeves: 8x16 (old) or 16x32
const PAL_CHARS = "0123456789abcdef";
const BOX_POS = { x: [-0.9, 0.9], y: [0.0, 2.8], z: [-0.9, 0.9] };
const BOX_SIZE = [0.05, 1.0];
export const MAX_VERTS = 700, MAX_TRIS = 1000;   // an imported 3D model; keep in step with avatar.py

const hex = (v, d = null) => (typeof v === "string" && HEX.test(v) ? v.toLowerCase() : d);
const num = (v, lo, hi) => {
  if (typeof v !== "number" || !Number.isFinite(v)) return null;
  return Math.round(Math.max(lo, Math.min(hi, v)) * 100) / 100;
};
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const cps = (s) => Array.from(s);

export function cleanTex(t, sizes = TEX_SIZES) {
  if (!isObj(t)) return null;
  const { pal, px } = t;
  if (!Array.isArray(pal) || typeof px !== "string" || !sizes.has(cps(px).length)) return null;
  const p = pal.slice(0, MAX_PAL).map((c) => hex(c));
  if (!p.length || p.some((c) => c === null)) return null;
  for (const ch of px) {
    if (ch === ".") continue;
    const i = PAL_CHARS.indexOf(ch);
    if (i < 0 || i >= p.length) return null;
  }
  if ([...px].every((c) => c === ".")) return null;
  return { pal: p, px };
}
export const cleanSleeve = (t) => cleanTex(t, SLEEVE_SIZES);

export function cleanBox(b) {
  if (!isObj(b)) return null;
  const { p, s } = b, c = hex(b.c);
  if (!Array.isArray(p) || !Array.isArray(s) || p.length !== 3 || s.length !== 3 || c === null) return null;
  const pos = p.map((v, i) => num(v, ...BOX_POS["xyz"[i]]));
  const size = s.map((v) => num(v, ...BOX_SIZE));
  if (pos.includes(null) || size.includes(null)) return null;
  return { p: pos, s: size, c };
}

export function cleanMesh(m) {
  if (!isObj(m)) return null;
  const { v, f } = m, c = hex(m.c, "#cccccc");
  if (!Array.isArray(v) || !Array.isArray(f) || v.length < 3 || v.length > MAX_VERTS || f.length < 1 || f.length > MAX_TRIS) return null;
  const verts = [];
  for (const p of v) {
    if (!Array.isArray(p) || p.length !== 3) return null;
    const q = p.map((x, i) => num(x, ...BOX_POS["xyz"[i]]));
    if (q.includes(null)) return null;
    verts.push(q.map((x) => Math.round(x * 1000) / 1000));
  }
  const tris = [], keep = [];
  for (let k = 0; k < f.length; k++) {
    const t = f[k];
    if (!Array.isArray(t) || t.length !== 3) return null;
    if (t.some((i) => !Number.isInteger(i) || i < 0 || i >= verts.length)) return null;
    if (new Set(t).size === 3) { tris.push([...t]); keep.push(k); }
  }
  if (!tris.length) return null;
  const out = { v: verts, f: tris, c };
  if (Array.isArray(m.pal) && typeof m.fc === "string") {
    const pal = m.pal.slice(0, MAX_PAL).map((x) => hex(x));
    if (pal.length && !pal.includes(null) && m.fc.length === f.length &&
        [...m.fc].every((ch) => ch >= "0" && ch <= "9" && Number(ch) < pal.length)) {
      out.pal = pal;
      out.fc = keep.map((k) => m.fc[k]).join("");
    }
  }
  return out;
}

export function cleanAcc(a) {
  if (!isObj(a) || !ALL_SLOTS.includes(a.slot)) return null;
  if (HIDE_SLOTS.includes(a.slot)) {   // nothing to draw: wearing it just hides the part
    const nm = cps(String(a.name ?? "").split(/\s+/).filter(Boolean).join(" ")).slice(0, NAME_MAX).join("");
    return { id: cps(String(a.id ?? "")).slice(0, 20).join(""), name: nm, slot: a.slot, boxes: [] };
  }
  const boxes = (Array.isArray(a.boxes) ? a.boxes : []).slice(0, MAX_BOXES).map(cleanBox).filter(Boolean);
  const mesh = cleanMesh(a.mesh);
  if (!boxes.length && !mesh) return null;
  const name = cps(String(a.name ?? "").split(/\s+/).filter(Boolean).join(" ")).slice(0, NAME_MAX).join("");
  const out = { id: cps(String(a.id ?? "")).slice(0, 20).join(""), name, slot: a.slot, boxes };
  if (mesh) out.mesh = mesh;
  return out;
}

export function clean(av) {
  const out = { ...DEFAULT, shirt_tex: null, pants_tex: null, sleeve_tex: null, shirt_item: null, pants_item: null, acc: [], height: 1, width: 1, body: "male" };
  if (isObj(av)) {
    for (const k of ["height", "width"]) {
      const v = av[k];
      out[k] = typeof v === "number" && Number.isFinite(v) ? Math.round(Math.max(SIZE_RANGE[0], Math.min(SIZE_RANGE[1], v)) * 100) / 100 : 1;
    }
    out.body = BODIES.includes(av.body) ? av.body : "male";
    for (const k of Object.keys(DEFAULT)) out[k] = hex(av[k], out[k]);
    out.shirt_tex = cleanTex(av.shirt_tex);
    out.pants_tex = cleanTex(av.pants_tex);
    out.sleeve_tex = cleanSleeve(av.sleeve_tex);
    for (const k of ["shirt_item", "pants_item"]) {
      const v = av[k];
      out[k] = typeof v === "string" && v ? cps(v).slice(0, 20).join("") : null;
    }
    const seen = new Set();
    for (const a0 of (Array.isArray(av.acc) ? av.acc : []).slice(0, ALL_SLOTS.length)) {
      const a = cleanAcc(a0);
      if (a && !seen.has(a.slot)) { seen.add(a.slot); out.acc.push(a); }
    }
    const legs = out.acc.filter((a) => LEG_SLOTS.includes(a.slot));
    if (legs.length > 1) out.acc.splice(out.acc.indexOf(legs[0]), 1);   // one leg off at a time: the last one wins
  }
  return out;
}
