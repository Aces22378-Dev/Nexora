// The staff page served at /admin. It only calls the /api/admin/* endpoints, which check staff on the server.
export const ADMIN_HTML = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nexora Staff</title>
<style>
:root{--bg:#0a0a12;--panel:#14142a;--panel2:#1c1c38;--line:#2a2a4a;--text:#ecebff;--dim:#9a98c4;--accent:#7c5cff;--cyan:#22d3ee;--danger:#ff5470;--ok:#3ddc97}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.4 system-ui,Segoe UI,sans-serif}
header{display:flex;align-items:center;gap:12px;padding:12px 16px;background:var(--panel);border-bottom:1px solid var(--line);flex-wrap:wrap}
header b{color:var(--accent);font-size:18px;letter-spacing:.5px}header span{color:var(--dim);margin-left:auto}
main{max-width:920px;margin:0 auto;padding:16px}
button,input,select{font:inherit;color:var(--text)}
input,select{background:#0c0c1a;border:1px solid var(--line);border-radius:6px;padding:8px 10px;min-width:0}
button{background:var(--panel2);border:1px solid var(--line);border-radius:6px;padding:8px 12px;cursor:pointer}
button.p{background:var(--accent);border-color:var(--accent);font-weight:600}button.d{border-color:var(--danger);color:var(--danger)}
button:disabled{opacity:.5;cursor:default}
nav{display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap}nav button.on{background:var(--accent);border-color:var(--accent)}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px;margin:10px 0}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.grow{flex:1}
.dim{color:var(--dim)}.tag{display:inline-block;border-radius:5px;padding:1px 7px;font-size:12px;margin-left:6px;background:var(--panel2)}
.tag.b{background:#4a1626;color:#ff8da1}.tag.m{background:#3b3010;color:#ffd666}.tag.s{background:#1d2e55;color:var(--cyan)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}.stats div{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px}
.stats b{display:block;font-size:22px}
#msg{min-height:22px;margin:8px 0;color:var(--cyan)}#msg.err{color:var(--danger)}
.hide{display:none}h2{margin:18px 0 6px;font-size:16px}
</style></head><body>
<header><b>NEXORA STAFF</b><span id="who"></span><button id="out" class="hide">Sign out</button></header>
<main>
<div id="login" class="card hide"><h2 style="margin-top:0">Sign in</h2>
<form id="lf" class="row"><input id="u" placeholder="Username" autocomplete="username" maxlength="20"><input id="p" type="password" placeholder="Password" autocomplete="current-password" maxlength="128"><button class="p">Sign in</button></form></div>
<div id="msg"></div>
<div id="app" class="hide">
<div class="stats" id="stats"></div>
<nav id="tabs"></nav>
<section id="t-users"><div class="row"><input id="q" class="grow" placeholder="Search a username" maxlength="20"><button id="qb" class="p">Search</button></div><div id="ulist"></div></section>
<section id="t-rest" class="hide"><div id="rlist"></div></section>
<section id="t-notice" class="hide"><div class="card"><p class="dim" style="margin-top:0">Shown as a banner at the top of the Nexora launcher. Leave empty to clear it.</p>
<div class="row"><input id="ntext" class="grow" maxlength="200" placeholder="Announcement"><button id="nsave" class="p">Post</button></div></div></section>
<section id="t-log" class="hide"><div id="llist"></div></section>
<section id="t-checks" class="hide"><div class="card"><div class="row"><button id="wtest" class="p">Send test to both Discord webhooks</button><span id="wres" class="dim"></span></div><p class="dim" style="margin-bottom:0">Every modified-client check the server received, and what it decided. If nothing shows up here after a player signs in, the app is not sending checks.</p></div><div id="clist"></div></section>
</div></main>
<script>
(function(){
var tok=null,me=null,$=function(i){return document.getElementById(i)};
try{tok=sessionStorage.getItem("nx_admin")}catch(e){}
function el(tag,cls,text){var e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e}
function say(t,err){var m=$("msg");m.textContent=t||"";m.className=err?"err":""}
async function api(method,path,body){
  var r=await fetch(path,{method:method,headers:Object.assign({"content-type":"application/json"},tok?{Authorization:"Bearer "+tok}:{}),body:body?JSON.stringify(body):undefined});
  var d={};try{d=await r.json()}catch(e){}
  if(!r.ok||d.ok===false){if(r.status===401&&tok&&path!=="/api/login")signOut();throw new Error(d.error||("Error "+r.status))}
  return d}
function when(u){return u===0?"permanent":"until "+new Date(u*1000).toLocaleString()}
function signOut(){tok=null;try{sessionStorage.removeItem("nx_admin")}catch(e){}start()}
$("out").onclick=function(){api("POST","/api/logout",{}).catch(function(){});signOut()};
$("lf").onsubmit=async function(ev){ev.preventDefault();say("");
  try{var d=await api("POST","/api/login",{username:$("u").value.trim(),password:$("p").value});
    if(!d.user.staff){say("That account isn't staff.",true);api("POST","/api/logout",{}).catch(function(){});tok=null;return}
    tok=d.token;try{sessionStorage.setItem("nx_admin",tok)}catch(e){}$("p").value="";start()}catch(e){say(e.message,true)}};
var tabs=[["users","Users"],["rest","Bans & mutes"],["notice","Announcement"],["log","Log"],["checks","Client checks"]],cur="users";
function showTab(k){cur=k;tabs.forEach(function(t){$("t-"+t[0]).classList.toggle("hide",t[0]!==k)});
  Array.prototype.forEach.call($("tabs").children,function(b){b.classList.toggle("on",b.dataset.k===k)});
  if(k==="users")loadUsers();if(k==="rest")loadRest();if(k==="log")loadLog();if(k==="checks")loadChecks();if(k==="notice")loadStats()}
async function loadStats(){try{var s=await api("GET","/api/admin/overview");var box=$("stats");box.textContent="";
  [["Accounts",s.users],["Games",s.games],["Playing now",s.online],["Active bans",s.bans],["Active mutes",s.mutes]].forEach(function(x){var d=el("div");d.appendChild(el("b",0,String(x[1])));d.appendChild(el("span","dim",x[0]));box.appendChild(d)});
  $("ntext").value=s.notice||""}catch(e){say(e.message,true)}}
async function act(path,body,done){say("");try{await api("POST","/api/admin/"+path,body);say("Done.");loadStats();if(done)done()}catch(e){say(e.message,true)}}
var DUR=[["10 minutes",10],["1 hour",60],["1 day",1440],["7 days",10080],["30 days",43200],["Permanent",0]];
function durSelect(){var s=el("select");DUR.forEach(function(d){var o=el("option",0,d[0]);o.value=d[1];s.appendChild(o)});s.value="1440";return s}
function userCard(u){var c=el("div","card"),top=el("div","row"),n=el("b",0,u.name);top.appendChild(n);
  if(u.staff)top.appendChild(el("span","tag s","staff"));
  if(u.ban)top.appendChild(el("span","tag b","banned "+when(u.ban.until)));
  if(u.mute)top.appendChild(el("span","tag m","muted "+when(u.mute.until)));
  top.appendChild(el("span","dim",u.balance.toLocaleString()+" Nexei \\u00b7 "+u.games+" game"+(u.games===1?"":"s")+" \\u00b7 joined "+new Date(u.created*1000).toLocaleDateString()));c.appendChild(top);
  if(u.staff)return c;
  var reason=el("input","grow");reason.placeholder="Reason (optional)";reason.maxLength=200;
  var dur=durSelect(),row=el("div","row");row.style.marginTop="8px";row.appendChild(dur);row.appendChild(reason);c.appendChild(row);
  var b=el("div","row");b.style.marginTop="8px";
  function btn(t,cls,fn){var x=el("button",cls,t);x.onclick=fn;b.appendChild(x)}
  var after=function(){loadUsers()};
  btn(u.ban?"Unban":"Ban","d",function(){u.ban?act("unban",{user:u.name,reason:reason.value},after):act("ban",{user:u.name,minutes:+dur.value,reason:reason.value},after)});
  btn(u.mute?"Unmute":"Mute","",function(){u.mute?act("unmute",{user:u.name,reason:reason.value},after):act("mute",{user:u.name,minutes:+dur.value,reason:reason.value},after)});
  btn("Kick","",function(){act("kick",{user:u.name,reason:reason.value},after)});
  var amt=el("input");amt.type="number";amt.placeholder="Nexei";amt.style.width="110px";b.appendChild(amt);
  btn("Give / take","",function(){if(+amt.value)act("nexei",{user:u.name,amount:+amt.value,reason:reason.value},after)});
  btn("Delete account","d",function(){var t=prompt("This permanently deletes "+u.name+" and their games. Type the username to confirm:");if(t)act("delete",{user:u.name,confirm:t,reason:reason.value},after)});
  c.appendChild(b);return c}
async function loadUsers(){try{var d=await api("GET","/api/admin/users?q="+encodeURIComponent($("q").value.trim()));var l=$("ulist");l.textContent="";
  if(!d.users.length)l.appendChild(el("p","dim","No accounts found."));d.users.forEach(function(u){l.appendChild(userCard(u))})}catch(e){say(e.message,true)}}
$("qb").onclick=loadUsers;$("q").onkeydown=function(e){if(e.key==="Enter")loadUsers()};
async function loadRest(){try{var d=await api("GET","/api/admin/restrictions");var l=$("rlist");l.textContent="";
  [["Bans",d.bans,"unban"],["Mutes",d.mutes,"unmute"]].forEach(function(sec){l.appendChild(el("h2",0,sec[0]));
    if(!sec[1].length)l.appendChild(el("p","dim","None."));
    sec[1].forEach(function(r){var c=el("div","card row");c.appendChild(el("b",0,r.user));
      c.appendChild(el("span","dim",when(r.until)+(r.reason?" \\u00b7 "+r.reason:"")+" \\u00b7 by "+r.by));
      var x=el("button","",sec[2]==="unban"?"Unban":"Unmute");x.style.marginLeft="auto";x.onclick=function(){act(sec[2],{user:r.user},loadRest)};c.appendChild(x);l.appendChild(c)})})}catch(e){say(e.message,true)}}
$("nsave").onclick=function(){act("notice",{text:$("ntext").value})};
async function loadLog(){try{var d=await api("GET","/api/admin/log");var l=$("llist");l.textContent="";if(!d.log.length)l.appendChild(el("p","dim","Nothing yet."));
  d.log.forEach(function(r){var c=el("div","card");c.appendChild(el("span","dim",new Date(r.at*1000).toLocaleString()+" \\u00b7 "));
    c.appendChild(el("b",0,r.staff));c.appendChild(el("span",0," "+r.action+" "));if(r.target)c.appendChild(el("b",0,r.target));
    if(r.detail)c.appendChild(el("span","dim"," ("+r.detail+")"));l.appendChild(c)})}catch(e){say(e.message,true)}}
async function loadChecks(){try{var d=await api("GET","/api/admin/checks");var l=$("clist");l.textContent="";
  $("wres").textContent="Webhooks set: hack reports "+(d.hooks.tamper?"yes":"NO")+", mod logs "+(d.hooks.mod?"yes":"NO");
  if(!d.checks.length)l.appendChild(el("p","dim","No checks received yet."));
  d.checks.forEach(function(r){var c=el("div","card");c.appendChild(el("span","dim",new Date(r.at*1000).toLocaleString()+" \u00b7 "));
    c.appendChild(el("b",0,r.user));c.appendChild(el("span","dim"," on "+r.version+" \u00b7 "));
    var bad=r.result.indexOf("modified")===0;c.appendChild(el("span",bad?"tag b":"tag",r.result));l.appendChild(c)})}catch(e){say(e.message,true)}}
$("wtest").onclick=async function(){try{var d=await api("POST","/api/admin/webhook-test",{});$("wres").textContent="Hack reports: "+d.tamper+" \u00b7 Mod logs: "+d.mod}catch(e){say(e.message,true)}};
async function start(){
  if(!tok){$("login").classList.remove("hide");$("app").classList.add("hide");$("out").classList.add("hide");$("who").textContent="";return}
  try{var d=await api("GET","/api/me");if(!d.user.staff)throw new Error("That account isn't staff.");me=d.user;
    $("login").classList.add("hide");$("app").classList.remove("hide");$("out").classList.remove("hide");$("who").textContent=me.username;
    if(!$("tabs").children.length)tabs.forEach(function(t){var b=el("button","",t[1]);b.dataset.k=t[0];b.onclick=function(){say("");showTab(t[0])};$("tabs").appendChild(b)});
    showTab(cur);loadStats()}catch(e){say(e.message,true);tok=null;$("login").classList.remove("hide");$("app").classList.add("hide")}}
start();
})();
</script></body></html>`;
