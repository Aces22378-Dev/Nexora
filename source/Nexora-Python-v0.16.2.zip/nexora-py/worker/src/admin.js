// Staff tools: ban, timed ban, mute, kick, Nexei, announcement, delete account, and an audit log.
// Everything here checks that the signed-in user is staff on the server; the /admin page is only a front end.
import { now } from "./util.js";

export const MOD_TABLES = [
  "CREATE TABLE IF NOT EXISTS bans (user TEXT PRIMARY KEY COLLATE NOCASE, until INTEGER, reason TEXT, by TEXT, at INTEGER)",
  "CREATE TABLE IF NOT EXISTS mutes (user TEXT PRIMARY KEY COLLATE NOCASE, until INTEGER, reason TEXT, by TEXT, at INTEGER)",
  "CREATE TABLE IF NOT EXISTS modlog (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, staff TEXT, action TEXT, target TEXT, detail TEXT)",
  "CREATE TABLE IF NOT EXISTS notice (id INTEGER PRIMARY KEY CHECK (id = 1), text TEXT, by TEXT, at INTEGER)",
  "CREATE TABLE IF NOT EXISTS checks (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, user TEXT, version TEXT, result TEXT)",
];

const NAME_RE = /^[A-Za-z0-9_]{3,20}$/;
const MAX_MINUTES = 60 * 24 * 365 * 5;
const cleanReason = (s) => Array.from(String(s ?? "")).filter((ch) => !/[\p{C}]/u.test(ch)).join("").trim().slice(0, 200);

export function untilText(until) {
  return until === 0 ? "permanently" : "until " + new Date(until * 1000).toISOString().replace("T", " ").slice(0, 16) + " UTC";
}
export function banMessage(row) {
  return `You are banned ${untilText(row.until)}.` + (row.reason ? ` Reason: ${row.reason}` : "");
}
export const activeBan = (c, name) => c.first("SELECT * FROM bans WHERE user = ? AND (until = 0 OR until > ?)", name, now());
export const activeMute = (c, name) => c.first("SELECT * FROM mutes WHERE user = ? AND (until = 0 OR until > ?)", name, now());

// Remove an account and what hangs off it. Their published games go too; items they made stay in the shop
// (for the people who bought them) under a neutral creator name.
export async function deleteAccount(c, name) {
  const games = (await c.all("SELECT id FROM games WHERE owner = ? AND data IS NOT NULL", name)).map((g) => g.id);
  const stmts = [];
  for (const id of games) {
    stmts.push(c.q("DELETE FROM likes WHERE game = ?", id), c.q("DELETE FROM plays WHERE game = ?", id),
                c.q("DELETE FROM items WHERE kind = 'pass' AND game = ?", id), c.q("DELETE FROM rooms WHERE game = ?", id),
                c.q("DELETE FROM games WHERE id = ?", id));
  }
  stmts.push(
    c.q("DELETE FROM items WHERE creator = ? AND COALESCE(status,'approved') != 'approved'", name),
    c.q("UPDATE items SET creator = 'deleted_user' WHERE creator = ?", name),
    c.q("DELETE FROM likes WHERE user = ?", name), c.q("DELETE FROM plays WHERE user = ?", name),
    c.q("DELETE FROM purchases WHERE user = ?", name), c.q("DELETE FROM tokens WHERE user = ?", name),
    c.q("DELETE FROM bans WHERE user = ?", name), c.q("DELETE FROM mutes WHERE user = ?", name),
    c.q("DELETE FROM users WHERE name = ?", name));
  await c.db.batch(stmts);
  return games.length;
}

// What the server decided about each modified-client check, so staff can see why a report did or didn't happen.
export async function noteCheck(c, user, version, result) {
  try {
    await c.run("INSERT INTO checks (at, user, version, result) VALUES (?, ?, ?, ?)", now(), user, String(version ?? "").slice(0, 30), result);
    await c.run("DELETE FROM checks WHERE id < (SELECT MAX(id) FROM checks) - 200");
  } catch { /* never get in the way */ }
}

export function makeAdmin({ ok, fail, bad, kickEverywhere, report }) {
  async function staff(c) {
    const u = await c.me();
    if (!c.isStaff(u.name)) bad(403, "Staff only.");
    return u;
  }
  async function target(c, d, { allowStaff = false, allowSelf = false } = {}) {
    const name = String(d.user ?? "").trim();
    if (!NAME_RE.test(name)) bad(400, "Type a username (letters, numbers, underscores).");
    const row = await c.first("SELECT name, balance FROM users WHERE name = ?", name);
    if (!row) bad(404, "No account with that name.");
    if (!allowStaff && c.isStaff(row.name)) bad(400, "Staff accounts can't be moderated.");
    return row;
  }
  // The audit log keeps a short sentence; the Discord post uses the staff format (punishment, moderator, affected, reason, notes).
  async function log(c, me, action, targetName, detail = "", rep = null) {
    await c.run("INSERT INTO modlog (at, staff, action, target, detail) VALUES (?, ?, ?, ?, ?)", now(), me.name, action, targetName ?? "", detail);
    await c.run("DELETE FROM modlog WHERE id < (SELECT MAX(id) FROM modlog) - 2000");
    if (rep) report(c, `Punishment: ${rep.punishment}\nModerator: ${me.name}\nAffected: ${targetName}\nReason: ${rep.reason || "None given"}\nNotes: ${rep.notes || "None"}`);
  }
  const minutesOf = (d) => {
    const m = Math.floor(Number(d.minutes));
    if (!Number.isFinite(m) || m < 0 || m > MAX_MINUTES) bad(400, "Pick how long.");
    return m;
  };
  const untilFor = (m) => (m === 0 ? 0 : now() + m * 60);
  const length = (m) => (m === 0 ? "permanent" : m >= 1440 ? `${Math.round(m / 1440)}d` : m >= 60 ? `${Math.round(m / 60)}h` : `${m}m`);
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  const words = (m) => (m === 0 ? "Permanent" : m >= 1440 ? plural(Math.round(m / 1440), "day") : m >= 60 ? plural(Math.round(m / 60), "hour") : plural(m, "minute"));

  return {
    async overview(c) {
      await staff(c);
      const n = (sql, ...p) => c.first(sql, ...p).then((r) => r.n ?? 0);
      return ok({
        users: await n("SELECT COUNT(*) AS n FROM users"), games: await n("SELECT COUNT(*) AS n FROM games WHERE data IS NOT NULL"),
        online: await n("SELECT COALESCE(SUM(players),0) AS n FROM rooms WHERE updated > ?", now() - 90),
        bans: await n("SELECT COUNT(*) AS n FROM bans WHERE until = 0 OR until > ?", now()),
        mutes: await n("SELECT COUNT(*) AS n FROM mutes WHERE until = 0 OR until > ?", now()),
        notice: (await c.first("SELECT text FROM notice WHERE id = 1"))?.text ?? "",
      });
    },
    async users(c) {
      await staff(c);
      const q = (c.url.searchParams.get("q") || "").trim().replace(/[%_\\]/g, "").slice(0, 20);
      const rows = await c.all("SELECT name, created, balance FROM users WHERE name LIKE ? ORDER BY created DESC LIMIT 30", `%${q}%`);
      const out = [];
      for (const r of rows) {
        const ban = await activeBan(c, r.name), mute = await activeMute(c, r.name);
        out.push({ name: r.name, created: r.created, balance: r.balance || 0, staff: c.isStaff(r.name),
                   games: (await c.first("SELECT COUNT(*) AS n FROM games WHERE owner = ? AND data IS NOT NULL", r.name)).n,
                   ban: ban && { until: ban.until, reason: ban.reason, by: ban.by }, mute: mute && { until: mute.until, reason: mute.reason, by: mute.by } });
      }
      return ok({ users: out });
    },
    async restrictions(c) {
      await staff(c);
      const t = now();
      return ok({ bans: await c.all("SELECT user, until, reason, by, at FROM bans WHERE until = 0 OR until > ? ORDER BY at DESC", t),
                  mutes: await c.all("SELECT user, until, reason, by, at FROM mutes WHERE until = 0 OR until > ? ORDER BY at DESC", t) });
    },
    async ban(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d), m = minutesOf(d), reason = cleanReason(d.reason);
      await c.run("INSERT OR REPLACE INTO bans (user, until, reason, by, at) VALUES (?, ?, ?, ?, ?)", u.name, untilFor(m), reason, me.name, now());
      await kickEverywhere(c, u.name, "You were banned.");   // sessions stay, but every request is refused while the ban lasts
      await log(c, me, "banned", u.name, `${length(m)}${reason ? ", " + reason : ""}`, { punishment: m === 0 ? "Ban" : "Temporary Ban", reason, notes: `(${m === 0 ? "Permanent" : "Duration: " + words(m)})` });
      return ok();
    },
    async unban(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d, { allowStaff: true });
      await c.run("DELETE FROM bans WHERE user = ?", u.name);
      await log(c, me, "unbanned", u.name, "", { punishment: "Unban", reason: cleanReason(d.reason) });
      return ok();
    },
    async mute(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d), m = minutesOf(d), reason = cleanReason(d.reason);
      await c.run("INSERT OR REPLACE INTO mutes (user, until, reason, by, at) VALUES (?, ?, ?, ?, ?)", u.name, untilFor(m), reason, me.name, now());
      await log(c, me, "muted", u.name, `${length(m)}${reason ? ", " + reason : ""}`, { punishment: "Mute", reason, notes: `(${m === 0 ? "Permanent" : "Duration: " + words(m)})` });
      return ok();
    },
    async unmute(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d, { allowStaff: true });
      await c.run("DELETE FROM mutes WHERE user = ?", u.name);
      await log(c, me, "unmuted", u.name, "", { punishment: "Unmute", reason: cleanReason(d.reason) });
      return ok();
    },
    async kick(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d);
      const n = await kickEverywhere(c, u.name, "You were removed from the server by staff.");
      await log(c, me, "kicked", u.name, n ? "" : "not in a server", { punishment: "Kick", reason: cleanReason(d.reason), notes: n ? "(Removed from a live server)" : "(Was not in a server)" });
      return ok({ kicked: n });
    },
    async nexei(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d);
      const amt = Math.trunc(Number(d.amount));
      if (!Number.isFinite(amt) || amt === 0 || Math.abs(amt) > 1000000) bad(400, "Amount must be between -1,000,000 and 1,000,000.");
      await c.run("UPDATE users SET balance = MAX(0, COALESCE(balance, 0) + ?) WHERE name = ?", amt, u.name);
      await log(c, me, amt > 0 ? "gave Nexei to" : "took Nexei from", u.name, String(Math.abs(amt)), { punishment: amt > 0 ? "Nexei Given" : "Nexei Taken", reason: cleanReason(d.reason), notes: `(${Math.abs(amt).toLocaleString("en-US")} Nexei)` });
      return ok();
    },
    async remove(c) {
      const me = await staff(c), d = await c.body(), u = await target(c, d);
      if (String(d.confirm ?? "").toLowerCase() !== u.name.toLowerCase()) bad(400, "Type the username again to confirm.");
      await kickEverywhere(c, u.name, "This account was deleted.");
      const games = await deleteAccount(c, u.name);
      await log(c, me, "deleted the account of", u.name, `${plural(games, "game")} removed`, { punishment: "Account Deletion", reason: cleanReason(d.reason), notes: `(${plural(games, "game")} removed)` });
      return ok();
    },
    async setNotice(c) {
      const me = await staff(c), d = await c.body(), text = Array.from(String(d.text ?? "")).filter((ch) => !/[\p{C}]/u.test(ch)).join("").trim().slice(0, 200);
      if (text) await c.run("INSERT OR REPLACE INTO notice (id, text, by, at) VALUES (1, ?, ?, ?)", text, me.name, now());
      else await c.run("DELETE FROM notice WHERE id = 1");
      await log(c, me, text ? "posted an announcement" : "cleared the announcement", "", text);   // admin log only, not a punishment
      return ok();
    },
    async log(c) {
      await staff(c);
      return ok({ log: await c.all("SELECT at, staff, action, target, detail FROM modlog ORDER BY id DESC LIMIT 100") });
    },
    async checks(c) {
      await staff(c);
      return ok({ checks: await c.all("SELECT at, user, version, result FROM checks ORDER BY id DESC LIMIT 60"),
                  hooks: { tamper: !!c.env.NEXORA_TAMPER_WEBHOOK, mod: !!c.env.NEXORA_MOD_WEBHOOK } });
    },
    async webhookTest(c) { // really send a test message and report what Discord answered
      const me = await staff(c), out = {};
      for (const [key, secret, what] of [["tamper", "NEXORA_TAMPER_WEBHOOK", "hack reports"], ["mod", "NEXORA_MOD_WEBHOOK", "mod logs"]]) {
        const hook = c.env[secret] || "";
        if (!hook) { out[key] = "not set"; continue; }
        try {
          const r = await fetch(hook, { method: "POST", headers: { "content-type": "application/json" },
            body: JSON.stringify({ content: `Webhook test (${what}) from ${me.name}`, allowed_mentions: { parse: [] } }) });
          out[key] = r.ok ? "ok" : `Discord answered ${r.status}`;
        } catch { out[key] = "couldn't reach Discord"; }
      }
      return ok(out);
    },
    async notice(c) { // public: the launcher shows it as a banner
      return ok({ text: (await c.first("SELECT text FROM notice WHERE id = 1"))?.text ?? "" });
    },
  };
}
