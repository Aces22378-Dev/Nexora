"""Settings page (mixed into App in main.py). Every control here saves to the account immediately."""
import os
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox, simpledialog

import accounts
import online
import theme as th
from widgets import ScrollFrame

VERSION = "0.1"

CATEGORIES = [
    ("account", "Account", "Username, password, email, and login security"),
    ("privacy", "Privacy & Safety", "Who can find, friend, or see you"),
    ("communication", "Communication", "Chat permissions, friend requests, and notifications"),
    ("notifications", "Notifications", "Game invites, updates, and creator announcements"),
    ("gameplay", "Gameplay", "Graphics, controls, sound, and performance"),
    ("appearance", "Appearance", "Themes, interface, and accessibility"),
    ("payments", "Payments & Nexora Coins", "Purchase history, spending limits, and refunds"),
    ("connections", "Friends & Connections", "Blocked users, friends, and followers"),
    ("parental", "Parental Controls", "Family-approved communication and spending limits"),
    ("help", "Help & Support", "Report a problem, appeal a moderation action, and get help"),
    ("danger", "Deactivate or Delete Account", "Manage your account's future"),
]
TITLES = {k: t for k, t, _ in CATEGORIES}


class SettingsMixin:
    settings_cat = "account"

    # ---------- page frame ----------
    def page_settings(self):
        name = self.user["username"]
        tk.Label(self.body, text="Nexora - User Settings", bg=th.BG, fg=th.TEXT,
                 font=(th.FONT, 18, "bold")).pack(anchor="w")
        tk.Label(self.body, text="Your Nexora account", bg=th.BG, fg=th.DIM, font=(th.FONT, 10)).pack(anchor="w")
        self.settings_crumb = tk.Label(self.body, text="", bg=th.BG, fg=th.CYAN, font=(th.FONT, 10))
        self.settings_crumb.pack(anchor="w", pady=(0, 8))
        wrap = tk.Frame(self.body, bg=th.BG)
        wrap.pack(fill="both", expand=True)
        nav = tk.Frame(wrap, bg=th.PANEL, highlightthickness=1, highlightbackground=th.LINE)
        nav.pack(side="left", fill="y", padx=(0, 16))
        self.cat_buttons = {}
        for key, title, sub in CATEGORIES:
            b = tk.Button(nav, text=title, anchor="w", relief="flat", bd=0, cursor="hand2", padx=14, pady=7,
                          font=(th.FONT, 10, "bold"), width=26, command=lambda k=key: self.show_settings_cat(k))
            b.pack(fill="x")
            self.cat_buttons[key] = b
        self.settings_scroll = ScrollFrame(wrap)
        self.settings_scroll.pack(side="left", fill="both", expand=True)
        self.show_settings_cat(self.settings_cat)

    def show_settings_cat(self, key):
        self.settings_cat = key
        name = self.user["username"]
        self.settings_crumb.configure(text=f"@{name}  ·  {TITLES[key]}")
        for k, b in self.cat_buttons.items():
            on = k == key
            b.configure(bg=th.ACCENT if on else th.PANEL, fg=th.ON_ACCENT if on else th.TEXT,
                        activebackground=th.ACCENT if on else th.PANEL2,
                        activeforeground=th.ON_ACCENT if on else th.TEXT)
        host = self.settings_scroll.inner
        for w in host.winfo_children():
            w.destroy()
        self.cfg = accounts.get_settings(name)
        sub = next(s for k, _, s in CATEGORIES if k == key)
        box = tk.Frame(host, bg=th.BG, padx=4)
        box.pack(fill="both", expand=True)
        tk.Label(box, text=TITLES[key], bg=th.BG, fg=th.TEXT, font=(th.FONT, 15, "bold")).pack(anchor="w")
        tk.Label(box, text=sub, bg=th.BG, fg=th.DIM, font=(th.FONT, 10)).pack(anchor="w", pady=(0, 8))
        self.sbox = box
        getattr(self, f"set_{key}")()

    # ---------- building blocks ----------
    def s_card(self, title=None):
        card = tk.Frame(self.sbox, bg=th.PANEL, padx=16, pady=12, highlightthickness=1, highlightbackground=th.LINE)
        card.pack(fill="x", pady=6)
        if title:
            tk.Label(card, text=title, bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11, "bold")).pack(anchor="w", pady=(0, 6))
        return card

    def s_note(self, parent, text, color=None):
        tk.Label(parent, text=text, bg=th.PANEL, fg=color or th.DIM, font=(th.FONT, 10), wraplength=560,
                 justify="left", anchor="w").pack(fill="x", pady=(2, 0))

    def s_msg(self, parent):
        lbl = tk.Label(parent, text="", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 10), anchor="w")
        lbl.pack(fill="x", pady=(4, 0))
        return lbl

    def need_pin(self):
        """(ok, pin). Asks for the parental PIN only when one is set."""
        if not accounts.parental_status(self.user["username"])["enabled"]:
            return True, None
        pin = simpledialog.askstring("Parental PIN", "Enter the parental PIN:", show="*", parent=self)
        if pin is None:
            return False, None
        if not accounts.parental_check(self.user["username"], pin):
            messagebox.showerror("Parental PIN", "That PIN is wrong.", parent=self)
            return False, None
        return True, pin

    def save_setting(self, key, value) -> bool:
        ok, pin = self.need_pin() if key in accounts.LOCKED_KEYS else (True, None)
        res = accounts.set_settings(self.user["username"], {key: value}, pin=pin) if ok else {"ok": False}
        if not res["ok"]:
            if ok:
                self.set_status(res.get("error", "Couldn't save that setting."))
            self.show_settings_cat(self.settings_cat)  # put the control back to the saved value
            return False
        self.cfg = res["settings"]
        self.set_status("Saved.")
        return True

    def s_toggle(self, parent, key, label, desc=""):
        var = tk.BooleanVar(value=bool(self.cfg[key]))
        tk.Checkbutton(parent, text=label, variable=var, bg=th.PANEL, fg=th.TEXT, selectcolor=th.PANEL2,
                       activebackground=th.PANEL, activeforeground=th.TEXT, font=(th.FONT, 11), anchor="w",
                       command=lambda: self.save_setting(key, var.get())).pack(fill="x")
        if desc:
            self.s_note(parent, desc)

    def s_choice(self, parent, key, options, after=None):
        var = tk.StringVar(value=str(self.cfg[key]))
        row = tk.Frame(parent, bg=th.PANEL)
        row.pack(fill="x")

        def pick():
            if self.save_setting(key, var.get()) and after:
                after()
        for value, text in options:
            tk.Radiobutton(row, text=text, value=value, variable=var, bg=th.PANEL, fg=th.TEXT,
                           selectcolor=th.PANEL2, activebackground=th.PANEL, activeforeground=th.TEXT,
                           font=(th.FONT, 11), command=pick).pack(side="left", padx=(0, 16))

    def s_slider(self, parent, key, label, lo, hi, unit=""):
        row = tk.Frame(parent, bg=th.PANEL)
        row.pack(fill="x", pady=4)
        tk.Label(row, text=label, bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11), width=22, anchor="w").pack(side="left")
        sc = tk.Scale(row, from_=lo, to=hi, orient="horizontal", length=240, bg=th.PANEL, fg=th.TEXT,
                      troughcolor=th.PANEL2, highlightthickness=0, activebackground=th.ACCENT, bd=0,
                      font=(th.FONT, 9))
        sc.set(self.cfg[key])
        sc.pack(side="left")
        tk.Label(row, text=unit, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 10)).pack(side="left", padx=6)
        sc.bind("<ButtonRelease-1>", lambda e: self.save_setting(key, int(sc.get())))
        sc.bind("<KeyRelease>", lambda e: self.save_setting(key, int(sc.get())))

    def s_field(self, parent, label, show=None, value=""):
        tk.Label(parent, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 10), anchor="w").pack(fill="x")
        e = self.entry(parent, show=show)
        e.pack(fill="x", ipady=5, pady=(1, 8))
        if value:
            e.insert(0, value)
        return e

    # ---------- categories ----------
    def set_account(self):
        name = self.user["username"]
        c = self.s_card("Email")
        email = self.s_field(c, "Email address (optional, kept on this PC only)", value=self.cfg["email"])
        msg = self.s_msg(c)

        def save_email():
            res = accounts.set_settings(name, {"email": email.get().strip()})
            msg.configure(text="Saved." if res["ok"] else "That doesn't look like an email address.",
                          fg=th.CYAN if res["ok"] else th.DANGER)
        self.button(c, "Save email", save_email).pack(anchor="w")

        if online.enabled():
            c = self.s_card("Your online account")
            self.s_note(c, f"You're signed in to {online.server_url()} as @{name}. Changing the username or "
                           "password online isn't available yet. Friends, blocks and settings are still kept on this PC.")
            return
        c = self.s_card("Change username")
        self.s_note(c, f"You are @{name}. Your friends and blocked lists follow you to the new name.")
        new_name = self.s_field(c, "New username")
        pw = self.s_field(c, "Your password", show="•")
        msg = self.s_msg(c)

        def rename():
            res = accounts.change_username(name, pw.get(), new_name.get())
            if not res["ok"]:
                msg.configure(text=res["error"], fg=th.DANGER)
                return
            self.user = res["user"]
            self.show_home(self.user, page="settings")
            self.set_status(f"You are now @{self.user['username']}.")
        self.button(c, "Change username", rename).pack(anchor="w")

        c = self.s_card("Change password")
        old = self.s_field(c, "Current password", show="•")
        new = self.s_field(c, "New password (6+ characters)", show="•")
        new2 = self.s_field(c, "Repeat new password", show="•")
        msg = self.s_msg(c)

        def change_pw():
            if new.get() != new2.get():
                msg.configure(text="The new passwords don't match.", fg=th.DANGER)
                return
            res = accounts.change_password(name, old.get(), new.get())
            msg.configure(text="Password changed." if res["ok"] else res["error"],
                          fg=th.CYAN if res["ok"] else th.DANGER)
            if res["ok"]:
                for e in (old, new, new2):
                    e.delete(0, "end")
        self.button(c, "Change password", change_pw).pack(anchor="w")

        c = self.s_card("Login security")
        self.s_note(c, "Passwords are hashed with scrypt and stored only on this PC. Two-step verification and "
                       "sign-in alerts need online accounts, which Nexora doesn't have yet.")
        self.button(c, "Log out", self.do_logout).pack(anchor="w", pady=(8, 0))

    def set_privacy(self):
        c = self.s_card("Who can see your play stats")
        self.s_note(c, "Your plays and friend count on your profile.")
        self.s_choice(c, "profile_stats", [("everyone", "Everyone"), ("friends", "Friends only"),
                                           ("nobody", "Only me")])
        c = self.s_card("Finding you")
        self.s_toggle(c, "searchable", "Show me in user search",
                      "Turn this off and people can't find you by searching. They can still see your profile "
                      "if they already know your name.")
        c = self.s_card("Safety")
        self.s_note(c, "You can block anyone from Friends & Connections. Blocked users can't find you, message "
                       "you or friend you, and you won't see each other in games.")
        if accounts.parental_status(self.user["username"])["enabled"]:
            self.s_note(c, "Parental controls are on, so changing these settings needs the PIN.", th.CYAN)

    def set_communication(self):
        c = self.s_card("Friend requests")
        self.s_note(c, "Who can send you friend requests.")
        self.s_choice(c, "friend_requests", [("everyone", "Everyone"), ("nobody", "Nobody")])
        c = self.s_card("Chat")
        self.s_note(c, "In-game text chat on servers (press Enter in a game to type). Blocked players are always hidden. "
                       "There's no word filter or moderation yet, so choose carefully. Voice chat doesn't exist.")
        self.s_choice(c, "chat", [("everyone", "Everyone"), ("friends", "Friends only"), ("off", "Off")])
        c = self.s_card("Notifications")
        self.s_note(c, "Friend request badges are in Notifications.")

    def set_notifications(self):
        c = self.s_card("Friend requests")
        self.s_toggle(c, "notify_requests", "Show a badge on People when I have friend requests")
        c = self.s_card("Game invites, updates and creator announcements")
        self.s_note(c, "These need online accounts and Nexora Studio, which don't exist yet, so nothing is sent. "
                       "Their switches will appear here once they do.")

    def set_gameplay(self):
        c = self.s_card("Graphics and performance")
        self.s_toggle(c, "fullscreen", "Start games in fullscreen")
        self.s_toggle(c, "vsync", "Vertical sync (smoother, caps frame rate to your screen)")
        self.s_toggle(c, "show_fps", "Show frames per second in games")
        self.s_slider(c, "fov", "Field of view", 60, 110, "degrees")
        c = self.s_card("Controls and camera")
        self.s_slider(c, "mouse_sens", "Mouse sensitivity", 10, 100, "(50 = default)")
        self.s_toggle(c, "invert_y", "Invert vertical look")
        self.s_slider(c, "cam_distance", "Camera distance", 4, 16, "(scroll wheel adjusts in game)")
        c = self.s_card("Games from other creators")
        self.s_toggle(c, "online_scripts", "Run scripts from other creators' games",
                      "Off (recommended): other people's games load without their scripts. Scripts are Python code "
                      "that runs on your PC with only a basic guard, not a real sandbox. Turn this on only if you "
                      "trust the creators. Your own games always run their scripts.")
        c = self.s_card("Sound")
        self.s_note(c, "Nexora's games have no sound yet, so there is nothing to adjust.")
        self.s_note(c, "Gameplay changes apply the next time you start a game.", th.CYAN)

    def set_appearance(self):
        c = self.s_card("Theme")
        var = tk.StringVar(value=self.cfg["theme"])
        for name in accounts.THEME_NAMES:
            t = th.THEMES[name]
            row = tk.Frame(c, bg=th.PANEL)
            row.pack(fill="x", pady=2)
            tk.Radiobutton(row, text={"contrast": "High contrast"}.get(name, name.capitalize()), value=name,
                           variable=var, bg=th.PANEL, fg=th.TEXT, selectcolor=th.PANEL2, width=14, anchor="w",
                           activebackground=th.PANEL, activeforeground=th.TEXT, font=(th.FONT, 11),
                           command=lambda: self.pick_appearance("theme", var.get())).pack(side="left")
            for col in (t["BG"], t["PANEL2"], t["ACCENT"], t["TEXT"]):
                tk.Frame(row, bg=col, width=26, height=18, highlightthickness=1,
                         highlightbackground=th.LINE).pack(side="left", padx=2)
        c = self.s_card("Text size")
        size = tk.StringVar(value=self.cfg["text_size"])
        row = tk.Frame(c, bg=th.PANEL)
        row.pack(fill="x")
        for value, text in (("small", "Small"), ("normal", "Normal"), ("large", "Large")):
            tk.Radiobutton(row, text=text, value=value, variable=size, bg=th.PANEL, fg=th.TEXT,
                           selectcolor=th.PANEL2, activebackground=th.PANEL, activeforeground=th.TEXT,
                           font=(th.FONT, 11),
                           command=lambda: self.pick_appearance("text_size", size.get())).pack(side="left", padx=(0, 16))
        c = self.s_card("Accessibility")
        self.s_note(c, "Use the High contrast theme with Large text for the easiest reading.")

    def pick_appearance(self, key, value):
        if self.save_setting(key, value):
            self.apply_appearance()
            self.show_home(self.user, page="settings")

    def set_payments(self):
        c = self.s_card("Nexora Coins")
        self.s_note(c, "Nexora Coins don't exist yet, and nothing in Nexora can be bought. No payment details "
                       "are stored.")
        c = self.s_card("Purchase history")
        self.s_note(c, "No purchases.")
        c = self.s_card("Spending limits and refunds")
        self.s_note(c, "These will appear here if purchases are ever added.")

    def set_connections(self):
        name = self.user["username"]
        u = accounts.get_user(name)["user"]
        c = self.s_card(f"Friends ({len(u['friends'])})")
        if not u["friends"]:
            self.s_note(c, "No friends yet. Find people on the People page.")
        for f in u["friends"]:
            row = tk.Frame(c, bg=th.PANEL)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=f, bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11)).pack(side="left")
            self.button(row, "Remove", lambda f=f: self.conn_action(accounts.remove_friend, f)).pack(side="right")
        c = self.s_card(f"Blocked users ({len(u['blocked'])})")
        if not u["blocked"]:
            self.s_note(c, "You haven't blocked anyone.")
        for b in u["blocked"]:
            row = tk.Frame(c, bg=th.PANEL)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=b, bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11)).pack(side="left")
            self.button(row, "Unblock", lambda b=b: self.conn_action(accounts.unblock_user, b)).pack(side="right")
        c = self.s_card("Block someone")
        who = self.s_field(c, "Username")
        msg = self.s_msg(c)

        def block():
            target = who.get().strip()
            if not target:
                return
            if not messagebox.askyesno("Block user", f"Block {target}? This also removes them as a friend.",
                                       parent=self):
                return
            res = accounts.block_user(name, target)
            if res["ok"]:
                self.user = res["user"]
                self.show_settings_cat("connections")
                self.set_status(f"Blocked {target}.")
            else:
                msg.configure(text=res.get("error", "Couldn't block that user."), fg=th.DANGER)
        self.button(c, "Block", block).pack(anchor="w")
        c = self.s_card("Followers")
        self.s_note(c, "Following isn't part of Nexora yet. Friends are the only connections for now.")

    def conn_action(self, fn, other):
        res = fn(self.user["username"], other)
        if res.get("ok"):
            self.user = res["user"]
        self.show_settings_cat("connections")

    def set_parental(self):
        name = self.user["username"]
        st = accounts.parental_status(name)
        c = self.s_card("Family-approved communication and online play")
        self.s_note(c, "A PIN locks the Privacy & Communication settings and account deactivation or deletion. "
                       "You can also switch off friend requests and online play. Anyone who knows the PIN can "
                       "change these, so choose one only the parent knows. Spending limits aren't needed yet, "
                       "because nothing can be bought.")
        rf = tk.BooleanVar(value=st["restrict_friends"])
        rj = tk.BooleanVar(value=st["restrict_join"])
        for var, text in ((rf, "Turn off friend requests and user search"),
                          (rj, "Turn off online play (hosting and joining servers)")):
            tk.Checkbutton(c, text=text, variable=var, bg=th.PANEL, fg=th.TEXT, selectcolor=th.PANEL2,
                           activebackground=th.PANEL, activeforeground=th.TEXT, font=(th.FONT, 11),
                           anchor="w").pack(fill="x")
        c2 = self.s_card("Parental controls are ON" if st["enabled"] else "Turn on parental controls")
        if st["enabled"]:
            pin = self.s_field(c2, "Parental PIN", show="•")
            msg = self.s_msg(c2)

            def apply():
                res = accounts.parental_update(name, pin.get(), rf.get(), rj.get())
                msg.configure(text="Saved." if res["ok"] else res["error"], fg=th.CYAN if res["ok"] else th.DANGER)

            def off():
                res = accounts.parental_disable(name, pin.get())
                if res["ok"]:
                    self.show_settings_cat("parental")
                    self.set_status("Parental controls are off.")
                else:
                    msg.configure(text=res["error"], fg=th.DANGER)
            row = tk.Frame(c2, bg=th.PANEL)
            row.pack(fill="x")
            self.button(row, "Save changes", apply, primary=True).pack(side="left")
            self.button(row, "Turn off", off).pack(side="left", padx=8)
        else:
            pw = self.s_field(c2, "Your account password", show="•")
            pin = self.s_field(c2, "New PIN (4-8 digits)", show="•")
            pin2 = self.s_field(c2, "Repeat PIN", show="•")
            msg = self.s_msg(c2)

            def on():
                if pin.get() != pin2.get():
                    msg.configure(text="The PINs don't match.", fg=th.DANGER)
                    return
                res = accounts.parental_enable(name, pw.get(), pin.get(), rf.get(), rj.get())
                if res["ok"]:
                    self.show_settings_cat("parental")
                    self.set_status("Parental controls are on.")
                else:
                    msg.configure(text=res["error"], fg=th.DANGER)
            self.button(c2, "Turn on", on, primary=True).pack(anchor="w")

    def set_help(self):
        name = self.user["username"]
        c = self.s_card("Report a problem")
        cat = tk.StringVar(value="Bug")
        om = tk.OptionMenu(c, cat, "Bug", "Account", "Safety or abuse", "Other")
        om.configure(bg=th.PANEL2, fg=th.TEXT, activebackground=th.PANEL2, activeforeground=th.TEXT,
                     highlightthickness=0, relief="flat", font=(th.FONT, 11))
        om["menu"].configure(bg=th.PANEL2, fg=th.TEXT)
        om.pack(anchor="w", pady=(0, 6))
        txt = tk.Text(c, height=5, width=60, bg=th.BG, fg=th.TEXT, insertbackground=th.TEXT, relief="flat",
                      font=(th.FONT, 11), highlightthickness=1, highlightbackground=th.LINE,
                      highlightcolor=th.ACCENT)
        txt.pack(fill="x", pady=(0, 6))
        msg = self.s_msg(c)

        def send():
            res = accounts.submit_report(name, cat.get(), txt.get("1.0", "end"))
            if res["ok"]:
                txt.delete("1.0", "end")
                msg.configure(text=f"Saved on this PC ({accounts.report_count(name)} so far). Nexora has no support "
                                   f"team online yet, so it isn't sent anywhere. Send the file to the developer.",
                              fg=th.CYAN)
            else:
                msg.configure(text=res["error"], fg=th.DANGER)
        self.button(c, "Save report", send).pack(anchor="w")
        c = self.s_card("Appeal a moderation action")
        self.s_note(c, "Nexora has no moderation system yet, so there is nothing to appeal.")
        c = self.s_card("Your data")
        folder = str(accounts.data_dir())
        self.s_note(c, f"Accounts, settings and reports live in:\n{folder}")
        self.button(c, "Open folder", lambda: self.open_folder(folder)).pack(anchor="w", pady=(6, 0))
        c = self.s_card("About")
        self.s_note(c, f"Nexora v{VERSION}")

    def open_folder(self, folder):
        try:
            if sys.platform == "win32":
                os.startfile(folder)  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except OSError as e:
            self.set_status(f"Couldn't open the folder: {e.strerror or e}")

    def set_danger(self):
        name = self.user["username"]
        if online.enabled():
            c = self.s_card("Delete account")
            self.s_note(c, "Permanently deletes your Nexora account, your published games, your Nexei and what you own. "
                           "This can't be undone.", th.DANGER)
            pw = self.s_field(c, "Your password", show="\u2022")
            msg = self.s_msg(c)

            def delete_online():
                ok, _ = self.need_pin()
                if not ok:
                    return
                if not pw.get():
                    msg.configure(text="Type your password to confirm.", fg=th.DANGER)
                    return
                if not messagebox.askyesno("Delete account", f"Permanently delete @{name}? This can't be undone.",
                                           icon="warning", parent=self):
                    return

                def done(res, err):
                    if err:
                        msg.configure(text=err, fg=th.DANGER)
                        return
                    self.stop_hosting()
                    self.net.token = ""
                    accounts.delete_account(name, "", verified=True)
                    accounts.logout()
                    self.user = None
                    self.show_auth()
                password = pw.get()   # read here: tkinter widgets can't be touched from the background thread
                self.bg(lambda: self.net.delete_account(password), done)
            self.button(c, "Delete my account", delete_online).pack(anchor="w")
            return
        c = self.s_card("Deactivate account")
        self.s_note(c, "Hides you from search and profiles. Nothing is deleted, and logging back in turns your "
                       "account on again.")
        pw1 = self.s_field(c, "Your password", show="•")
        msg1 = self.s_msg(c)

        def deactivate():
            ok, _ = self.need_pin()
            if not ok:
                return
            if not messagebox.askyesno("Deactivate", "Deactivate your account and log out?", parent=self):
                return
            res = accounts.deactivate_account(name, pw1.get())
            if res["ok"]:
                self.stop_hosting()
                self.user = None
                self.show_auth()
            else:
                msg1.configure(text=res["error"], fg=th.DANGER)
        self.button(c, "Deactivate", deactivate).pack(anchor="w")

        c = self.s_card("Delete account")
        self.s_note(c, "Permanently deletes your account, avatar, settings and play history from this PC, and "
                       "removes you from everyone's friends. This can't be undone.", th.DANGER)
        pw2 = self.s_field(c, "Your password", show="•")
        msg2 = self.s_msg(c)

        def delete():
            ok, _ = self.need_pin()
            if not ok:
                return
            if not messagebox.askyesno("Delete account", f"Permanently delete @{name}? This can't be undone.",
                                       icon="warning", parent=self):
                return
            res = accounts.delete_account(name, pw2.get())
            if res["ok"]:
                self.stop_hosting()
                self.user = None
                self.show_auth()
            else:
                msg2.configure(text=res["error"], fg=th.DANGER)
        self.button(c, "Delete my account", delete).pack(anchor="w")
