"""Nexora Studio scripting: Python scripts that run inside a Nexora game.

A script can define any of these functions:
    on_start()            once, when the game begins
    on_update(dt)         every frame (dt = seconds since last frame)
    on_touch(player)      when the player touches the part the script is attached to
    on_died(player)       when the player's health reaches 0 (they respawn right after)

and uses these names (already available, no import needed):
    game     score, say(), win(), time, find(), find_all(), parts, spawn_part(), after(), every()
    part     the part this script is attached to (None for a game-wide script)
    player   name, position, teleport(), speed, jump_height, on_ground,
             health, max_health, regen, damage(n), heal(n), alive
    math, random, time-free helpers: distance(a, b), rgb(r, g, b)

SAFETY: this is a guard rail, not a security boundary. It blocks the obvious ways to touch files, the network
or the rest of Python, and stops runaway loops, but a determined person could still find a way around it.
Only run games from people you trust.
"""
import ast
import builtins
import math
import random
import sys
import traceback

MAX_SOURCE = 50_000
LINE_BUDGET = 400_000       # script lines one call may run before it is stopped (about a tenth of a second)
MAX_RUNTIME_PARTS = 1000
MAX_TIMERS = 200
ERRORS_BEFORE_STOP = 3
ALLOWED_IMPORTS = {"math", "random"}
BANNED_NAMES = {
    "eval", "exec", "compile", "open", "__import__", "globals", "locals", "vars", "getattr", "setattr",
    "delattr", "input", "breakpoint", "memoryview", "exit", "quit", "help", "dir",
}
# attributes that lead from ordinary objects to Python's internals (frames, code, tracebacks)
BANNED_ATTRS = {
    "gi_frame", "gi_code", "gi_yieldfrom", "cr_frame", "cr_code", "cr_await", "cr_origin", "ag_frame", "ag_code",
    "ag_await", "f_globals", "f_locals", "f_builtins", "f_back", "f_code", "f_trace", "tb_frame", "tb_next",
    "tb_lasti", "mro", "with_traceback", "co_code", "co_consts", "co_names", "func_globals",
}
SAFE_BUILTINS = {
    n: getattr(builtins, n) for n in (
        "abs all any bool dict divmod enumerate filter float int isinstance issubclass len list map max min "
        "pow range reversed round set sorted str sum tuple zip chr ord hex bin repr hash callable iter next "
        "slice frozenset bytes bytearray complex format id type object super property classmethod staticmethod "
        "Exception ValueError TypeError KeyError IndexError ZeroDivisionError StopIteration AttributeError "
        "ArithmeticError RuntimeError NameError LookupError OverflowError AssertionError "
        "True False None NotImplemented Ellipsis").split()
}


class ScriptTimeout(Exception):
    pass


def check_source(src: str) -> list:
    """Problems with a script, as [(line, message)]. Empty list means it can run."""
    if len(src) > MAX_SOURCE:
        return [(1, f"Script is too long ({len(src)} characters, the limit is {MAX_SOURCE}).")]
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return [(e.lineno or 1, f"Syntax error: {e.msg}")]
    except (ValueError, RecursionError):
        return [(1, "This script couldn't be read.")]
    errs = []
    for node in ast.walk(tree):
        line = getattr(node, "lineno", 1)
        if isinstance(node, ast.Attribute) and (node.attr.startswith("_") or node.attr in BANNED_ATTRS):
            errs.append((line, f"'.{node.attr}' isn't available in Nexora scripts."))
        elif isinstance(node, ast.Name) and (node.id in BANNED_NAMES or node.id.startswith("__")):
            errs.append((line, f"'{node.id}' isn't available in Nexora scripts."))
        elif isinstance(node, ast.Import):
            for a in node.names:
                if a.name not in ALLOWED_IMPORTS:
                    errs.append((line, f"You can only import {', '.join(sorted(ALLOWED_IMPORTS))} (not '{a.name}')."))
        elif isinstance(node, ast.ImportFrom):
            if node.level or node.module not in ALLOWED_IMPORTS:
                errs.append((line, f"You can only import {', '.join(sorted(ALLOWED_IMPORTS))} (not '{node.module}')."))
        elif isinstance(node, (ast.AsyncFunctionDef, ast.Await, ast.AsyncFor, ast.AsyncWith)):
            errs.append((line, "async code isn't supported."))
        elif (isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow) and isinstance(node.right, ast.Constant)
              and isinstance(node.right.value, (int, float)) and abs(node.right.value) > 1000):
            errs.append((line, "That exponent is too large."))
        elif isinstance(node, ast.FunctionDef) and any(a.arg.startswith("__") for a in node.args.args):
            errs.append((line, "Argument names can't start with __."))
    return sorted(set(errs))


def _import(name, globals=None, locals=None, fromlist=(), level=0):
    if name not in ALLOWED_IMPORTS or level:
        raise ImportError(f"You can only import {', '.join(sorted(ALLOWED_IMPORTS))}.")
    return __import__(name, globals, locals, fromlist, level)


def run_limited(fn, *args, budget: int = LINE_BUDGET):
    """Call fn(*args) but raise ScriptTimeout if script code runs more than `budget` lines."""
    count = 0

    def local(frame, event, arg):
        nonlocal count
        if event == "line":
            count += 1
            if count > budget:
                raise ScriptTimeout("The script ran too long without finishing (is there an endless loop?)")
        return local

    def tracer(frame, event, arg):
        return local if frame.f_code.co_filename.startswith("<nexora:") else None

    old = sys.gettrace()
    sys.settrace(tracer)
    try:
        return fn(*args)
    finally:
        sys.settrace(old)


def _num3(v, what="value"):
    try:
        x, y, z = v
        out = (float(x), float(y), float(z))
    except (TypeError, ValueError):
        raise TypeError(f"{what} must be three numbers like (0, 5, 0)") from None
    if not all(math.isfinite(c) and abs(c) < 1e6 for c in out):
        raise ValueError(f"{what} has a number that is too large")
    return out


def _hex(c):
    if isinstance(c, str) and len(c) == 7 and c[0] == "#":
        try:
            int(c[1:], 16)
            return c.lower()
        except ValueError:
            pass
    raise ValueError("color must look like '#ff8800' (or use rgb(255, 136, 0))")


def distance(a, b):
    """Distance between two positions (tuples), parts or players."""
    pa = getattr(a, "position", a)
    pb = getattr(b, "position", b)
    pa, pb = _num3(pa), _num3(pb)
    return math.dist(pa, pb)


def rgb(r, g, b):
    """rgb(255, 136, 0) -> '#ff8800'"""
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in (r, g, b))


class Part:
    """A part in the game. Change its properties and it changes on screen."""

    def __init__(self, host, rec):
        object.__setattr__(self, "_host", host)
        object.__setattr__(self, "_rec", rec)
        object.__setattr__(self, "on_touch", None)

    # read-only
    @property
    def id(self): return self._rec["id"]
    @property
    def kind(self): return self._rec["kind"]
    @property
    def destroyed(self): return bool(self._rec.get("dead"))

    def _set(self, key, value, field):
        if self._rec.get("dead"):
            return
        self._rec[key] = value
        self._host.adapter.part_changed(self._rec, field)

    @property
    def name(self): return self._rec["name"]
    @name.setter
    def name(self, v): self._rec["name"] = str(v)[:40]

    @property
    def position(self): return tuple(self._rec["pos"])
    @position.setter
    def position(self, v): self._set("pos", list(_num3(v, "position")), "pos")

    @property
    def size(self): return tuple(self._rec["size"])
    @size.setter
    def size(self, v):
        s = _num3(v, "size")
        if any(c <= 0 for c in s):
            raise ValueError("size must be above 0")
        self._set("size", list(s), "size")

    @property
    def rotation_y(self): return self._rec["rot_y"]
    @rotation_y.setter
    def rotation_y(self, v): self._set("rot_y", float(v) % 360, "rot")

    @property
    def color(self): return self._rec["color"]
    @color.setter
    def color(self, v): self._set("color", _hex(v), "color")

    @property
    def visible(self): return self._rec.get("visible", True)
    @visible.setter
    def visible(self, v): self._set("visible", bool(v), "visible")

    @property
    def can_collide(self): return self._rec.get("collide", True)
    @can_collide.setter
    def can_collide(self, v): self._set("collide", bool(v), "collide")

    def distance_to(self, other):
        return distance(self, other)

    def destroy(self):
        if not self._rec.get("dead"):
            self._rec["dead"] = True
            self._host.adapter.part_destroyed(self._rec)

    def __setattr__(self, key, value):
        if key == "on_touch":
            if value is not None and not callable(value):
                raise TypeError("on_touch must be a function")
            object.__setattr__(self, key, value)
        elif key in type(self).__dict__ and isinstance(type(self).__dict__[key], property):
            type(self).__dict__[key].__set__(self, value)
        else:
            raise AttributeError(f"A part has no property called '{key}'")

    def __repr__(self):
        return f"<Part {self._rec['name']!r}>"


def _finite(v) -> float:
    v = float(v)
    if v != v or v in (float("inf"), float("-inf")):
        raise ValueError("that number isn't usable")
    return v


class Player:
    def __init__(self, host):
        object.__setattr__(self, "_host", host)

    @property
    def name(self): return self._host.adapter.player_name()
    @property
    def position(self): return tuple(self._host.adapter.player_pos())
    @property
    def on_ground(self): return bool(self._host.adapter.player_grounded())

    @property
    def speed(self): return self._host.adapter.get_player("speed")
    @speed.setter
    def speed(self, v): self._host.adapter.set_player("speed", max(0.0, min(60.0, float(v))))

    @property
    def jump_height(self): return self._host.adapter.get_player("jump_height")
    @jump_height.setter
    def jump_height(self, v): self._host.adapter.set_player("jump_height", max(0.0, min(30.0, float(v))))

    @property
    def health(self): return self._host.adapter.get_player("health")
    @health.setter
    def health(self, v): self._host.adapter.set_player("health", max(0.0, min(self.max_health, _finite(v))))

    @property
    def max_health(self): return self._host.adapter.get_player("max_health")
    @max_health.setter
    def max_health(self, v): self._host.adapter.set_player("max_health", max(1.0, min(10000.0, _finite(v))))

    @property
    def regen(self):  # health points regained per second (0 = none)
        return self._host.adapter.get_player("regen")
    @regen.setter
    def regen(self, v): self._host.adapter.set_player("regen", max(0.0, min(1000.0, _finite(v))))

    @property
    def alive(self): return self.health > 0

    def has_pass(self, name):
        """True if this player owns the gamepass called `name` (made in Studio > Game settings > Gamepasses).
        Note: scripts run on the player's own PC, so this is an honour system, not copy protection."""
        owned = getattr(self._host.adapter, "player_passes", lambda: set())()
        return owned == "*" or str(name) in owned

    def damage(self, amount):
        """player.damage(25) takes 25 health. At 0 the player dies and respawns."""
        self.health = self.health - _finite(amount)

    def heal(self, amount):
        self.health = self.health + _finite(amount)

    def teleport(self, x, y=None, z=None):
        """player.teleport(0, 10, 0) or player.teleport(part.position)"""
        pos = _num3(x if y is None else (x, y, z), "teleport position")
        self._host.adapter.teleport(pos)

    def distance_to(self, other):
        return distance(self, other)

    def __setattr__(self, key, value):
        p = type(self).__dict__.get(key)
        if isinstance(p, property):
            p.__set__(self, value)
        else:
            raise AttributeError(f"A player has no property called '{key}'")


class Timer:
    def __init__(self, host, delay, fn, repeat):
        self.host, self.delay, self.fn, self.repeat = host, delay, fn, repeat
        self.left = delay
        self.active = True

    def cancel(self):
        self.active = False


class Game:
    def __init__(self, host):
        object.__setattr__(self, "_host", host)

    @property
    def score(self): return self._host.adapter.get_score()
    @score.setter
    def score(self, v): self._host.adapter.set_score(int(v))

    @property
    def time(self): return self._host.clock

    @property
    def parts(self): return [p for p in self._host.part_list() if not p.destroyed]

    def find(self, name):
        for p in self.parts:
            if p.name == name:
                return p
        return None

    def find_all(self, name):
        return [p for p in self.parts if p.name == name]

    def say(self, text, seconds=2.5):
        """Show a message in the middle of the screen."""
        self._host.adapter.say(str(text)[:120], max(0.5, min(30.0, float(seconds))))

    def win(self, text="You win!"):
        self._host.adapter.win(str(text)[:120])

    def after(self, seconds, fn):
        """Run fn once after `seconds`. Returns a timer you can .cancel()."""
        return self._host.add_timer(seconds, fn, False)

    def every(self, seconds, fn):
        """Run fn every `seconds`. Returns a timer you can .cancel()."""
        return self._host.add_timer(seconds, fn, True)

    def spawn_part(self, name="Part", position=(0, 5, 0), size=(2, 1, 2), color="#ffffff", shape="box",
                   can_collide=True):
        return self._host.spawn(name, position, size, color, shape, can_collide)

    def __setattr__(self, key, value):
        if key == "score":
            type(self).score.__set__(self, value)
        else:
            raise AttributeError(f"game has no property called '{key}'")


class _Script:
    def __init__(self, name, target, ns):
        self.name, self.target, self.ns = name, target, ns
        self.errors = 0
        self.stopped = False


class ScriptHost:
    """Loads scripts and drives their events. `adapter` connects it to the real game (or a test double)."""

    def __init__(self, adapter):
        self.adapter = adapter
        self.clock = 0.0
        self.scripts = []
        self.timers = []
        self.parts = {}          # id -> Part handle
        self.runtime_parts = 0
        self.game = Game(self)
        self.player = Player(self)
        self._touch_funcs = {}   # part id -> [(script, fn)]

    # ---- parts
    def part_list(self):
        return list(self.parts.values())

    def register_part(self, rec):
        h = Part(self, rec)
        self.parts[rec["id"]] = h
        return h

    def spawn(self, name, position, size, color, shape, can_collide):
        if self.runtime_parts >= MAX_RUNTIME_PARTS:
            raise RuntimeError(f"A game can create at most {MAX_RUNTIME_PARTS} parts while it runs.")
        if shape not in ("box", "sphere", "cylinder", "cone", "wedge"):
            raise ValueError("shape must be 'box', 'sphere', 'cylinder', 'cone' or 'wedge'")
        size = _num3(size, "size")
        if any(c <= 0 for c in size):
            raise ValueError("size must be above 0")
        rec = {"id": f"rt{self.runtime_parts + 1}-{len(self.parts)}", "name": str(name)[:40], "kind": "part",
               "shape": shape, "pos": list(_num3(position, "position")), "size": list(size), "rot_y": 0.0,
               "color": _hex(color), "collide": bool(can_collide), "visible": True}
        self.runtime_parts += 1
        self.adapter.part_created(rec)
        return self.register_part(rec)

    # ---- timers
    def add_timer(self, seconds, fn, repeat):
        if not callable(fn):
            raise TypeError("the second argument must be a function")
        seconds = float(seconds)
        if not seconds >= 0.02:
            seconds = 0.02
        if len([t for t in self.timers if t.active]) >= MAX_TIMERS:
            raise RuntimeError("Too many timers.")
        t = Timer(self, seconds, fn, repeat)
        self.timers.append(t)
        return t

    # ---- loading
    def load(self, scripts, part_recs):
        """scripts: [{'name','target','source'}]. Returns a list of 'name line N: problem' strings."""
        problems = []
        for rec in part_recs:
            self.register_part(rec)
        for s in scripts:
            name = s.get("name", "Script")
            src = s.get("source", "")
            errs = check_source(src)
            if errs:
                for line, msg in errs:
                    problems.append(f"{name} line {line}: {msg}")
                continue
            target = self.parts.get(s.get("target")) if s.get("target") else None
            if s.get("target") and target is None:
                problems.append(f"{name}: the part this script was attached to no longer exists.")
                continue
            ns = {"__builtins__": dict(SAFE_BUILTINS, __import__=_import, __build_class__=builtins.__build_class__,
                                       print=self._make_print(name)),
                  "__name__": "nexora_script", "game": self.game, "player": self.player, "part": target,
                  "math": math, "random": random, "distance": distance, "rgb": rgb}
            sc = _Script(name, target, ns)
            try:
                code = compile(src, f"<nexora:{name}>", "exec")
                run_limited(exec, code, ns)
            except BaseException as e:  # noqa: BLE001 - a broken script must never take the game down
                if isinstance(e, (KeyboardInterrupt, SystemExit)):
                    raise
                problems.append(self._describe(name, e))
                continue
            self.scripts.append(sc)
            fn = ns.get("on_touch")
            if callable(fn) and target is not None:
                self._touch_funcs.setdefault(target.id, []).append((sc, fn))
        return problems

    def _make_print(self, name):
        def _print(*args, sep=" ", end="\n"):
            self.adapter.log(f"[{name}] " + str(sep).join(str(a) for a in args))
        return _print

    @staticmethod
    def _describe(name, e):
        line = None
        for fs in traceback.extract_tb(e.__traceback__):
            if fs.filename.startswith("<nexora:"):
                line = fs.lineno
        where = f" line {line}" if line else ""
        if isinstance(e, SyntaxError):
            return f"{name}{where}: {e.msg}"
        return f"{name}{where}: {type(e).__name__}: {e}"

    def _call(self, sc, fn, *args):
        if sc is not None and sc.stopped:
            return
        try:
            run_limited(fn, *args)
        except BaseException as e:  # noqa: BLE001
            if isinstance(e, (KeyboardInterrupt, SystemExit)):
                raise
            who = sc.name if sc else "timer"
            self.adapter.log("ERROR " + self._describe(who, e))
            if sc is not None:
                sc.errors += 1
                if sc.errors >= ERRORS_BEFORE_STOP:
                    sc.stopped = True
                    self.adapter.log(f"[{sc.name}] stopped after {ERRORS_BEFORE_STOP} errors.")

    # ---- events
    def start(self):
        for sc in list(self.scripts):
            fn = sc.ns.get("on_start")
            if callable(fn):
                self._call(sc, fn)

    def update(self, dt):
        dt = min(max(dt, 0.0), 0.1)  # a long hitch (like the first frame) must not make timers fire in a burst
        self.clock += dt
        for t in list(self.timers):
            if not t.active:
                continue
            t.left -= dt
            if t.left <= 0:
                if t.repeat:
                    t.left += t.delay
                else:
                    t.active = False
                self._call(None, t.fn)
        self.timers = [t for t in self.timers if t.active]
        for sc in list(self.scripts):
            fn = sc.ns.get("on_update")
            if callable(fn):
                self._call(sc, fn, dt)

    def died(self):
        for sc in list(self.scripts):
            fn = sc.ns.get("on_died")
            if callable(fn):
                self._call(sc, fn, self.player)

    def has_touch(self, part_id):
        h = self.parts.get(part_id)
        return bool(self._touch_funcs.get(part_id)) or bool(h is not None and h.on_touch)

    def touch(self, part_id):
        h = self.parts.get(part_id)
        if h is None or h.destroyed:
            return
        for sc, fn in list(self._touch_funcs.get(part_id, [])):
            self._call(sc, fn, self.player)
        if h.on_touch:
            self._call(None, h.on_touch, self.player)
