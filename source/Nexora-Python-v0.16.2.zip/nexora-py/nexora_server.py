"""Nexora online server: accounts, game catalog, likes, play counts and live game rooms.

Run it on a computer or a web host (see README, "Hosting the online server"):
    pip install aiohttp
    python nexora_server.py            (listens on $PORT, default 8080; data in $NEXORA_DATA, default ./nexora-data)

HTTP (JSON):   POST /api/register /api/login /api/logout     GET /api/me      PUT /api/avatar
               GET /api/games[?q=]    GET /api/games/<id>    GET /api/games/<id>/data    PUT/DELETE /api/games/<id>
               POST /api/games/<id>/like    GET /api/games/<id>/servers    POST /api/games/<id>/join
Nexei:         GET /api/wallet  POST /api/daily  GET/POST /api/shop  POST /api/items/<id>/buy  DELETE /api/items/<id>
               GET/POST /api/games/<id>/passes  GET /api/games/<id>/mypasses
WebSocket:     /ws/<room>?token=...   same messages as the LAN servers in network.py (join, state, chat, bye)

Joining a game puts you in a room of that game that has space, and makes a new room if there isn't one, so the
first person gets a server to themselves and the next person who presses Play lands in it.
Player names in rooms come from the signed-in account, so they can't be faked.
"""
import asyncio
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path

from aiohttp import WSMsgType, web

import accounts
import games as builtin_games
import network as nw
import project as pj

DATA_DIR = Path(os.environ.get("NEXORA_DATA", "nexora-data"))
ROOM_MAX = int(os.environ.get("NEXORA_ROOM_MAX", "12"))
MAX_ROOMS = 200
TOKEN_DAYS = 30
MAX_GAMES_PER_USER = 30
EMPTY_ROOM_SECONDS = 30
PLAY_COUNT_GAP = 300  # the same person only adds a play to the same game every 5 minutes

# Staff accounts have unlimited Nexei. Their names can only be registered with the staff code (env NEXORA_STAFF_CODE),
# so nobody else can sign up as them. Change the list with NEXORA_STAFF="Name1,Name2".
STAFF = {n.strip().lower() for n in os.environ.get("NEXORA_STAFF", "Aces22378,Ivy").split(",") if n.strip()}
STAFF_CODE = os.environ.get("NEXORA_STAFF_CODE", "")
# Badges by names: "verified" (NEXORA_VERIFIED="Name1,Name2") and "staff" (the staff list above). Staff is the higher one,
# so someone who has both shows only the staff badge.
VERIFIED = {n.strip().lower() for n in os.environ.get("NEXORA_VERIFIED", "Aces22378,Ivy").split(",") if n.strip()}


def badge_map() -> dict:
    return {**{n: "verified" for n in VERIFIED}, **{n: "staff" for n in STAFF}}
DAILY_NEXEI = 100          # free Nexei you can claim every 24 hours (there is no real-money purchase yet)
DAILY_GAP = 24 * 3600
SELLER_SHARE = 0.70        # the creator of a gamepass gets 70% of the price; the rest leaves the economy
MAX_PRICE = 1_000_000
MAX_PASSES_PER_GAME = 20
MAX_PENDING_PER_USER = 10   # items a creator can have waiting for review
MAX_ITEMS_PER_USER = 100
FREE_SHIRT = {"#7c5cff", "#22d3ee", "#ef4444", "#f59e0b", "#4ade80", "#ec4899", "#f8fafc", "#1f2937"}
FREE_PANTS = {"#2b2b4a", "#1d4ed8", "#374151", "#7f1d1d", "#14532d", "#78350f", "#f8fafc", "#0f172a"}

DB = None
ROOMS = {}        # room id -> Room
ONLINE = {}       # (room id, username lower) -> websocket, so a second login replaces the first


# ---------------------------------------------------------------- storage
SCHEMA = """
        CREATE TABLE IF NOT EXISTS users (name TEXT PRIMARY KEY COLLATE NOCASE, salt TEXT, hash TEXT, created INTEGER,
                                          avatar TEXT);
        CREATE TABLE IF NOT EXISTS tokens (hash TEXT PRIMARY KEY, user TEXT COLLATE NOCASE, expires INTEGER);
        CREATE TABLE IF NOT EXISTS games (id TEXT PRIMARY KEY, owner TEXT COLLATE NOCASE, name TEXT, description TEXT,
                                          emoji TEXT, thumb TEXT, data TEXT, plays INTEGER DEFAULT 0,
                                          created INTEGER, updated INTEGER);
        CREATE TABLE IF NOT EXISTS likes (game TEXT, user TEXT COLLATE NOCASE, PRIMARY KEY (game, user));
        CREATE TABLE IF NOT EXISTS items (id TEXT PRIMARY KEY, kind TEXT, game TEXT, name TEXT, description TEXT,
                                          price INTEGER, color TEXT, creator TEXT COLLATE NOCASE, created INTEGER);
        CREATE TABLE IF NOT EXISTS purchases (user TEXT COLLATE NOCASE, item TEXT, price INTEGER, at INTEGER,
                                              PRIMARY KEY (user, item));
"""
UPGRADES = ("ALTER TABLE users ADD COLUMN balance INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN last_daily INTEGER DEFAULT 0",
            "ALTER TABLE items ADD COLUMN payload TEXT",
            "ALTER TABLE items ADD COLUMN status TEXT DEFAULT 'approved'",
            "ALTER TABLE users ADD COLUMN algo TEXT")  # NULL = scrypt; 'pbkdf2' = made by the Cloudflare Worker  # added in 0.6 - upgrade old databases


def _body_payload(slot, **extra):
    return json.dumps({"acc": {"slot": slot, "boxes": []}, **extra})


# Looks-only body items sold by Nexora itself: id, name, description, price, payload, earlier default (price, payload).
# "Legless" is a bundle: buying it gives you the Left and the Right leg item (which have no price of their own and only
# show up in the Shop once you own them). You can wear one of them at a time.
OFFICIAL_ITEMS = (
    ("o-headless", "Headless", "Take your head off. Just for looks.", 31000, _body_payload("nohead"), 200),
    ("o-legless-b", "Legless", "Get the Left and Right leg items: take a leg off. You can wear one at a time. Just for looks.",
     17000, _body_payload("noleftleg", bundle=["o-legless-l", "o-legless-r"]), None),
    ("o-legless-l", "Legless (Left)", "Included with Legless. Takes your left leg off. Just for looks.", 0,
     _body_payload("noleftleg", hidden=True), 100),
    ("o-legless-r", "Legless (Right)", "Included with Legless. Takes your right leg off. Just for looks.", 0,
     _body_payload("norightleg", hidden=True), 100),
)


def seed_official(db):
    """Make sure the official body items exist. A price changed in the database sticks; one still at an earlier default
    of mine is moved to the current default."""
    for iid, name, desc, price, payload, old in OFFICIAL_ITEMS:
        db.execute("INSERT OR IGNORE INTO items (id, kind, game, name, description, price, color, creator, created, payload, status) "
                   "VALUES (?, 'acc', NULL, ?, ?, ?, NULL, NULL, ?, ?, 'approved')",
                   (iid, name, desc, price, int(time.time()), payload))
        if old is not None:
            db.execute("UPDATE items SET price = ?, payload = ?, description = ?, name = ? WHERE id = ? AND price = ?",
                       (price, payload, desc, name, iid, old))
    db.commit()


def open_db():
    """Local SQLite (fast). With the CF_* environment variables set, it is also kept safe on Cloudflare D1."""
    import d1_mirror
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    raw = sqlite3.connect(DATA_DIR / "nexora.db", check_same_thread=False)
    raw.row_factory = sqlite3.Row
    raw.executescript(SCHEMA)
    for col in UPGRADES:
        try:
            raw.execute(col)
        except sqlite3.OperationalError:
            pass
    raw.commit()
    db = raw
    d1 = d1_mirror.from_env()
    if d1:
        stmts = [x.strip() for x in SCHEMA.split(";") if x.strip()]
        d1_mirror.prepare(d1, stmts, UPGRADES)
        if raw.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            n = d1_mirror.restore(raw, d1)
            print(f"Restored {n} rows from Cloudflare D1.", flush=True)
        db = d1_mirror.Mirror(raw, d1)
        print("Cloudflare D1 backup is on.", flush=True)
    else:
        print("Cloudflare D1 is not set up: data lives only on this server's disk.", flush=True)
    for g in builtin_games.GAMES:  # the built-in games exist on every PC; the server only keeps their numbers
        db.execute("INSERT OR IGNORE INTO games (id, owner, name, description, emoji, thumb, data, created, updated) "
                   "VALUES (?, 'Nexora', ?, ?, ?, ?, NULL, ?, ?)",
                   (g["id"], g["name"], g["desc"], g["emoji"], g["thumb"], int(time.time()), int(time.time())))
    db.commit()
    return db


def hash_pw(password: str, salt: str, algo=None) -> str:
    if algo == "pbkdf2":  # accounts made by the Cloudflare Worker (it shares the same D1 database)
        return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100000, 32).hex()
    return hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=2 ** 14, r=8, p=1).hex()


def tok_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def new_token(user: str) -> str:
    token = secrets.token_urlsafe(32)
    DB.execute("DELETE FROM tokens WHERE expires < ?", (int(time.time()),))
    DB.execute("INSERT INTO tokens VALUES (?, ?, ?)", (tok_hash(token), user, int(time.time()) + TOKEN_DAYS * 86400))
    DB.commit()
    return token


def user_for_token(token: str):
    row = DB.execute("SELECT user FROM tokens WHERE hash = ? AND expires > ?", (tok_hash(token or ""),
                                                                              int(time.time()))).fetchone()
    return DB.execute("SELECT * FROM users WHERE name = ?", (row["user"],)).fetchone() if row else None


def bearer(request) -> str:
    h = request.headers.get("Authorization", "")
    return h[7:] if h.startswith("Bearer ") else ""


class Limiter:
    def __init__(self):
        self.hits = {}

    def allow(self, key, limit, window) -> bool:
        now = time.monotonic()
        lst = [t for t in self.hits.get(key, []) if now - t < window]
        if len(lst) >= limit:
            self.hits[key] = lst
            return False
        lst.append(now)
        self.hits[key] = lst
        if len(self.hits) > 20000:  # don't grow forever
            self.hits = {k: v for k, v in self.hits.items() if v and now - v[-1] < window}
        return True


LIMIT = Limiter()


def client_ip(request) -> str:
    fwd = request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
    return fwd or request.remote or "?"


def fail(msg, status=400):
    return web.json_response({"ok": False, "error": msg}, status=status)


async def body(request) -> dict:
    try:
        d = await request.json()
    except (ValueError, UnicodeDecodeError):
        raise web.HTTPBadRequest(text=json.dumps({"ok": False, "error": "Bad request."}),
                                 content_type="application/json")
    if not isinstance(d, dict):
        raise web.HTTPBadRequest(text=json.dumps({"ok": False, "error": "Bad request."}),
                                 content_type="application/json")
    return d


def me_or_401(request):
    u = user_for_token(bearer(request))
    if not u:
        raise web.HTTPUnauthorized(text=json.dumps({"ok": False, "error": "Please sign in again."}),
                                   content_type="application/json")
    return u


def public_user(u) -> dict:
    return {"username": u["name"], "avatar": nw.clean_avatar(json.loads(u["avatar"] or "{}")),
            "staff": is_staff(u["name"])}


# ---------------------------------------------------------------- accounts
async def register(request):
    d = await body(request)
    name, pw = str(d.get("username", "")).strip(), str(d.get("password", ""))
    if not nw.NAME_RE.fullmatch(name):
        return fail("Username must be 3-20 letters, numbers or underscores.")
    if len(pw) < 6 or len(pw) > 128:
        return fail("Password must be 6-128 characters.")
    if not LIMIT.allow(("reg", client_ip(request)), 6, 3600):
        return fail("Too many new accounts from this network. Try again later.", 429)
    if name.lower() in STAFF and not (STAFF_CODE and hmac.compare_digest(str(d.get("staff_code", "")), STAFF_CODE)):
        return fail("That username is reserved for Nexora staff.")
    if name.lower() in accounts.RESERVED_NAMES or DB.execute("SELECT 1 FROM users WHERE name = ?", (name,)).fetchone():
        return fail("That username is taken.")
    salt = secrets.token_hex(16)
    h = await asyncio.get_running_loop().run_in_executor(None, hash_pw, pw, salt)
    try:
        DB.execute("INSERT INTO users (name, salt, hash, created, avatar) VALUES (?, ?, ?, ?, ?)",
                   (name, salt, h, int(time.time()), json.dumps({})))
        DB.commit()
    except sqlite3.IntegrityError:
        return fail("That username is taken.")
    u = DB.execute("SELECT * FROM users WHERE name = ?", (name,)).fetchone()
    return web.json_response({"ok": True, "token": new_token(u["name"]), "user": public_user(u)})


async def login(request):
    d = await body(request)
    name, pw = str(d.get("username", "")).strip(), str(d.get("password", ""))
    if not LIMIT.allow(("login", client_ip(request), name.lower()), 10, 300):
        return fail("Too many tries. Wait a few minutes.", 429)
    u = DB.execute("SELECT * FROM users WHERE name = ?", (name,)).fetchone()
    salt = u["salt"] if u else "00" * 16
    h = await asyncio.get_running_loop().run_in_executor(None, hash_pw, pw[:128], salt, u["algo"] if u else None)
    if not u or not hmac.compare_digest(h, u["hash"]):
        return fail("Wrong username or password.", 401)
    return web.json_response({"ok": True, "token": new_token(u["name"]), "user": public_user(u)})


async def logout(request):
    DB.execute("DELETE FROM tokens WHERE hash = ?", (tok_hash(bearer(request)),))
    DB.commit()
    return web.json_response({"ok": True})


async def me(request):
    return web.json_response({"ok": True, "user": public_user(me_or_401(request))})


async def set_avatar(request):
    """The client says what it wants to wear; the server decides what it may wear and stores the resolved look."""
    import avatar as av_mod
    u = me_or_401(request)
    d = (await body(request)).get("avatar")
    d = d if isinstance(d, dict) else {}
    av = nw.clean_avatar(d)
    staff = is_staff(u["name"])
    owned = {r["id"]: r for r in DB.execute(
        "SELECT i.* FROM items i JOIN purchases p ON p.item = i.id WHERE p.user = ? AND COALESCE(i.status,'approved') = 'approved'",
        (u["name"],))}
    if staff:  # staff may wear anything that is on sale
        for r in DB.execute("SELECT * FROM items WHERE kind IN ('shirt','pants','acc') AND COALESCE(status,'approved') = 'approved'"):
            owned.setdefault(r["id"], r)
    owned_colors = {r["color"] for r in owned.values() if r["color"]}
    free = {"shirt": FREE_SHIRT, "pants": FREE_PANTS}
    av["sleeve_tex"] = None  # sleeves only ever come from a shirt you own
    for part in ("shirt", "pants"):
        iid = av[part + "_item"]
        av[part + "_tex"], av[part + "_item"] = None, None
        if iid:
            r = owned.get(iid)
            if not r or r["kind"] != part:
                return fail(f"You don't own that {part}. Buy it in the Shop first.", 403)
            payload = json.loads(r["payload"]) if r["payload"] else {}
            av[part], av[part + "_tex"], av[part + "_item"] = r["color"], payload.get("tex"), r["id"]
            if part == "shirt":
                av["sleeve_tex"] = payload.get("sleeve")
        elif av[part] not in free[part] and av[part] not in owned_colors and not staff:
            return fail(f"You don't own that {part}. Buy it in the Shop first.", 403)
    raw = d.get("acc") if isinstance(d.get("acc"), list) else []
    wanted = [str(a.get("id"))[:20] for a in raw[:4] if isinstance(a, dict) and a.get("id")]  # only the ids count
    acc = []
    for iid in wanted:
        r = owned.get(iid)
        if not r or r["kind"] != "acc":
            return fail("You don't own that accessory. Buy it in the Shop first.", 403)
        whole = json.loads(r["payload"]) if r["payload"] else {}
        if whole.get("bundle"):
            continue   # a bundle only hands out its parts; it isn't worn itself
        payload = whole.get("acc") or {}
        a = av_mod.clean_acc({"id": r["id"], "name": r["name"], "slot": payload.get("slot"), "boxes": payload.get("boxes"), "mesh": payload.get("mesh")})
        if a and all(a["slot"] != x["slot"] for x in acc):
            acc.append(a)
    legs = [x for x in acc if x["slot"] in av_mod.LEG_SLOTS]
    for x in legs[:-1]:   # one leg item at a time: the one asked for last stays
        acc.remove(x)
    av["acc"] = acc
    DB.execute("UPDATE users SET avatar = ? WHERE name = ?", (json.dumps(av), u["name"]))
    DB.commit()
    return web.json_response({"ok": True, "avatar": av})


async def badges(request):
    return web.json_response({"ok": True, "badges": badge_map()})


async def user_exists(request):
    me_or_401(request)
    row = DB.execute("SELECT name FROM users WHERE name = ?", (request.match_info["name"],)).fetchone()
    return web.json_response({"ok": True, "username": row["name"] if row else None})


async def users_exist(request):
    me_or_401(request)
    try:
        d = await request.json()
    except ValueError:
        d = {}
    raw = d.get("names") if isinstance(d, dict) and isinstance(d.get("names"), list) else []
    names = list(dict.fromkeys(n for n in raw if isinstance(n, str) and 3 <= len(n) <= 20 and n.replace("_", "").isalnum() and n.isascii()))[:60]
    found = []
    for n in names:
        row = DB.execute("SELECT name FROM users WHERE name = ?", (n,)).fetchone()
        if row:
            found.append(row["name"])
    return web.json_response({"ok": True, "exist": found})


# ---------------------------------------------------------------- games
def live_players(game_id: str) -> int:
    return sum(len(r.players) for r in ROOMS.values() if r.game_id == game_id)


def game_summary(row) -> dict:
    data = json.loads(row["data"]) if row["data"] else {}
    likes = DB.execute("SELECT COUNT(*) FROM likes WHERE game = ?", (row["id"],)).fetchone()[0]
    return {"id": row["id"], "name": row["name"], "desc": row["description"], "emoji": row["emoji"],
            "thumb": row["thumb"], "owner": row["owner"], "devs": data.get("devs", []), "plays": row["plays"],
            "likes": likes, "playing": live_players(row["id"]), "official": row["data"] is None,
            "updated": row["updated"], "has_scripts": bool(data.get("scripts"))}


async def list_games(request):
    q = request.query.get("q", "").strip().lower()[:40]
    rows = DB.execute("SELECT * FROM games ORDER BY plays DESC, updated DESC LIMIT 300").fetchall()
    out = [game_summary(r) for r in rows if not q or q in r["name"].lower() or q in r["description"].lower()
           or q in r["owner"].lower()]
    return web.json_response({"ok": True, "games": out})


def get_row(request):
    row = DB.execute("SELECT * FROM games WHERE id = ?", (request.match_info["id"][:40],)).fetchone()
    if not row:
        raise web.HTTPNotFound(text=json.dumps({"ok": False, "error": "That game doesn't exist."}),
                               content_type="application/json")
    return row


def room_list(game_id):
    return [{"id": r.id, "name": r.name, "players": len(r.players), "max": ROOM_MAX}
            for r in sorted(ROOMS.values(), key=lambda r: -len(r.players)) if r.game_id == game_id]


async def game_detail(request):
    row = get_row(request)
    s = game_summary(row)
    data = json.loads(row["data"]) if row["data"] else {}
    s["thumbs"] = data.get("thumbs", [])
    u = user_for_token(bearer(request))
    s["liked"] = bool(u and DB.execute("SELECT 1 FROM likes WHERE game = ? AND user = ?", (row["id"], u["name"])).fetchone())
    s["servers"] = room_list(row["id"])
    return web.json_response({"ok": True, "game": s})


async def game_data(request):
    row = get_row(request)
    if not row["data"]:
        return fail("That's a built-in game; it's already on your PC.", 404)
    return web.Response(text=row["data"], content_type="application/json")


async def publish(request):
    u = me_or_401(request)
    gid = request.match_info["id"]
    if not pj._ID.fullmatch(gid):
        return fail("Bad game id.")
    try:
        d = pj.clean_project(await body(request))
    except ValueError as e:
        return fail(str(e))
    if d["id"] != gid:
        return fail("The game id doesn't match.")
    old = DB.execute("SELECT * FROM games WHERE id = ?", (gid,)).fetchone()
    if old:
        if old["data"] is None:
            return fail("That id belongs to a built-in game.", 403)
        if not pj.is_dev(json.loads(old["data"]), u["name"]):
            return fail(f"This game belongs to {old['owner']}.", 403)
        d["owner"] = old["owner"]  # the owner never changes
        if u["name"].lower() != old["owner"].lower():
            d["devs"] = json.loads(old["data"]).get("devs", [])  # only the owner can change the developer list
    else:
        d["owner"] = u["name"]
        if DB.execute("SELECT COUNT(*) FROM games WHERE owner = ?", (u["name"],)).fetchone()[0] >= MAX_GAMES_PER_USER:
            return fail(f"You can publish at most {MAX_GAMES_PER_USER} games.")
    real_devs = []
    for n in d["devs"]:
        row = DB.execute("SELECT name FROM users WHERE name = ?", (n,)).fetchone()
        if not row:
            return fail(f"There's no Nexora account called {n}.")
        real_devs.append(row["name"])
    d["devs"] = real_devs
    d["author"] = d["owner"]
    text = json.dumps(d)
    now = int(time.time())
    if old:
        DB.execute("UPDATE games SET name=?, description=?, emoji=?, thumb=?, data=?, updated=? WHERE id=?",
                   (d["name"], d["desc"], d["emoji"], d["thumb"], text, now, gid))
    else:
        DB.execute("INSERT INTO games (id, owner, name, description, emoji, thumb, data, created, updated) "
                   "VALUES (?,?,?,?,?,?,?,?,?)", (gid, d["owner"], d["name"], d["desc"], d["emoji"], d["thumb"], text,
                                                   now, now))
    DB.commit()
    return web.json_response({"ok": True, "game": game_summary(DB.execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone())})


async def unpublish(request):
    u = me_or_401(request)
    row = get_row(request)
    if row["data"] is None or row["owner"].lower() != u["name"].lower():
        return fail("Only the owner can remove a game.", 403)
    DB.execute("DELETE FROM games WHERE id = ?", (row["id"],))
    DB.execute("DELETE FROM likes WHERE game = ?", (row["id"],))
    DB.commit()
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- modified-client check (silent)
_MANIFEST = {}
try:
    _MANIFEST = json.loads((Path(__file__).resolve().parent / "integrity_manifest.json").read_text())
except (OSError, ValueError):
    pass
_tamper_seen = set()
_HEX64 = __import__("re").compile(r"[0-9a-f]{64}")
_VER = __import__("re").compile(r"[A-Za-z0-9._-]{1,30}")


async def integrity(request):
    """The client sends its file hashes. Always answers the same, so a modified client learns nothing."""
    u = me_or_401(request)
    answer = web.json_response({"ok": True})
    try:
        d = await request.json()
        ver, files = d.get("version"), d.get("files")
        if (is_staff(u["name"]) or not isinstance(ver, str) or not _VER.fullmatch(ver) or ver not in _MANIFEST
                or not isinstance(files, dict) or len(files) > 200
                or not LIMIT.allow(("integrity", u["name"].lower()), 6, 3600)):
            return answer
        if not all(isinstance(k, str) and len(k) < 80 and isinstance(v, str) and _HEX64.fullmatch(v)
                   for k, v in files.items()):
            return answer
        official = _MANIFEST[ver]
        if (all(files.get(k) == h for k, h in official.items()) and set(files) <= set(official)) or (u["name"].lower(), ver) in _tamper_seen:
            return answer
        _tamper_seen.add((u["name"].lower(), ver))
        hook = os.environ.get("NEXORA_TAMPER_WEBHOOK", "")
        if hook.startswith(os.environ.get("NEXORA_WEBHOOK_PREFIX", "https://discord.com/api/webhooks/")):
            async def send():
                try:
                    import aiohttp
                    async with aiohttp.ClientSession() as s:
                        await s.post(hook, json={"content": f"Modified client: {u['name']}\nVersion: Nexora {ver}",
                                                 "allowed_mentions": {"parse": []}}, timeout=aiohttp.ClientTimeout(total=10))
                except Exception:   # noqa: BLE001
                    pass
            asyncio.ensure_future(send())
    except Exception:   # noqa: BLE001 - never show the client an error here
        pass
    return answer


async def toggle_like(request):
    u = me_or_401(request)
    row = get_row(request)
    if DB.execute("SELECT 1 FROM likes WHERE game = ? AND user = ?", (row["id"], u["name"])).fetchone():
        DB.execute("DELETE FROM likes WHERE game = ? AND user = ?", (row["id"], u["name"]))
        liked = False
    else:
        DB.execute("INSERT INTO likes VALUES (?, ?)", (row["id"], u["name"]))
        liked = True
    DB.commit()
    n = DB.execute("SELECT COUNT(*) FROM likes WHERE game = ?", (row["id"],)).fetchone()[0]
    return web.json_response({"ok": True, "liked": liked, "likes": n})


async def servers(request):
    return web.json_response({"ok": True, "servers": room_list(get_row(request)["id"])})


_last_play = {}


async def join(request):
    """Press Play: land in a room of this game that has space (the fullest one), or start a new room."""
    u = me_or_401(request)
    row = get_row(request)
    d = {}
    if request.can_read_body:
        d = await body(request)
    room = None
    want = d.get("room")
    if want is not None:
        room = ROOMS.get(str(want))
        if not room or room.game_id != row["id"]:
            return fail("That server doesn't exist any more.", 404)
        if len(room.players) >= ROOM_MAX:
            return fail("That server is full.", 409)
    else:
        open_rooms = [r for r in ROOMS.values() if r.game_id == row["id"] and len(r.players) < ROOM_MAX]
        if open_rooms:
            room = max(open_rooms, key=lambda r: len(r.players))
        else:
            if len(ROOMS) >= MAX_ROOMS:
                return fail("Nexora is very busy right now. Try again in a minute.", 503)
            room = Room(row["id"], row["name"])
            ROOMS[room.id] = room
    key = (u["name"].lower(), row["id"])
    now = time.time()
    if now - _last_play.get(key, 0) > PLAY_COUNT_GAP:
        _last_play[key] = now
        DB.execute("UPDATE games SET plays = plays + 1 WHERE id = ?", (row["id"],))
        DB.commit()
    return web.json_response({"ok": True, "room": room.id, "name": room.name, "players": len(room.players),
                              "max": ROOM_MAX, "game": row["id"], "official": row["data"] is None})


# ---------------------------------------------------------------- Nexei: wallet, shop, gamepasses
def is_staff(name: str) -> bool:
    return (name or "").lower() in STAFF


def wallet_of(u) -> dict:
    row = DB.execute("SELECT balance, last_daily FROM users WHERE name = ?", (u["name"],)).fetchone()
    wait = max(0, int(row["last_daily"] + DAILY_GAP - time.time()))
    staff = is_staff(u["name"])
    return {"balance": None if staff else int(row["balance"] or 0), "infinite": staff, "daily_in": wait,
            "daily": DAILY_NEXEI}


def item_json(r, owned, me=None) -> dict:
    payload = json.loads(r["payload"]) if r["payload"] else {}
    return {"id": r["id"], "kind": r["kind"], "game": r["game"], "name": r["name"], "desc": r["description"],
            "price": r["price"], "color": r["color"], "creator": r["creator"], "owned": r["id"] in owned,
            "status": r["status"] or "approved", "mine": bool(me and r["creator"] and r["creator"].lower() == me.lower()),
            "tex": payload.get("tex"), "sleeve": payload.get("sleeve"), "acc": payload.get("acc"),
            "bundle": payload.get("bundle"), "hidden": bool(payload.get("hidden"))}


def owned_ids(u) -> set:
    return {r["item"] for r in DB.execute("SELECT item FROM purchases WHERE user = ?", (u["name"],))}


def clean_item(d, kind) -> tuple:
    name = " ".join(str(d.get("name", "")).split())[:40]
    desc = " ".join(str(d.get("desc", "")).split())[:200]
    price = d.get("price")
    if not name:
        raise ValueError("Give it a name.")
    if isinstance(price, bool) or not isinstance(price, int) or not 1 <= price <= MAX_PRICE:
        raise ValueError(f"The price must be a whole number from 1 to {MAX_PRICE:,} Nexei.")
    color = None
    if kind in ("shirt", "pants"):
        color = str(d.get("color", "")).lower()
        if not nw.HEX_RE.fullmatch(color):
            raise ValueError("Pick a colour like #ff8800.")
    return name, desc, price, color


def clean_payload(d, kind) -> dict:
    """The picture of a shirt/pants, or the boxes of an accessory. Checked again here, whatever the client says."""
    import avatar as av
    if kind == "acc":
        a = av.clean_acc({"slot": d.get("slot"), "name": d.get("name"), "boxes": d.get("boxes"), "mesh": d.get("mesh")})
        if not a:
            raise ValueError("An accessory needs a place to wear it (head, face, back or neck) and 1-8 boxes or a 3D model "
                             f"(up to {av.MAX_TRIS} triangles).")
        return {"acc": {k: a[k] for k in ("slot", "boxes", "mesh") if k in a}}
    tex = av.clean_tex(d.get("tex")) if d.get("tex") else None
    if d.get("tex") and not tex:
        raise ValueError("That picture isn't valid. Use a 32x32 (or 8x8) grid with at most 16 colours.")
    out = {"tex": tex} if tex else {}
    if kind == "shirt" and d.get("sleeve"):
        sl = av.clean_sleeve(d.get("sleeve"))
        if not sl:
            raise ValueError("That sleeve picture isn't valid. Use a 16x32 (or 8x16) grid with at most 16 colours.")
        out["sleeve"] = sl
    return out


def can_manage(u, row) -> bool:
    data = json.loads(row["data"]) if row["data"] else {}
    me = u["name"].lower()
    return me == (row["owner"] or "").lower() or me in (str(x).lower() for x in data.get("devs", []))


async def wallet(request):
    return web.json_response({"ok": True, "wallet": wallet_of(me_or_401(request))})


async def claim_daily(request):
    u = me_or_401(request)
    w = wallet_of(u)
    if w["infinite"]:
        return fail("Staff accounts already have unlimited Nexei.")
    if w["daily_in"] > 0:
        return fail(f"Come back in {w['daily_in'] // 3600}h {w['daily_in'] % 3600 // 60}m for your next free Nexei.")
    DB.execute("UPDATE users SET balance = balance + ?, last_daily = ? WHERE name = ?",
               (DAILY_NEXEI, int(time.time()), u["name"]))
    DB.commit()
    return web.json_response({"ok": True, "wallet": wallet_of(u)})


async def shop(request):
    u = me_or_401(request)
    owned = owned_ids(u)
    rows = DB.execute("SELECT * FROM items WHERE kind IN ('shirt','pants','acc') AND "
                      "(COALESCE(status,'approved') = 'approved' OR creator = ?) ORDER BY created DESC",
                      (u["name"],)).fetchall()
    items = [item_json(r, owned, u["name"]) for r in rows]
    # items that come with a bundle ("Legless (Left)") only show up once you own them
    return web.json_response({"ok": True, "items": [i for i in items if not i["hidden"] or i["owned"]]})


async def shop_review_list(request):
    u = me_or_401(request)
    if not is_staff(u["name"]):
        return fail("Only Nexora staff can review items.", 403)
    rows = DB.execute("SELECT * FROM items WHERE status = 'pending' ORDER BY created").fetchall()
    return web.json_response({"ok": True, "items": [item_json(r, set(), u["name"]) for r in rows]})


async def shop_add(request):
    """Anyone signed in can make clothing or an accessory. Staff items go on sale at once; the rest wait for review."""
    u = me_or_401(request)
    if not LIMIT.allow(("make", u["name"].lower()), 10, 3600):
        return fail("You're making items too fast. Try again in a while.", 429)
    d = await body(request)
    kind = d.get("kind")
    if kind not in ("shirt", "pants", "acc"):
        return fail("Make a shirt, pants or accessory.")
    import avatar as av_hide
    if kind == "acc" and d.get("slot") in av_hide.HIDE_SLOTS and not is_staff(u["name"]):
        return fail("Only Nexora staff can make body items (Headless, Legless).", 403)
    try:
        name, desc, price, color = clean_item(d, kind)
        payload = clean_payload(d, kind)
    except ValueError as e:
        return fail(str(e))
    staff = is_staff(u["name"])
    mine = DB.execute("SELECT COUNT(*) AS n, SUM(status = 'pending') AS p FROM items WHERE creator = ? AND kind IN "
                      "('shirt','pants','acc')", (u["name"],)).fetchone()
    if (mine["n"] or 0) >= MAX_ITEMS_PER_USER:
        return fail(f"You can have up to {MAX_ITEMS_PER_USER} items.")
    if not staff and (mine["p"] or 0) >= MAX_PENDING_PER_USER:
        return fail(f"You already have {MAX_PENDING_PER_USER} items waiting for review. Wait for those first.")
    iid = secrets.token_hex(6)
    status = "approved" if staff else "pending"
    DB.execute("INSERT INTO items (id, kind, game, name, description, price, color, creator, created, payload, status) "
               "VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?)",
               (iid, kind, name, desc, price, color, u["name"], int(time.time()), json.dumps(payload), status))
    DB.execute("INSERT OR IGNORE INTO purchases VALUES (?, ?, 0, ?)", (u["name"], iid, int(time.time())))  # you own what you make
    DB.commit()
    return web.json_response({"ok": True, "id": iid, "status": status})


async def shop_review(request):
    u = me_or_401(request)
    if not is_staff(u["name"]):
        return fail("Only Nexora staff can review items.", 403)
    r = DB.execute("SELECT * FROM items WHERE id = ?", (request.match_info["id"][:20],)).fetchone()
    if not r or r["kind"] == "pass":
        return fail("That item doesn't exist.", 404)
    ok = bool((await body(request)).get("approve"))
    DB.execute("UPDATE items SET status = ? WHERE id = ?", ("approved" if ok else "rejected", r["id"]))
    DB.commit()
    return web.json_response({"ok": True, "status": "approved" if ok else "rejected"})


async def item_delete(request):
    u = me_or_401(request)
    r = DB.execute("SELECT * FROM items WHERE id = ?", (request.match_info["id"][:20],)).fetchone()
    if not r:
        return fail("That item doesn't exist.", 404)
    if r["kind"] == "pass":
        g = DB.execute("SELECT * FROM games WHERE id = ?", (r["game"],)).fetchone()
        ok = bool(g and can_manage(u, g))
    else:
        ok = is_staff(u["name"]) or (r["creator"] or "").lower() == u["name"].lower()
    if not ok:
        return fail("You can't remove that.", 403)
    DB.execute("DELETE FROM items WHERE id = ?", (r["id"],))  # people who bought it keep the purchase record
    DB.commit()
    return web.json_response({"ok": True})


async def game_passes(request):
    u = me_or_401(request)
    row = get_row(request)
    owned = owned_ids(u)
    rows = DB.execute("SELECT * FROM items WHERE kind = 'pass' AND game = ? ORDER BY created", (row["id"],)).fetchall()
    return web.json_response({"ok": True, "passes": [item_json(r, owned) for r in rows],
                              "can_manage": can_manage(u, row)})


async def pass_add(request):
    u = me_or_401(request)
    row = get_row(request)
    if row["data"] is None or not can_manage(u, row):
        return fail("Only the creator or a developer of this game can add gamepasses.", 403)
    d = await body(request)
    try:
        name, desc, price, _ = clean_item(d, "pass")
    except ValueError as e:
        return fail(str(e))
    if DB.execute("SELECT COUNT(*) FROM items WHERE kind = 'pass' AND game = ?", (row["id"],)).fetchone()[0] >= MAX_PASSES_PER_GAME:
        return fail(f"A game can have up to {MAX_PASSES_PER_GAME} gamepasses.")
    if DB.execute("SELECT 1 FROM items WHERE kind = 'pass' AND game = ? AND name = ? COLLATE NOCASE",
                  (row["id"], name)).fetchone():
        return fail("This game already has a gamepass with that name.")
    iid = secrets.token_hex(6)
    DB.execute("INSERT INTO items (id, kind, game, name, description, price, color, creator, created, status) "
               "VALUES (?, 'pass', ?, ?, ?, ?, NULL, ?, ?, 'approved')",
               (iid, row["id"], name, desc, price, row["owner"], int(time.time())))
    DB.commit()
    return web.json_response({"ok": True, "id": iid})


async def buy(request):
    u = me_or_401(request)
    if not LIMIT.allow(("buy", u["name"].lower()), 30, 60):
        return fail("Slow down a little.", 429)
    r = DB.execute("SELECT * FROM items WHERE id = ?", (request.match_info["id"][:20],)).fetchone()
    if not r:
        return fail("That item isn't for sale any more.", 404)
    if (r["status"] or "approved") != "approved":
        return fail("That item isn't for sale.", 404)
    if r["id"] in owned_ids(u):
        return fail("You already own this.")
    staff, price = is_staff(u["name"]), r["price"]
    try:
        DB.execute("BEGIN IMMEDIATE")
        if not staff:
            bal = DB.execute("SELECT balance FROM users WHERE name = ?", (u["name"],)).fetchone()["balance"] or 0
            if bal < price:
                DB.execute("ROLLBACK")
                return fail(f"You need {price - bal:,} more Nexei.", 402)
            DB.execute("UPDATE users SET balance = balance - ? WHERE name = ?", (price, u["name"]))
        if r["creator"] and r["creator"].lower() != u["name"].lower():
            DB.execute("UPDATE users SET balance = balance + ? WHERE name = ?", (int(price * SELLER_SHARE), r["creator"]))
        DB.execute("INSERT INTO purchases VALUES (?, ?, ?, ?)", (u["name"], r["id"], 0 if staff else price, int(time.time())))
        for inc in (json.loads(r["payload"]).get("bundle") or []) if r["payload"] else []:   # a bundle gives you its parts too
            DB.execute("INSERT OR IGNORE INTO purchases VALUES (?, ?, 0, ?)", (u["name"], str(inc)[:20], int(time.time())))
        DB.commit()
    except sqlite3.Error:
        DB.rollback()
        return fail("The purchase didn't go through. You were not charged.", 500)
    return web.json_response({"ok": True, "wallet": wallet_of(u), "item": item_json(r, {r["id"]})})


async def my_passes(request):
    """Names of the gamepasses this player owns in one game; the launcher hands them to the game when it starts."""
    u = me_or_401(request)
    row = get_row(request)
    names = [r["name"] for r in DB.execute(
        "SELECT i.name FROM items i JOIN purchases p ON p.item = i.id WHERE p.user = ? AND i.game = ? AND i.kind = 'pass'",
        (u["name"], row["id"]))]
    return web.json_response({"ok": True, "passes": names})


# ---------------------------------------------------------------- rooms (live play)
class Room:
    counter = {}

    def __init__(self, game_id, game_name):
        self.id = secrets.token_urlsafe(6)
        Room.counter[game_id] = Room.counter.get(game_id, 0) + 1
        self.game_id = game_id
        self.name = f"{game_name} #{Room.counter[game_id]}"
        self.players = {}
        self.next_id = 1
        self.empty_since = time.time()

    def pub(self, p):
        return {"id": p["id"], "user": p["user"], "avatar": p["avatar"], "pos": p["pos"], "rot": p["rot"],
                "walk": p["walk"]}

    async def send(self, p, text):
        if p["busy"]:
            return  # this player is slow: skip a frame instead of piling up
        p["busy"] = True
        try:
            await asyncio.wait_for(p["ws"].send_str(text), 3)
        except Exception:
            try:
                await p["ws"].close()
            except Exception:
                pass
        finally:
            p["busy"] = False

    def broadcast(self, obj, skip=None):
        text = json.dumps(obj, separators=(",", ":"))
        for pid, p in list(self.players.items()):
            if pid != skip:
                asyncio.ensure_future(self.send(p, text))


async def ws_room(request):
    user = user_for_token(request.query.get("token", ""))
    room = ROOMS.get(request.match_info["room"])
    ws = web.WebSocketResponse(heartbeat=20, max_msg_size=16 * 1024)
    await ws.prepare(request)
    if not user or not room:
        await ws.send_json({"t": "deny", "reason": "Please sign in again." if not user else "That server is gone."})
        await ws.close()
        return ws
    pid = None
    try:
        first = json.loads(await asyncio.wait_for(ws.receive_str(), 8))
        if first.get("t") != "join" or first.get("v") != nw.PROTOCOL:
            await ws.send_json({"t": "deny", "reason": "Version mismatch - update Nexora."})
            return ws
        old = ONLINE.get((room.id, user["name"].lower()))
        if old is not None:  # same account signed in twice: the newer one wins
            await old.close()
            await asyncio.sleep(0.1)
        if len(room.players) >= ROOM_MAX:
            await ws.send_json({"t": "deny", "reason": "Server is full."})
            return ws
        pid = room.next_id
        room.next_id += 1
        me_ = {"id": pid, "user": user["name"], "avatar": public_user(user)["avatar"],
               "pos": [0.0, 0.0, 0.0], "rot": 0.0, "walk": False, "ws": ws, "busy": False, "last_chat": 0.0}
        ONLINE[(room.id, user["name"].lower())] = ws
        await ws.send_json({"t": "welcome", "id": pid, "game": room.game_id, "name": room.name, "max": ROOM_MAX,
                            "players": [room.pub(p) for p in room.players.values()]})
        room.players[pid] = me_
        room.broadcast({"t": "joined", "p": room.pub(me_)}, skip=pid)
        bucket, stamp = 60.0, time.monotonic()
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                break
            now = time.monotonic()  # at most ~60 messages per second per player
            bucket = min(60.0, bucket + (now - stamp) * 60)
            stamp = now
            bucket -= 1
            if bucket < 0:
                break
            m = json.loads(msg.data)
            t = m.get("t")
            if t == "state":
                x, y, z = (nw._coord(v) for v in m["p"])
                me_["pos"] = [round(x, 2), round(y, 2), round(z, 2)]
                me_["rot"] = round(nw._coord(m.get("r", 0.0), 100000.0), 1)
                me_["walk"] = bool(m.get("w"))
            elif t == "chat":
                text = nw.clean_chat(m.get("m"))
                if text and now - me_["last_chat"] >= nw.CHAT_GAP:
                    me_["last_chat"] = now
                    room.broadcast({"t": "chat", "id": pid, "user": me_["user"], "m": text})
            elif t == "bye":
                break
    except Exception:
        pass  # bad data, timeout or disconnect: drop this player only
    finally:
        if pid in room.players:
            room.players.pop(pid)
            room.broadcast({"t": "left", "id": pid})
            if not room.players:
                room.empty_since = time.time()
        if ONLINE.get((room.id, user["name"].lower() if user else "")) is ws:
            ONLINE.pop((room.id, user["name"].lower()), None)
    return ws


async def ticker(app):
    try:
        while True:
            await asyncio.sleep(nw.TICK)
            now = time.time()
            for rid, r in list(ROOMS.items()):
                if len(r.players) >= 2:
                    r.broadcast({"t": "states", "s": {str(i): [*p["pos"], p["rot"], p["walk"]]
                                                      for i, p in r.players.items()}})
                elif not r.players and now - r.empty_since > EMPTY_ROOM_SECONDS:
                    ROOMS.pop(rid, None)
    except asyncio.CancelledError:
        pass


async def start_background(app):
    app["ticker"] = asyncio.ensure_future(ticker(app))


async def stop_background(app):
    app["ticker"].cancel()


async def home(request):
    return web.Response(text="Nexora server is running.\n")


def make_app() -> web.Application:
    global DB
    DB = open_db()
    seed_official(DB)
    app = web.Application(client_max_size=2 * 1024 * 1024)
    app.add_routes([
        web.get("/", home), web.get("/health", home),
        web.post("/api/register", register), web.post("/api/login", login), web.post("/api/logout", logout),
        web.get("/api/badges", badges), web.get("/api/me", me), web.put("/api/avatar", set_avatar), web.get("/api/users/{name}", user_exists),
        web.get("/api/games", list_games), web.get("/api/games/{id}", game_detail),
        web.get("/api/games/{id}/data", game_data), web.put("/api/games/{id}", publish),
        web.delete("/api/games/{id}", unpublish), web.post("/api/games/{id}/like", toggle_like),
        web.get("/api/games/{id}/servers", servers), web.post("/api/games/{id}/join", join),
        web.post("/api/integrity", integrity), web.post("/api/users/exist", users_exist), web.get("/api/wallet", wallet), web.post("/api/daily", claim_daily),
        web.get("/api/shop", shop), web.post("/api/shop", shop_add), web.get("/api/shop/review", shop_review_list),
        web.post("/api/items/{id}/review", shop_review), web.delete("/api/items/{id}", item_delete),
        web.post("/api/items/{id}/buy", buy),
        web.get("/api/games/{id}/passes", game_passes), web.post("/api/games/{id}/passes", pass_add),
        web.get("/api/games/{id}/mypasses", my_passes),
        web.get("/ws/{room}", ws_room),
    ])
    app.on_startup.append(start_background)
    app.on_cleanup.append(stop_background)
    return app


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    print(f"Nexora server on port {port}, data in {DATA_DIR.resolve()}", flush=True)
    web.run_app(make_app(), host="0.0.0.0", port=port, print=None)
