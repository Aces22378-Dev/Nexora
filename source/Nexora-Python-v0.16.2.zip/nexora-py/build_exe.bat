@echo off
title Build Nexora.exe
cd /d "%~dp0"
echo Installing build tools...
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
  echo Install failed. Make sure Python 3.10+ is installed: https://python.org
  pause
  exit /b 1
)
echo.
echo Building Nexora.exe (this takes a few minutes)...
python -m PyInstaller --noconfirm --clean --windowed --name Nexora --icon assets\icon.ico ^
  --add-data "assets;assets" ^
  --hidden-import runner --hidden-import network --hidden-import servers_ui --hidden-import settings_ui --hidden-import online_ui --hidden-import online --hidden-import websockets --hidden-import games --hidden-import project --hidden-import scripting ^
  --collect-all ursina --collect-all panda3d --collect-all panda3d_gltf --collect-all panda3d_simplepbr ^
  main.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Done: dist\Nexora\Nexora.exe  (keep the whole dist\Nexora folder together)
pause
