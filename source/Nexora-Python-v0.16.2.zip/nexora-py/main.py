"""Nexora - desktop game platform (v0.1). Launcher: accounts, games, servers, people, settings.
Other modes of this same file:
  python main.py --play <game_id> --user <name> [--join host:port]     (a game window, Ursina)
  python main.py --serve <game_id> --name <n> --max <n> --port <p> --owner <user>   (a game server)
"""
import json
import os
import re
import subprocess
import sys
import time
import tkinter as tk

import accounts
import avatar as av_mod
import badges
import integrity
import discordrpc
import theme as th
import games as game_db
import online
from online_ui import OnlineMixin
from servers_ui import ServersMixin
from shop_ui import ShopMixin
from settings_ui import SettingsMixin
from widgets import PANTS, SHIRT, SKIN, ScrollFrame, draw_avatar


def resource_path(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def arg(name, default=None):
    a = sys.argv
    return a[a.index(name) + 1] if name in a and a.index(name) + 1 < len(a) else default


def play_mode() -> bool:
    """Handle the --serve and --play entry points (no launcher window)."""
    if "--serve" in sys.argv:
        import network
        network.run_server(arg("--serve"), arg("--name", "Nexora server"), int(arg("--max", 8)),
                           int(arg("--port", network.DEFAULT_PORT)), arg("--owner", ""))
        return True
    if "--play" not in sys.argv:
        return False
    join = None
    if arg("--join"):
        import network
        join = network.parse_address(arg("--join"))
    import threading
    threading.Thread(target=integrity.report_game, daemon=True).start()   # silent; online games only
    from runner import run
    run(arg("--play"), arg("--user", ""), join, arg("--project"), arg("--room"), arg("--scripts", "0") == "1")
    return True


class App(ServersMixin, SettingsMixin, ShopMixin, OnlineMixin, tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Nexora")
        self.geometry("1180x760")
        self.minsize(1040, 640)
        self._base_scaling = float(self.tk.call("tk", "scaling"))
        for cls in ("Button", "Checkbutton", "Radiobutton", "Scale", "Scrollbar"):
            self.option_add(f"*{cls}.highlightThickness", 0)  # no stray focus outline around controls
        self.configure(bg=th.BG)
        self.imgs = {}
        try:
            for key in ("logo_44", "logo_120", "icon_64"):
                self.imgs[key] = tk.PhotoImage(file=resource_path(f"assets/{key}.png"))
            self.iconphoto(True, self.imgs["icon_64"])
            if sys.platform == "win32":
                self.iconbitmap(resource_path("assets/icon.ico"))
        except tk.TclError:
            pass  # missing/unsupported icon files should never stop the app
        self.user = None
        self.mode = "login"
        self.proc = None
        self.server_proc = None
        self.server_info = None
        self.page = "games"
        self._building = False
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.container = tk.Frame(self, bg=th.BG)
        self.container.pack(fill="both", expand=True)
        self.net = online.Session(persist=True)
        s = accounts.session()
        if online.enabled():  # accounts live on the Nexora server: check the saved sign-in in the background
            if self.net.token:
                self.resume_online()
            else:
                self.show_auth()
        elif s["ok"]:
            self.user = s["user"]
            self.apply_appearance()
            self.show_home(s["user"])
        else:
            self.show_auth()

    def self_cmd(self):
        """Command that starts another copy of this program (game window or server)."""
        if getattr(sys, "frozen", False):
            return [sys.executable]
        return [sys.executable, os.path.abspath(__file__)]

    def apply_appearance(self):
        cfg = accounts.get_settings(self.user["username"])
        th.apply(cfg["theme"])
        self.tk.call("tk", "scaling", self._base_scaling * th.TEXT_SCALE[cfg["text_size"]])
        self.configure(bg=th.BG)
        self.container.configure(bg=th.BG)

    def set_status(self, text):
        lbl = getattr(self, "statusbar", None)
        if lbl is not None and lbl.winfo_exists():
            lbl.configure(text=text)

    def on_close(self):
        for p in (self.proc,):
            if p and p.poll() is None:
                p.terminate()
        self.stop_hosting()
        self.destroy()

    # ---------- helpers ----------
    def clear(self):
        for w in self.container.winfo_children():
            w.destroy()

    def button(self, parent, text, cmd, primary=False, **kw):
        bg = th.ACCENT if primary else th.PANEL2
        b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=th.ON_ACCENT if primary else th.TEXT, activebackground=bg,
                      activeforeground=th.ON_ACCENT if primary else th.TEXT, relief="flat", bd=0, cursor="hand2",
                      font=(th.FONT, 11, "bold"), padx=16, pady=9, **kw)
        return b

    def entry(self, parent, show=None):
        return tk.Entry(parent, bg=th.BG, fg=th.TEXT, insertbackground=th.TEXT, relief="flat", show=show,
                        font=(th.FONT, 12), highlightthickness=1, highlightbackground=th.LINE,
                        highlightcolor=th.ACCENT)

    # ---------- auth ----------
    def show_auth(self):
        self.clear()
        outer = tk.Frame(self.container, bg=th.BG)
        outer.place(relx=0.5, rely=0.5, anchor="center")
        card = tk.Frame(outer, bg=th.PANEL, padx=34, pady=30, highlightthickness=1, highlightbackground=th.LINE)
        card.pack()
        if "logo_120" in self.imgs:
            tk.Label(card, image=self.imgs["logo_120"], bg=th.PANEL).pack()
        tk.Label(card, text="NEXORA", bg=th.PANEL, fg=th.ACCENT, font=(th.FONT, 30, "bold")).pack()
        tk.Label(card, text="Play. Explore. Build.", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 11)).pack(pady=(0, 14))

        tabs = tk.Frame(card, bg=th.PANEL)
        tabs.pack(fill="x", pady=(0, 12))
        self.tab_login = tk.Button(tabs, text="Log in", relief="flat", bd=0, cursor="hand2",
                                   font=(th.FONT, 11, "bold"), command=lambda: self.set_mode("login"))
        self.tab_reg = tk.Button(tabs, text="Sign up", relief="flat", bd=0, cursor="hand2",
                                 font=(th.FONT, 11, "bold"), command=lambda: self.set_mode("register"))
        self.tab_login.pack(side="left", expand=True, fill="x", ipady=6)
        self.tab_reg.pack(side="left", expand=True, fill="x", ipady=6)

        self.e_user = self.entry(card)
        self.e_user.pack(fill="x", ipady=8, pady=4)
        self.e_pass = self.entry(card, show="•")
        self.e_pass.pack(fill="x", ipady=8, pady=4)
        self.err = tk.Label(card, text="", bg=th.PANEL, fg=th.DANGER, font=(th.FONT, 10), width=36, height=2,
                           wraplength=320, justify="center")
        self.err.pack(pady=4)
        self.submit = self.button(card, "Log in", self.do_auth, primary=True)
        self.submit.pack(fill="x")
        self.auth_server_row(card)
        self.e_user.bind("<Return>", lambda e: self.do_auth())
        self.e_pass.bind("<Return>", lambda e: self.do_auth())
        self.set_mode("login")
        self.e_user.focus_set()

    def set_mode(self, mode):
        self.mode = mode
        for btn, name in ((self.tab_login, "login"), (self.tab_reg, "register")):
            on = mode == name
            btn.configure(bg=th.PANEL2 if on else th.PANEL, fg=th.TEXT if on else th.DIM, activebackground=th.PANEL2,
                          activeforeground=th.TEXT)
        self.submit.configure(text="Log in" if mode == "login" else "Create account")
        if mode == "register":
            self.err.configure(text="Username: 3-20 letters, numbers or underscores. No spaces.", fg=th.DIM)
        else:
            self.err.configure(text="", fg=th.DANGER)

    def do_auth(self):
        u, p = self.e_user.get(), self.e_pass.get()
        if self.mode == "register" and not re.fullmatch(r"[A-Za-z0-9_]{3,20}", u.strip()):
            self.err.configure(text="No spaces or symbols. Use 3-20 letters, numbers or underscores.", fg=th.DANGER)
            return
        self.err.configure(fg=th.DANGER)
        if online.enabled():
            self.do_auth_online(u, p)
            return
        res = accounts.login(u, p) if self.mode == "login" else accounts.register(u, p)
        if not res["ok"]:
            self.err.configure(text=res["error"])
            return
        self.show_home(res["user"])

    def fill_name_slot(self):
        slot = getattr(self, "name_slot", None)
        if slot is not None and slot.winfo_exists() and getattr(self, "user", None):
            badges.fill_row(slot, [("name", self.user["username"])], th.PANEL, th.TEXT, (th.FONT, 11, "bold"))

    def names_changed(self):
        """The badge list arrived: draw the names again, with their badges."""
        self.fill_name_slot()
        if getattr(self, "page", None) and hasattr(self, f"page_{self.page}") and self.page not in ("avatar", "settings"):
            try:
                self.show_page(self.page)
            except tk.TclError:
                pass

    # ---------- home ----------
    def show_home(self, user, page="games"):
        self.user = user
        self.apply_appearance()
        self.clear()
        top = tk.Frame(self.container, bg=th.PANEL, padx=22, pady=12)
        top.pack(fill="x")
        if "logo_44" in self.imgs:
            tk.Label(top, image=self.imgs["logo_44"], bg=th.PANEL).pack(side="left", padx=(0, 8))
        tk.Label(top, text="NEXORA", bg=th.PANEL, fg=th.ACCENT, font=(th.FONT, 18, "bold")).pack(side="left")
        self.nav = {}
        for key, label in (("games", "Games"), ("servers", "Servers"), ("people", "People"),
                           ("shop", "Shop"), ("avatar", "Avatar"), ("settings", "Settings")):
            b = tk.Button(top, text=label, relief="flat", bd=0, cursor="hand2", font=(th.FONT, 11, "bold"),
                          padx=12, pady=6, command=lambda k=key: self.show_page(k))
            b.pack(side="left", padx=(14 if key == "games" else 2, 0))
            self.nav[key] = b
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self.on_search())
        se = self.entry(top)
        se.configure(textvariable=self.search_var, width=15)
        se.pack(side="left", padx=24, ipady=6)
        self.button(top, "Log out", self.do_logout).pack(side="right")
        self.wallet_lbl = tk.Label(top, text=self.wallet_text() if self.online_ready() else "", bg=th.PANEL, fg=th.CYAN,
                                   font=(th.FONT, 11, "bold"), cursor="hand2")
        self.wallet_lbl.pack(side="right", padx=14)
        self.wallet_lbl.bind("<Button-1>", lambda e: self.show_page("shop"))
        self.refresh_wallet()
        badges.note_self(user)
        self.name_slot = tk.Frame(top, bg=th.PANEL)
        self.name_slot.pack(side="right", padx=14)
        self.fill_name_slot()
        if self.online_ready():   # who has a badge: fetched in the background, names redraw when it arrives
            self.bg(lambda: badges.load(), lambda changed, err: changed and self.names_changed())
            self.bg(lambda: integrity.report(self.net, user["username"]), lambda r, e: None)

        self.statusbar = tk.Label(self.container, text="", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 10),
                                  anchor="w", padx=22, pady=4)
        self.statusbar.pack(side="bottom", fill="x")
        self.notice_bar = tk.Label(self.container, text="", bg=th.ACCENT, fg="white", font=(th.FONT, 11, "bold"),
                                   anchor="w", padx=22, pady=6, wraplength=1000, justify="left")
        self.body = tk.Frame(self.container, bg=th.BG, padx=24, pady=16)
        self.body.pack(fill="both", expand=True)
        self.show_page(page)
        self.live_start()

    # ---------- live updates ----------
    LIVE_SECS = int(os.environ.get("NEXORA_LIVE_SECS", "20"))   # (the variable is only for testing)

    def live_start(self):
        """While signed in to a server: every few seconds refresh the announcement banner, the games list, drop
        deleted accounts from People and friends, and sign out an account that was banned or deleted."""
        self.live_gen = getattr(self, "live_gen", 0) + 1
        if self.online_ready():
            gen = self.live_gen
            self.after(1500, lambda: self.live_tick(gen))

    def set_notice(self, text):
        bar = getattr(self, "notice_bar", None)
        if bar is None or not bar.winfo_exists():
            return
        if text:
            bar.configure(text="\U0001F4E2  " + text)
            if not bar.winfo_ismapped():
                bar.pack(fill="x", before=self.body)
        elif bar.winfo_ismapped():
            bar.pack_forget()

    def live_tick(self, gen):
        if gen != getattr(self, "live_gen", 0) or not self.user or not self.online_ready():
            return
        me = self.user["username"]
        names = [n for n in accounts.online_mirror_names() if n.lower() != me.lower()][:60]

        def work():
            r = {}
            try:
                r["notice"] = self.net.notice()
            except online.OnlineError:
                pass
            try:
                self.net.request("GET", "/api/me")
            except online.OnlineError as e:
                if e.status in (401, 403):   # the server answered: the account is banned, deleted or signed out
                    r["out"] = str(e) if e.status == 403 else "You were signed out. Please sign in again."
                    return r
            try:
                r["games"] = self.net.games()
                if names:
                    r["exist"] = self.net.users_exist(names)
            except online.OnlineError:
                pass
            return r

        def done(r, err):
            if gen != getattr(self, "live_gen", 0) or not self.user:
                return
            if r and r.get("out"):
                self.live_sign_out(r["out"])
                return
            if r:
                if "notice" in r:
                    self.set_notice(r["notice"])
                if r.get("games") is not None:
                    fresh = {g["id"]: g for g in r["games"]}
                    changed = set(fresh) != set(self.catalog)
                    self.catalog = fresh
                    if changed and self.page == "games" and not self.search_var.get():
                        self.render_games()
                if r.get("exist") is not None:
                    have = {n.lower() for n in r["exist"]}
                    gone = accounts.remove_gone([n for n in names if n.lower() not in have])
                    if gone:
                        self.update_badges()
                        if self.page == "people":
                            self.render_people()
            self.after(self.LIVE_SECS * 1000, lambda: self.live_tick(gen))
        self.bg(work, done)

    def live_sign_out(self, message):
        self.live_gen += 1
        self.stop_hosting()
        self.net.token = ""
        accounts.logout()
        self.user = None
        self.show_auth()
        self.err.configure(text=message, fg=th.DANGER)

    # ---------- pages ----------
    def show_page(self, name):
        self._building = True
        self.page = name
        self.search_var.set("")
        for w in self.body.winfo_children():
            w.destroy()
        for key, b in self.nav.items():
            on = key == name
            b.configure(bg=th.PANEL2 if on else th.PANEL, fg=th.TEXT if on else th.DIM,
                        activebackground=th.PANEL2, activeforeground=th.TEXT)
        self.update_badges()
        getattr(self, f"page_{name}")()
        self._building = False

    def update_badges(self):
        """Put a count on People when friend requests are waiting (if the user wants that)."""
        me = accounts.get_user(self.user["username"])
        if me["ok"]:
            self.user = me["user"]
        n = len(self.user["incoming"]) if accounts.get_settings(self.user["username"])["notify_requests"] else 0
        self.nav["people"].configure(text=f"People ({n})" if n else "People")

    def on_search(self):
        if self._building:
            return
        if self.page == "games":
            self.render_games()
        elif self.page == "people":
            self.render_people()
        elif self.page == "servers" and hasattr(self, "srv_host"):
            self.render_servers()

    def page_games(self):
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        self.grid_frame = sf.inner
        self.render_games()
        self.refresh_catalog(then=lambda: self.page == "games" and self.render_games())

    # ----- People: friends, requests, find users -----
    def page_people(self):
        tk.Label(self.body, text="People", bg=th.BG, fg=th.TEXT, font=(th.FONT, 18, "bold")).pack(anchor="w")
        tk.Label(self.body, text="Type in the search box above to find users on this PC.", bg=th.BG, fg=th.DIM,
                 font=(th.FONT, 10)).pack(anchor="w", pady=(0, 6))
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True)
        self.people_host = sf.inner
        self.render_people()

    def person_row(self, name, buttons):
        p = accounts.profile(name, self.user["username"])
        av = p["user"]["avatar"] if p["ok"] else accounts.DEFAULT_AVATAR
        row = tk.Frame(self.people_host, bg=th.PANEL, padx=12, pady=8, highlightthickness=1,
                       highlightbackground=th.LINE)
        row.pack(fill="x", pady=4)
        c = tk.Canvas(row, width=34, height=60, bg=th.PANEL, highlightthickness=0)
        c.pack(side="left")
        draw_avatar(c, av, s=2, ox=1, oy=2)
        badges.name_row(row, name, th.PANEL, th.TEXT, (th.FONT, 12, "bold"), side="left", padx=12)
        for text, cmd, primary in reversed(buttons):
            self.button(row, text, cmd, primary=primary).pack(side="right", padx=4)

    def friend_action(self, fn, name):
        res = fn(self.user["username"], name)
        if res.get("ok"):
            self.user = res["user"]
            self.set_status("")
        else:
            self.set_status(res.get("error", "That didn't work."))
        self.render_people()
        self.update_badges()

    def render_people(self):
        for w in self.people_host.winfo_children():
            w.destroy()
        me = accounts.get_user(self.user["username"])
        if me["ok"]:
            self.user = me["user"]
        u = self.user
        q = self.search_var.get().strip().lower()

        def section(title):
            tk.Label(self.people_host, text=title, bg=th.BG, fg=th.TEXT, font=(th.FONT, 13, "bold")).pack(
                anchor="w", pady=(14, 2))

        def note(text):
            tk.Label(self.people_host, text=text, bg=th.BG, fg=th.DIM, font=(th.FONT, 10)).pack(anchor="w")

        view = lambda n: ("View", lambda: self.view_profile(n), False)
        if u["incoming"]:
            section(f"Friend requests ({len(u['incoming'])})")
            for n in u["incoming"]:
                self.person_row(n, [view(n),
                                    ("Accept", lambda n=n: self.friend_action(accounts.accept_request, n), True),
                                    ("Decline", lambda n=n: self.friend_action(accounts.decline_request, n), False)])
        section(f"Friends ({len(u['friends'])})")
        friends = [f for f in u["friends"] if q in f.lower()]
        if not friends:
            note("No friends yet. Find someone below." if not u["friends"] else "No friends match your search.")
        for n in friends:
            self.person_row(n, [view(n),
                                ("Remove", lambda n=n: self.friend_action(accounts.remove_friend, n), False)])
        section("Find users")
        found = [r for r in accounts.search_users(q, u["username"]) if r["friend_status"] in ("none", "outgoing")]
        if not found:
            note("No other users found." if not q else "No users match your search.")
        for r in found:
            n = r["username"]
            if r["friend_status"] == "outgoing":
                act = ("Pending (cancel)", lambda n=n: self.friend_action(accounts.cancel_request, n), False)
            else:
                act = ("Add friend", lambda n=n: self.friend_action(accounts.send_request, n), True)
            self.person_row(n, [view(n), act])

    def view_profile(self, name):
        win = tk.Toplevel(self)
        win.title(name)
        win.configure(bg=th.PANEL)
        win.geometry("340x470")
        win.transient(self)
        holder = tk.Frame(win, bg=th.PANEL)
        holder.pack(fill="both", expand=True)

        def act(fn):
            res = fn(self.user["username"], name)
            if res.get("ok"):
                self.user = res["user"]
            else:
                self.set_status(res.get("error", "That didn't work."))
            build()
            if self.page == "people":
                self.render_people()

        def build():
            for w in holder.winfo_children():
                w.destroy()
            p = accounts.profile(name, self.user["username"])
            if not p["ok"]:
                tk.Label(holder, text="User not found.", bg=th.PANEL, fg=th.DIM).pack(pady=40)
                return
            pu = p["user"]
            c = tk.Canvas(holder, width=16 * 8 + 20, height=28 * 8 + 20, bg=th.PANEL, highlightthickness=0)
            c.pack(pady=(18, 6))
            draw_avatar(c, pu["avatar"], s=8, ox=10, oy=10)
            badges.name_row(holder, pu["username"], th.PANEL, th.TEXT, (th.FONT, 18, "bold"), size=28)
            joined = time.strftime("%b %d, %Y", time.localtime(pu["created"]))
            stats = (f"{pu['total_plays']} plays  |  {pu['friend_count']} friends"
                     if pu["total_plays"] is not None else "Stats are private")
            tk.Label(holder, text=f"Joined {joined}  |  {stats}",
                     bg=th.PANEL, fg=th.DIM, font=(th.FONT, 10)).pack(pady=8)
            st = pu["friend_status"]
            if st == "self":
                tk.Label(holder, text="This is you", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 11)).pack(pady=6)
            elif st == "friends":
                self.button(holder, "Remove friend", lambda: act(accounts.remove_friend)).pack(pady=6)
            elif st == "incoming":
                self.button(holder, "Accept friend request", lambda: act(accounts.accept_request),
                            primary=True).pack(pady=6)
            elif st == "outgoing":
                self.button(holder, "Request sent (cancel)", lambda: act(accounts.cancel_request)).pack(pady=6)
            else:
                self.button(holder, "Add friend", lambda: act(accounts.send_request), primary=True).pack(pady=6)

        build()

    # ----- Avatar editor -----
    def page_avatar(self):
        tk.Label(self.body, text="Your avatar", bg=th.BG, fg=th.TEXT, font=(th.FONT, 18, "bold")).pack(anchor="w", pady=(0, 14))
        wrap = tk.Frame(self.body, bg=th.BG)
        wrap.pack(anchor="w")
        self.edit_av = dict(self.user["avatar"])
        self.av_canvas = tk.Canvas(wrap, width=16 * 10 + 20, height=34 * 10 + 20, bg=th.PANEL,
                                   highlightthickness=1, highlightbackground=th.LINE)
        self.av_canvas.pack(side="left", padx=(0, 30))
        ctl = tk.Frame(wrap, bg=th.BG)
        ctl.pack(side="left", anchor="n")
        for part, label, palette in (("skin", "Skin", SKIN), ("shirt", "Shirt", SHIRT), ("pants", "Pants", PANTS)):
            tk.Label(ctl, text=label, bg=th.BG, fg=th.DIM, font=(th.FONT, 11, "bold")).pack(anchor="w", pady=(0, 4))
            row = tk.Frame(ctl, bg=th.BG)
            row.pack(anchor="w", pady=(0, 14))
            for col in palette:
                tk.Button(row, bg=col, activebackground=col, width=3, relief="flat", bd=0, cursor="hand2",
                          command=lambda p=part, c=col: self.pick_color(p, c)).pack(side="left", padx=3)
        tk.Label(ctl, text="Body", bg=th.BG, fg=th.DIM, font=(th.FONT, 11, "bold")).pack(anchor="w", pady=(0, 4))
        brow = tk.Frame(ctl, bg=th.BG)
        brow.pack(anchor="w", pady=(0, 8))
        self.body_btns = {}
        for kind in av_mod.BODIES:
            b = tk.Button(brow, text=kind.title(), relief="flat", bd=0, cursor="hand2", font=(th.FONT, 10, "bold"),
                          padx=14, pady=5, activebackground=th.PANEL2, activeforeground=th.TEXT,
                          command=lambda k=kind: self.set_body(k))
            b.pack(side="left", padx=(0, 4))
            self.body_btns[kind] = b
        tk.Button(brow, text="Custom skin colour...", relief="flat", bd=0, cursor="hand2", font=(th.FONT, 10),
                  padx=12, pady=5, bg=th.PANEL, fg=th.TEXT, activebackground=th.PANEL2,
                  command=self.pick_skin_custom).pack(side="left", padx=(10, 0))
        self.size_vars = {}
        for key, label in (("height", "Height"), ("width", "Width")):
            line = tk.Frame(ctl, bg=th.BG)
            line.pack(anchor="w", pady=2)
            tk.Label(line, text=label, bg=th.BG, fg=th.TEXT, font=(th.FONT, 10), width=7, anchor="w").pack(side="left")
            var = tk.IntVar(value=round((self.edit_av.get(key) or 1.0) * 100))
            self.size_vars[key] = var
            tk.Scale(line, from_=round(av_mod.SIZE_RANGE[0] * 100), to=round(av_mod.SIZE_RANGE[1] * 100), orient="horizontal",
                     variable=var, length=220, showvalue=True, resolution=1, bg=th.BG, fg=th.TEXT, troughcolor=th.PANEL,
                     highlightthickness=0, bd=0, command=lambda _v, k=key: self.set_size(k)).pack(side="left")
            tk.Label(line, text="%", bg=th.BG, fg=th.DIM, font=(th.FONT, 10)).pack(side="left")
        tk.Button(ctl, text="Reset size", relief="flat", bd=0, cursor="hand2", font=(th.FONT, 9), padx=10, pady=3,
                  bg=th.PANEL, fg=th.DIM, activebackground=th.PANEL2, command=self.reset_size).pack(anchor="w", pady=(2, 14))
        self.refresh_body_buttons()
        self.button(ctl, "Save avatar", self.save_avatar, primary=True).pack(anchor="w")
        self.av_status = tk.Label(ctl, text="", bg=th.BG, fg=th.CYAN, font=(th.FONT, 10))
        self.av_status.pack(anchor="w", pady=6)
        self.redraw_avatar()

    def redraw_avatar(self):
        self.av_canvas.delete("all")
        draw_avatar(self.av_canvas, self.edit_av, s=10, ox=10, oy=10, top=6)

    def refresh_body_buttons(self):
        cur = self.edit_av.get("body") or "male"
        for kind, b in self.body_btns.items():
            on = kind == cur
            b.configure(bg=th.PANEL2 if on else th.PANEL, fg=th.TEXT if on else th.DIM)

    def set_body(self, kind):
        self.edit_av["body"] = kind
        self.refresh_body_buttons()
        self.av_status.configure(text="")
        self.redraw_avatar()

    def set_size(self, key):
        self.edit_av[key] = self.size_vars[key].get() / 100
        self.av_status.configure(text="")
        self.redraw_avatar()

    def reset_size(self):
        for key, var in self.size_vars.items():
            var.set(100)
            self.edit_av[key] = 1.0
        self.redraw_avatar()

    def pick_skin_custom(self):
        from tkinter import colorchooser
        c = colorchooser.askcolor(color=self.edit_av.get("skin", "#f1c27d"), parent=self)[1]
        if c:
            self.pick_color("skin", c.lower())

    def pick_color(self, part, col):
        self.edit_av[part] = col
        if part in ("shirt", "pants"):  # a plain colour replaces a shop shirt/pants
            self.edit_av[part + "_item"] = None
            self.edit_av[part + "_tex"] = None
            if part == "shirt":
                self.edit_av["sleeve_tex"] = None
        self.av_status.configure(text="")
        self.redraw_avatar()

    def save_avatar(self):
        res = accounts.set_avatar(self.user["username"], self.edit_av)
        if res["ok"]:
            self.user = res["user"]
            if self.online_ready():
                def synced(res, err):
                    if res:  # the server's answer is the truth: it only lets you wear what you own
                        out = accounts.set_avatar(self.user["username"], res)
                        if out["ok"]:
                            self.user = out["user"]
                av = {**self.edit_av, "acc": [{"id": a["id"]} for a in self.edit_av.get("acc", [])]}
                self.bg(lambda: self.net.set_avatar(av), synced)
            self.av_status.configure(text="Saved! You'll look like this in games.")
        else:
            self.av_status.configure(text=res.get("error", "Could not save."))

    # ----- favourites, continue, recommendations -----
    def fav_ids(self) -> list:
        return accounts.get_settings(self.user["username"])["favorites"]

    def recent_ids(self) -> list:
        return accounts.get_settings(self.user["username"])["recent"]

    def is_fav(self, gid) -> bool:
        return gid in self.fav_ids()

    def toggle_fav(self, gid):
        favs = self.fav_ids()
        favs = [f for f in favs if f != gid] if gid in favs else [gid] + favs
        res = accounts.set_settings(self.user["username"], {"favorites": favs[:100]})
        if not res["ok"]:
            self.set_status(res.get("error", "Could not save favourites."))
        return gid in favs

    def note_played(self, gid):
        if not gid or not self.user:
            return
        rec = [gid] + [r for r in self.recent_ids() if r != gid]
        accounts.set_settings(self.user["username"], {"recent": rec[:12]})

    def recommended(self, pool, taken, limit=6) -> list:
        """Games not already shown above, best first. Liked/played games and creators the player favours rank higher."""
        liked_owners = {g.get("owner") for g in pool if g["id"] in taken and g.get("owner") and g.get("owner") != "Nexora"}
        out = []
        for g in pool:
            if g["id"] in taken:
                continue
            st = self.catalog.get(g["id"]) or {}
            score = st.get("likes", 0) * 3 + st.get("plays", 0) + st.get("playing", 0) * 5
            if g.get("owner") in liked_owners:
                score += 50
            out.append((score, g))
        out.sort(key=lambda t: -t[0])
        return [g for _, g in out[:limit]]

    def section(self, title, games, start_row):
        """A heading and a grid of cards; returns the next free row."""
        tk.Label(self.grid_frame, text=title, bg=th.BG, fg=th.TEXT, font=(th.FONT, 16, "bold")).grid(
            row=start_row, column=0, columnspan=3, sticky="w", padx=9, pady=(14 if start_row else 0, 2))
        for i, g in enumerate(games):
            self.game_card(g, start_row + 1 + i // 3, i % 3)
        return start_row + 1 + (len(games) + 2) // 3

    def game_card(self, g, row, col):
        card = tk.Frame(self.grid_frame, bg=th.PANEL, highlightthickness=1, highlightbackground=th.LINE, cursor="hand2")
        card.grid(row=row, column=col, padx=9, pady=9, sticky="n")
        thumb = tk.Label(card, text=g["emoji"], bg=g["thumb"], fg="white", font=("Segoe UI Emoji", 38), width=8, height=2)
        thumb.pack(fill="x")
        tk.Label(card, text=g["name"], bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 13, "bold"),
                 anchor="w").pack(fill="x", padx=12, pady=(10, 0))
        tk.Label(card, text=g["desc"], bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9), anchor="w",
                 wraplength=210, justify="left").pack(fill="x", padx=12, pady=(2, 6))
        by = g.get("owner") or ""
        if by:
            badges.name_row(card, by, th.PANEL, th.CYAN, (th.FONT, 9), prefix="by ",
                            suffix=("  \U0001F6E0" if by != "Nexora" else ""), fill="x", padx=12)
        st = self.catalog.get(g["id"])
        stats = f"\U0001F441 {st['plays']:,}   \U0001F44D {st['likes']:,}   \U0001F7E2 {st['playing']}" if st else " "
        tk.Label(card, text=stats, bg=th.PANEL, fg=th.DIM, font=("Segoe UI Emoji", 9), anchor="w").pack(
            fill="x", padx=12, pady=(4, 12))

        def bind_all(w):
            w.bind("<Button-1>", lambda e: self.show_game(g))
            for c in w.winfo_children():
                bind_all(c)
        bind_all(card)
        star = tk.Label(card, text="\u2605" if self.is_fav(g["id"]) else "\u2606", bg=g["thumb"],
                        fg="#ffd54a", font=(th.FONT, 18), cursor="hand2")
        star.place(relx=1.0, x=-8, y=4, anchor="ne")
        star.bind("<Button-1>", lambda e, gid=g["id"]: (self.toggle_fav(gid), self.render_games()) and None)

    def render_games(self):
        for w in self.grid_frame.winfo_children():
            w.destroy()
        q = self.search_var.get().strip().lower()
        pool = self.all_games_online() if self.online_ready() else game_db.all_games()
        by_id = {g["id"]: g for g in pool}
        if q:
            games = [g for g in pool if q in g["name"].lower() or q in g["desc"].lower()
                     or q in (g.get("owner") or "").lower()]
            if not games:
                tk.Label(self.grid_frame, text="No games match your search.", bg=th.BG, fg=th.DIM).grid(
                    row=0, column=0, sticky="w")
                return
            self.section("Results", games, 0)
            return
        row = 0
        recent = [by_id[i] for i in self.recent_ids() if i in by_id][:3]
        if recent:
            row = self.section("Continue", recent, row)
        favs = [by_id[i] for i in self.fav_ids() if i in by_id]
        if favs:
            row = self.section("Favorites", favs, row)
        taken = {g["id"] for g in recent} | {g["id"] for g in favs}
        recs = self.recommended(pool, taken)
        if recs:
            row = self.section("Recommended", recs, row)
        rest = [g for g in pool if g["id"] not in taken and g not in recs]
        if rest:
            row = self.section("All games" if (recent or favs or recs) else "Discover", rest, row)

    def launch(self, game_id, join=None, extra=None, online_room=False, passes=None, rpc_name=None):
        if self.proc and self.proc.poll() is None:
            self.set_status("A game is already running.")
            return
        if (join or online_room) and self.online_blocked():
            self.set_status("Parental controls: online play is turned off.")
            return
        cmd = self.self_cmd() + ["--play", game_id or "plaza", "--user", self.user["username"]]
        if join:
            cmd += ["--join", f"{join[0]}:{join[1]}"]
        cmd += extra or []
        env = dict(os.environ, NEXORA_TOKEN=self.net.token) if online_room and self.net.token else None
        if env is not None:
            env["NEXORA_PASSES"] = json.dumps(passes or [])
        accounts.pop_last_error()  # forget any old message
        self.note_played(game_id)
        try:
            self.proc = subprocess.Popen(cmd, env=env)
        except OSError as e:
            self.set_status(f"Could not start game: {e.strerror or e}")
            return
        self.set_status("Joining the server..." if (join or online_room) else "Game running... (Esc inside the game to leave)")
        self.rpc_playing(game_id, join, online_room, extra, rpc_name)
        self.after(700, self.poll_game)

    def rpc_playing(self, game_id, join, online_room, extra, rpc_name=None):
        """Tell Discord which game this is and where (alone, a LAN server, or an online server with a player count)."""
        g = game_db.get_game(game_id) if game_id else None
        name = rpc_name or (g["name"] if g else "a game")
        discordrpc.set(details=f"Playing {name}", state="On an online server" if online_room else
                       ("On a server" if join else "Playing alone"))
        room = None
        if online_room and extra and "--room" in extra:
            room = extra[extra.index("--room") + 1]
        if room:
            self.rpc_party(game_id, room, name)

    def rpc_party(self, game_id, room, name):
        """While the online game runs, refresh 'x of y players' on Discord every 20 seconds."""
        if not (self.proc and self.proc.poll() is None):
            return

        def work():
            return [r for r in self.net.servers(game_id) if r["id"] == room]

        def done(res, err):
            if not err and res and self.proc and self.proc.poll() is None:
                discordrpc.set(details=f"Playing {name}", state="On an online server", party=(res[0]["players"], res[0]["max"]))
            self.after(20000, lambda: self.rpc_party(game_id, room, name))
        self.bg(work, done)

    def poll_game(self):
        if self.proc and self.proc.poll() is None:
            self.after(700, self.poll_game)
            return
        code = self.proc.returncode if self.proc else 0
        self.proc = None
        discordrpc.set(details="Browsing games")
        if not self.user:  # logged out while the game was running
            return
        res = accounts.get_user(self.user["username"])
        if res["ok"]:
            self.user = res["user"]
        err = accounts.pop_last_error()
        if code == 0:
            self.set_status("")
        elif err:
            self.set_status(err)
        else:
            self.set_status("The game closed with an error. Is 'ursina' installed? (pip install ursina)")
        if self.page == "games":
            self.render_games()
        elif self.page == "game":
            self.load_detail_once()
        elif self.page == "servers" and hasattr(self, "srv_host"):
            self.refresh_servers()

    def do_logout(self):
        self.stop_hosting()
        if online.enabled():
            self.bg(self.net.logout, lambda r, e: None)
            self.net.token = ""
        accounts.logout()
        self.user = None
        self.show_auth()


if __name__ == "__main__":
    import bootstrap
    if not any(a in sys.argv for a in ("--play", "--serve")) and not bootstrap.ensure_dependencies("Nexora"):
        sys.exit(1)
    if not play_mode():
        discordrpc.set(details="Browsing games")
        discordrpc.start("nexora")  # "Playing Nexora" on Discord
        app = App()
        bootstrap.close_splash()
        app.mainloop()
