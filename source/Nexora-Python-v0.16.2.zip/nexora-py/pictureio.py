"""Turn a PNG / JPG / GIF / BMP / WEBP into the picture of a shirt front, pants or sleeves (see avatar.py)."""
import avatar as av

EXTS = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp")


class PictureError(Exception):
    pass


def to_texture(path, w=av.TEX, h=av.TEX):
    """{"pal": [...up to 16 colours], "px": w*h characters}. See-through pixels stay empty (the garment colour shows there).
    The picture is squashed to w x h by averaging, then its colours are reduced to 16, so pixel art whose size is a
    multiple of w x h comes out unchanged and a photo comes out soft."""
    from PIL import Image, UnidentifiedImageError
    try:
        im = Image.open(path)
        im.load()
    except (OSError, UnidentifiedImageError, Image.DecompressionBombError):
        raise PictureError("Couldn't read that picture. Use a PNG or JPG.")
    if im.width * im.height > 40_000_000:
        raise PictureError("That picture is far too big. Use one under about 4000 x 4000 pixels.")
    im = im.convert("RGBA").resize((w, h), Image.BOX)
    opaque = [(i, p[:3]) for i, p in enumerate(im.getdata()) if p[3] >= 128]
    if not opaque:
        raise PictureError("That picture is completely see-through.")
    colors = sorted({c for _i, c in opaque})
    if len(colors) > av.MAX_PAL:
        strip = Image.new("RGB", (len(opaque), 1))
        strip.putdata([c for _i, c in opaque])
        q = strip.quantize(colors=av.MAX_PAL, method=Image.Quantize.MEDIANCUT)
        flat = q.getpalette()
        used = sorted(set(q.getdata()))
        pal_rgb = [tuple(flat[i * 3:i * 3 + 3]) for i in used]
        index = {u: n for n, u in enumerate(used)}
        picks = {i: index[v] for (i, _c), v in zip(opaque, q.getdata())}
    else:
        pal_rgb = colors
        picks = {i: colors.index(c) for i, c in opaque}
    px = "".join(av.PAL_CHARS[picks[i]] if i in picks else "." for i in range(w * h))
    return {"pal": ["#%02x%02x%02x" % c for c in pal_rgb], "px": px}
