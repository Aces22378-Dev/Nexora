"""Copy the accounts you made on this PC (local mode) into a Nexora server's database, keeping their passwords.

Stop the server first, then run this in the same folder you start the server from:
    py import_local_accounts.py                  (server data folder: .\\nexora-data)
    py import_local_accounts.py C:\\path\\to\\nexora-data
Then start the server again. Anyone already on the server is skipped. Friends and settings stay on this PC.
"""
import json
import os
import re
import sqlite3
import sys
import time
from pathlib import Path

import accounts

NAME_RE = re.compile(r"[A-Za-z0-9_]{3,20}")


def run(data_dir: Path, local_db: dict) -> dict:
    import nexora_server as ns
    ns.DATA_DIR = data_dir
    db = ns.open_db()
    done, skipped = [], []
    for key, u in local_db.get("users", {}).items():
        name = u.get("username", key)
        if not NAME_RE.fullmatch(name) or name.lower() in accounts.RESERVED_NAMES:
            skipped.append((name, "name not allowed on a server"))
            continue
        if db.execute("SELECT 1 FROM users WHERE name = ?", (name,)).fetchone():
            skipped.append((name, "already on the server"))
            continue
        db.execute("INSERT INTO users (name, salt, hash, created, avatar) VALUES (?, ?, ?, ?, ?)",
                   (name, u["salt"], u["hash"], int(u.get("created") or time.time()),
                    json.dumps(u.get("avatar") or {})))
        done.append(name)
    db.commit()
    if hasattr(db, "flush"):
        db.flush()  # D1 backup, if it is on
    return {"imported": done, "skipped": skipped}


if __name__ == "__main__":
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else os.environ.get("NEXORA_DATA", "nexora-data"))
    res = run(folder, accounts._load())
    print(f"Server data folder: {folder.resolve()}")
    print("Imported:", ", ".join(res["imported"]) or "nobody")
    for n, why in res["skipped"]:
        print(f"Skipped {n}: {why}")
