"""Talks to the Nexora online server (nexora_server.py) over HTTPS. No extra libraries needed.

Nexora and Nexora Studio always use DEFAULT_SERVER: players cannot pick a server. (This is only the app's own setting;
the real protection is that the server decides everything: accounts, Nexei, what you own.)
For development, two environment variables change that: NEXORA_SERVER=<address> points the apps at another server
(NEXORA_SERVER= with nothing after it means local accounts only), and NEXORA_ALLOW_SERVER_CHANGE=1 brings back the
"Server..." button, which stores its choice in the Nexora data folder (online.json).
"""
import json
import os
import urllib.error
import urllib.parse
import urllib.request

import accounts

TIMEOUT = 12
DEFAULT_SERVER = "https://nexora-server.minecraftmobileexplorer.workers.dev"


class OnlineError(Exception):
    """A readable problem: wrong password, server unreachable, not allowed..."""
    status = 0   # the server's HTTP status when it answered (401 signed out, 403 banned); 0 when it couldn't be reached


def _file():
    return accounts.data_dir() / "online.json"


def _read() -> dict:
    try:
        d = json.loads(_file().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(d: dict) -> None:
    try:
        _file().write_text(json.dumps(d), encoding="utf-8")
    except OSError:
        pass


def normalize_url(text: str) -> str:
    t = (text or "").strip().rstrip("/")
    if not t:
        return ""
    if "://" not in t:
        t = ("http://" if t.startswith(("localhost", "127.", "192.168.", "10.")) else "https://") + t
    p = urllib.parse.urlparse(t)
    if p.scheme not in ("http", "https") or not p.netloc:
        raise OnlineError("That doesn't look like a server address.")
    return f"{p.scheme}://{p.netloc}"


def server_locked() -> bool:
    """True for players: the server is fixed and the sign-in screens show no way to change it."""
    return not os.environ.get("NEXORA_ALLOW_SERVER_CHANGE")


def server_url() -> str:
    if "NEXORA_SERVER" in os.environ:
        return normalize_url(os.environ["NEXORA_SERVER"])
    if server_locked():
        return DEFAULT_SERVER
    d = _read()
    return d["server"] if "server" in d else DEFAULT_SERVER


def set_server_url(text: str) -> str:
    if server_locked():
        raise OnlineError("This version of Nexora always uses the official Nexora server.")
    url = normalize_url(text)
    d = _read()
    d["server"] = url
    if not url:
        d.pop("token", None)
    _write(d)
    return url


def enabled() -> bool:
    return bool(server_url())


def ws_url(path: str) -> str:
    u = server_url()
    return ("wss://" if u.startswith("https://") else "ws://") + u.split("://", 1)[1] + path


class Session:
    """One signed-in account. The launcher keeps its token on disk (so you stay signed in); Studio keeps it in memory."""

    def __init__(self, persist: bool = False):
        self.persist = persist
        self.token = _read().get("token", "") if persist else ""
        self.username = _read().get("username", "") if persist else ""
        self.avatar = None

    # ---- plumbing
    def request(self, method: str, path: str, body=None, auth: bool = True):
        base = server_url()
        if not base:
            raise OnlineError("No Nexora server address is set.")
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(base + path, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "Nexora/0.4")
        if auth and self.token:
            req.add_header("Authorization", "Bearer " + self.token)
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read().decode("utf-8")).get("error")
            except (ValueError, OSError):
                msg = None
            if e.code == 401 and auth and self.token and not path.startswith("/api/login"):
                self.token = ""
                if self.persist:
                    d = _read()
                    d.pop("token", None)
                    _write(d)
            err = OnlineError(msg or f"The server said {e.code}.")
            err.status = e.code
            raise err from None
        except (urllib.error.URLError, OSError, ValueError) as e:
            reason = getattr(e, "reason", e)
            raise OnlineError(f"Couldn't reach the Nexora server ({reason}). It may be waking up: try again in a "
                              "minute.") from None

    def _signed(self, res: dict) -> dict:
        self.token, self.username, self.avatar = res["token"], res["user"]["username"], res["user"]["avatar"]
        if self.persist:
            d = _read()
            d.update(token=self.token, username=self.username)
            _write(d)
        return res["user"]

    # ---- accounts
    def register(self, username, password):
        body = {"username": username, "password": password}
        code = os.environ.get("NEXORA_STAFF_CODE")  # only staff have this; the server checks it
        if code:
            body["staff_code"] = code
        return self._signed(self.request("POST", "/api/register", body, False))

    def login(self, username, password):
        return self._signed(self.request("POST", "/api/login", {"username": username, "password": password}, False))

    def resume(self):
        """Stay signed in from last time. Returns the user dict, or None."""
        if not self.token:
            return None
        try:
            u = self.request("GET", "/api/me")["user"]
        except OnlineError:
            return None
        self.username, self.avatar = u["username"], u["avatar"]
        return u

    def logout(self):
        try:
            if self.token:
                self.request("POST", "/api/logout", {})
        except OnlineError:
            pass
        self.token = ""
        if self.persist:
            d = _read()
            d.pop("token", None)
            d.pop("username", None)
            _write(d)

    def set_avatar(self, avatar: dict) -> dict:
        """Ask to wear this. Returns the avatar the server decided on (it only allows what you own)."""
        return self.request("PUT", "/api/avatar", {"avatar": avatar})["avatar"]

    def account_exists(self, name: str):
        return self.request("GET", "/api/users/" + urllib.parse.quote(name, safe=""))["username"]

    # ---- games
    def games(self, q: str = "") -> list:
        return self.request("GET", "/api/games" + (("?q=" + urllib.parse.quote(q)) if q else ""))["games"]

    def game(self, gid: str) -> dict:
        return self.request("GET", "/api/games/" + urllib.parse.quote(gid, safe=""))["game"]

    def download(self, gid: str) -> dict:
        return self.request("GET", f"/api/games/{urllib.parse.quote(gid, safe='')}/data")

    def publish(self, project_dict: dict) -> dict:
        return self.request("PUT", f"/api/games/{urllib.parse.quote(project_dict['id'], safe='')}", project_dict)["game"]

    def unpublish(self, gid: str):
        return self.request("DELETE", "/api/games/" + urllib.parse.quote(gid, safe=""))

    def like(self, gid: str) -> dict:
        return self.request("POST", f"/api/games/{urllib.parse.quote(gid, safe='')}/like", {})

    def servers(self, gid: str) -> list:
        return self.request("GET", f"/api/games/{urllib.parse.quote(gid, safe='')}/servers")["servers"]

    def join(self, gid: str, room=None) -> dict:
        return self.request("POST", f"/api/games/{urllib.parse.quote(gid, safe='')}/join",
                            {"room": room} if room else {})

    # ---- Nexei: wallet, shop, gamepasses
    def wallet(self) -> dict:
        return self.request("GET", "/api/wallet")["wallet"]

    def users_exist(self, names: list) -> list:
        return list(self.request("POST", "/api/users/exist", {"names": names[:60]}).get("exist") or [])

    def notice(self) -> str:
        return str(self.request("GET", "/api/notice", auth=False).get("text") or "")

    def delete_account(self, password: str) -> None:
        self.request("POST", "/api/delete-account", {"password": password})

    def daily(self) -> dict:
        return self.request("POST", "/api/daily", {})["wallet"]

    def shop(self) -> list:
        return self.request("GET", "/api/shop")["items"]

    def add_clothing(self, kind, name, price, color) -> str:
        return self.request("POST", "/api/shop", {"kind": kind, "name": name, "price": price, "color": color})["id"]

    def make_item(self, **fields) -> dict:
        """Send a new shirt / pants / accessory (kind, name, price, color, tex, slot, boxes). Returns {"id", "status"}."""
        return self.request("POST", "/api/shop", fields)

    def review_list(self) -> list:
        return self.request("GET", "/api/shop/review")["items"]

    def review(self, item_id: str, approve: bool) -> str:
        return self.request("POST", f"/api/items/{urllib.parse.quote(item_id, safe='')}/review",
                            {"approve": bool(approve)})["status"]

    def buy(self, item_id: str) -> dict:
        return self.request("POST", f"/api/items/{urllib.parse.quote(item_id, safe='')}/buy", {})

    def remove_item(self, item_id: str):
        return self.request("DELETE", f"/api/items/{urllib.parse.quote(item_id, safe='')}")

    def passes(self, gid: str) -> dict:
        return self.request("GET", f"/api/games/{urllib.parse.quote(gid, safe='')}/passes")

    def add_pass(self, gid: str, name: str, desc: str, price: int) -> str:
        return self.request("POST", f"/api/games/{urllib.parse.quote(gid, safe='')}/passes",
                            {"name": name, "desc": desc, "price": price})["id"]

    def my_passes(self, gid: str) -> list:
        return self.request("GET", f"/api/games/{urllib.parse.quote(gid, safe='')}/mypasses")["passes"]


def nexei_text(w: dict) -> str:
    """'1,250 Nexei' / '1 Nexei' / '∞ Nexei' for a wallet dict."""
    if w.get("infinite"):
        return "∞ Nexei"
    n = int(w.get("balance") or 0)
    return f"{n:,} Nexei" if n != 1 else "1 Nexei"


def cache_dir():
    d = accounts.data_dir() / "cache"
    d.mkdir(parents=True, exist_ok=True)
    return d
