"""Launcher pieces that need the Nexora online server: sign-in, the game page (likes, plays, live servers) and Play."""
import json
import threading
import tkinter as tk
from tkinter import simpledialog

import accounts
import badges
import games as game_db
import online
import theme as th

EMOJI = "Segoe UI Emoji"


class OnlineMixin:
    net = None
    catalog = {}        # game id -> summary from the server (plays, likes, playing...)
    detail = None       # the game whose page is open

    # ------------------------------------------------------------ background work
    def bg(self, fn, done):
        """Run fn() in a thread; call done(result, error_text) on the main thread when it finishes."""
        box = {}

        def work():
            try:
                box["r"] = fn()
            except online.OnlineError as e:
                box["e"] = str(e)
            except Exception as e:  # noqa: BLE001 - shown to the person instead of killing the app
                box["e"] = f"Something went wrong: {e}"
        t = threading.Thread(target=work, daemon=True)
        t.start()

        def poll():
            if t.is_alive():
                self.after(80, poll)
                return
            try:
                done(box.get("r"), box.get("e"))
            except tk.TclError:
                pass  # the window was closed or changed while we waited
        self.after(80, poll)

    def online_ready(self) -> bool:
        return online.enabled() and bool(self.net and self.net.token)

    # ------------------------------------------------------------ sign in
    def change_server(self):
        cur = online.server_url()
        text = simpledialog.askstring(
            "Nexora server", "Address of the Nexora server (for example https://nexora-xxxx.onrender.com).\n"
                             "Leave empty to use local accounts on this PC only.", initialvalue=cur, parent=self)
        if text is None:
            return
        try:
            online.set_server_url(text)
        except online.OnlineError as e:
            self.err.configure(text=str(e), fg=th.DANGER)
            return
        self.net = online.Session(persist=True)
        self.show_auth()

    def auth_server_row(self, card):
        row = tk.Frame(card, bg=th.PANEL)
        row.pack(fill="x", pady=(10, 0))
        url = online.server_url()
        tk.Label(row, text=("Online: " + url.split("://", 1)[1]) if url else "Local accounts on this PC",
                 bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).pack(side="left")
        if not online.server_locked():
            tk.Button(row, text="Server…", command=self.change_server, bg=th.PANEL, fg=th.CYAN, relief="flat", bd=0,
                      activebackground=th.PANEL, activeforeground=th.TEXT, cursor="hand2",
                      font=(th.FONT, 9)).pack(side="right")

    def do_auth_online(self, u, p):
        self.err.configure(text="Contacting the server… (the first request can take a minute)", fg=th.DIM)
        self.submit.configure(state="disabled")
        fn = lambda: (self.net.register if self.mode == "register" else self.net.login)(u.strip(), p)  # noqa: E731

        def done(user, err):
            self.submit.configure(state="normal")
            if err:
                self.err.configure(text=err, fg=th.DANGER)
                return
            self.show_home(accounts.ensure_local(user["username"], user["avatar"])["user"])
        self.bg(fn, done)

    def resume_online(self):
        """Stay signed in: check the saved token in the background."""
        self.show_auth()
        self.err.configure(text="Signing you in…", fg=th.DIM)

        def done(user, err):
            if user:
                self.show_home(accounts.ensure_local(user["username"], user["avatar"])["user"])
            else:
                self.err.configure(text=err or "", fg=th.DIM)
        self.bg(self.net.resume, done)

    # ------------------------------------------------------------ catalog
    def refresh_catalog(self, then=None):
        if not self.online_ready():
            return

        def done(games, err):
            if games is not None:
                self.catalog = {g["id"]: g for g in games}
                if then:
                    then()
        self.bg(self.net.games, done)

    def all_games_online(self) -> list:
        """Built-in games, games on the server, and games published on this PC (the server's copy wins)."""
        out = {g["id"]: dict(g) for g in game_db.all_games()}
        for gid, s in self.catalog.items():
            if gid in out:
                continue
            out[gid] = {"id": gid, "name": s["name"], "desc": s["desc"], "emoji": s["emoji"], "thumb": s["thumb"],
                        "owner": s["owner"], "devs": s["devs"], "online_only": True}
        return list(out.values())

    # ------------------------------------------------------------ the game page
    def show_game(self, g):
        self.detail = g
        self.show_page("game")

    def page_game(self):
        g = self.detail
        self.search_var.set("")
        self._shots = []
        tk.Button(self.body, text="←  Back to games", command=lambda: self.show_page("games"), bg=th.BG, fg=th.CYAN,
                  relief="flat", bd=0, activebackground=th.BG, activeforeground=th.TEXT, cursor="hand2",
                  font=(th.FONT, 10, "bold")).pack(anchor="w", pady=(0, 10))
        wrap = tk.Frame(self.body, bg=th.BG)
        wrap.pack(fill="both", expand=True)
        self.d_left = tk.Frame(wrap, bg=th.BG)
        self.d_left.pack(side="left", anchor="n")
        right = tk.Frame(wrap, bg=th.BG)
        right.pack(side="left", fill="both", expand=True, padx=(28, 0), anchor="n")
        self.d_title = tk.Label(right, text=g["name"], bg=th.BG, fg=th.TEXT, font=(th.FONT, 24, "bold"), anchor="w")
        self.d_title.pack(fill="x")
        self.d_by = tk.Frame(right, bg=th.BG)
        self.d_by.pack(fill="x", pady=(2, 8))
        self.d_desc = tk.Label(right, text=g["desc"] or "No description yet.", bg=th.BG, fg=th.DIM, font=(th.FONT, 11),
                               anchor="w", justify="left", wraplength=430)
        self.d_desc.pack(fill="x")
        self.d_stats = tk.Label(right, text="", bg=th.BG, fg=th.TEXT, font=(th.FONT, 12, "bold"), anchor="w")
        self.d_stats.pack(fill="x", pady=14)
        btns = tk.Frame(right, bg=th.BG)
        btns.pack(fill="x")
        self.d_play = self.button(btns, "▶  Play", lambda: self.play_game(g), primary=True)
        self.d_play.pack(side="left", ipadx=26, ipady=4)
        self.d_like = self.button(btns, "👍  Like", self.toggle_like)
        self.d_like.pack(side="left", padx=10, ipady=4)
        self.d_fav = self.button(btns, "\u2605  Favorited" if self.is_fav(g["id"]) else "\u2606  Favorite", self.fav_detail)
        self.d_fav.pack(side="left", ipady=4)
        self.d_msg = tk.Label(right, text="", bg=th.BG, fg=th.CYAN, font=(th.FONT, 10), anchor="w")
        self.d_msg.pack(fill="x", pady=(8, 0))
        tk.Label(right, text="SERVERS", bg=th.BG, fg=th.DIM, font=(th.FONT, 9, "bold"), anchor="w").pack(fill="x",
                                                                                                         pady=(16, 4))
        self.d_servers = tk.Frame(right, bg=th.BG)
        self.d_servers.pack(fill="x")
        self.build_passes_box(right)
        self.render_detail({})
        if self.online_ready():
            self.load_detail()
        else:
            self.d_like.configure(state="disabled")
            self.d_msg.configure(text="Likes, play counts and live servers need a Nexora server. Press Play to "
                                      "play on your own.")

    def load_detail(self):
        gid = self.detail["id"]

        def done(full, err):
            if not self.page == "game" or self.detail["id"] != gid:
                return
            if err:
                self.d_msg.configure(text=err, fg=th.DANGER)
            else:
                self.render_detail(full)
            if self.page == "game" and self.detail["id"] == gid:
                self.after(6000, lambda: self.page == "game" and self.detail["id"] == gid and self.load_detail())
        self.bg(lambda: self.net.game(gid), done)

    def render_detail(self, full):
        g = self.detail
        for w in self.d_left.winfo_children():
            w.destroy()
        shots = []
        for b64 in (full.get("thumbs") or [])[:3]:
            try:
                shots.append(tk.PhotoImage(data=b64))
            except tk.TclError:
                pass
        self._shots = shots
        if shots:
            big = tk.Label(self.d_left, image=shots[0], bg=th.PANEL, bd=0)
            big.pack()
            if len(shots) > 1:
                strip = tk.Frame(self.d_left, bg=th.BG)
                strip.pack(anchor="w", pady=6)
                for im in shots:
                    t = tk.Label(strip, image=im, bg=th.PANEL, cursor="hand2", bd=0)
                    t.pack(side="left", padx=(0, 8))
                    t.bind("<Button-1>", lambda e, im=im: big.configure(image=im))
        else:
            tk.Label(self.d_left, text=g["emoji"], bg=g["thumb"], fg="white", font=(EMOJI, 72), width=6,
                     height=2).pack()
        owner = full.get("owner") or g.get("owner") or ""
        devs = full.get("devs") if full else g.get("devs", [])
        parts = (["by 🛠 ", ("name", owner)] if owner and owner != "Nexora" else (["by Nexora"] if owner else []))
        for i, d in enumerate(devs or []):
            parts += (["   ·   with 🛠 "] if i == 0 else [", 🛠 "]) + [("name", d)]
        badges.fill_row(self.d_by, parts, th.BG, th.CYAN, (th.FONT, 11))
        if full:
            self.d_title.configure(text=full["name"])
            self.d_desc.configure(text=full["desc"] or "No description yet.")
            self.d_stats.configure(text=f"👁 {full['plays']:,} plays      👍 {full['likes']:,} likes      "
                                        f"🟢 {full['playing']} playing now")
            self.d_like.configure(text="👍  Liked" if full["liked"] else "👍  Like")
            self.d_msg.configure(text="", fg=th.CYAN)
            if full.get("has_scripts") and not self.scripts_allowed(full):
                self.d_msg.configure(text="This game has scripts. They're off by default for other people's games "
                                          "(Settings → Gameplay).", fg=th.DIM)
        for w in self.d_servers.winfo_children():
            w.destroy()
        servers = full.get("servers", []) if full else []
        if not self.online_ready():
            return
        if not servers:
            tk.Label(self.d_servers, text="No servers yet. Press Play and one starts for you; the next person who "
                                          "presses Play joins you.", bg=th.BG, fg=th.DIM, font=(th.FONT, 10),
                     anchor="w", justify="left", wraplength=430).pack(fill="x")
        for s in servers:
            row = tk.Frame(self.d_servers, bg=th.PANEL, padx=12, pady=8, highlightthickness=1,
                           highlightbackground=th.LINE)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=s["name"], bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11, "bold")).pack(side="left")
            tk.Label(row, text=f"{s['players']} / {s['max']} players", bg=th.PANEL, fg=th.DIM,
                     font=(th.FONT, 10)).pack(side="left", padx=14)
            full_ = s["players"] >= s["max"]
            b = self.button(row, "Full" if full_ else "Join", lambda s=s: self.play_game(self.detail, s["id"]))
            b.pack(side="right")
            if full_:
                b.configure(state="disabled")

    def fav_detail(self):
        on = self.toggle_fav(self.detail["id"])
        self.d_fav.configure(text="\u2605  Favorited" if on else "\u2606  Favorite")

    def toggle_like(self):
        gid = self.detail["id"]
        self.d_like.configure(state="disabled")

        def done(res, err):
            self.d_like.configure(state="normal")
            if err:
                self.d_msg.configure(text=err, fg=th.DANGER)
                return
            self.d_like.configure(text="👍  Liked" if res["liked"] else "👍  Like")
            self.load_detail_once()
        self.bg(lambda: self.net.like(gid), done)

    def load_detail_once(self):
        gid = self.detail["id"]
        self.bg(lambda: self.net.game(gid),
                lambda full, err: full and self.page == "game" and self.detail["id"] == gid and self.render_detail(full))

    # ------------------------------------------------------------ Play
    def scripts_allowed(self, full) -> bool:
        me = self.user["username"].lower()
        mine = me == (full.get("owner") or "").lower() or me in (d.lower() for d in full.get("devs", []))
        return mine or bool(accounts.get_settings(self.user["username"]).get("online_scripts"))

    def play_game(self, g, room=None):
        if self.proc and self.proc.poll() is None:
            self.set_status("A game is already running.")
            return
        if not self.online_ready():
            self.launch(g["id"], rpc_name=g.get("name"))  # no server: play it alone on this PC
            return
        if self.online_blocked():
            self.set_status("Parental controls: online play is turned off.")
            return
        self.set_status("Finding a server…")
        gid = g["id"]

        def work():
            j = self.net.join(gid, room)
            path, info = None, {}
            if not j["official"]:
                info = self.net.download(gid)
                path = online.cache_dir() / f"{gid}.json"
                path.write_text(json.dumps(info), encoding="utf-8")
            try:
                owned = self.net.my_passes(gid)
            except online.OnlineError:
                owned = []
            return j, path, info, owned

        def done(res, err):
            if err:
                self.set_status(err)
                return
            j, path, info, owned = res
            cmd = ["--room", j["room"], "--scripts", "1" if self.scripts_allowed(info or g) else "0"]
            if path:
                cmd += ["--project", str(path)]
            self.set_status(f"Joining {j['name']}…")
            self.launch(gid, extra=cmd, online_room=True, passes=owned, rpc_name=g["name"])
        self.bg(work, done)
