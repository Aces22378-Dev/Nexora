# Nexora (Python)

Desktop game platform, v0.2. Two separate apps:
- **Nexora** (`main.py`) - the player app: accounts, games, servers, friends.
- **Nexora Studio** (`studio.py`) - the creator app: build 3D games from parts + Python scripts, test, publish.

Plus an optional **online server** (`nexora_server.py`) for accounts, likes, play counts and live servers.

They share one data folder, so a game published in Studio shows up in Nexora's Games list (and can be hosted).

## Run
1. Install Python 3.10+ (https://python.org) - tick "Add python.exe to PATH"
2. `py -m pip install -r requirements.txt`
3. `py main.py`

To test with two accounts, open a second terminal in the same folder and run `py main.py` again.

## Build the .exe files
- `build_exe.bat` -> `dist\Nexora\Nexora.exe`
- `build_studio_exe.bat` -> `dist\NexoraStudio\NexoraStudio.exe`
- `build_exe_onefile.bat` / `build_studio_exe_onefile.bat` -> one single `.exe` each in `dist\` (slower to start, easy to share)
Keep each whole `dist` folder together.

## Nexora Studio
Run `py studio.py` (or `run_studio.bat`). New game -> add parts (Insert menu / toolbar), move them in the 3D view, edit numbers in Properties, add scripts, press **Play Test** (F5), then **Publish**.
- 3D view: left-drag select/move, right-drag orbit, Shift+right-drag pan, wheel zoom, WASD/QE fly, F focus, Delete.
- Tools: Select/Move/Scale/Rotate, snapping. Ctrl+Z/Y undo/redo, Ctrl+D duplicate, Ctrl+S save.
- Scripts are Python (not Luau). Help -> Scripting guide lists everything: `on_start()`, `on_update(dt)`, `on_touch(player)`, plus `game`, `part`, `player`.
- **Safety:** scripts are guarded (no files/network, endless loops are stopped) but this is not a true sandbox. Only play games from people you trust.
- Scripts run on each player's PC; they are not synced between players in online servers yet.

## Files
- `main.py` - launcher: login/sign up, games, people, avatar. Also the entry point for game windows and servers
- `servers_ui.py` - Servers page: browse, host, join by address
- `settings_ui.py` - Settings page (11 categories)
- `runner.py` - third-person 3D game runner, single player or online
- `network.py` - game server, LAN discovery and the client the games use
- `accounts.py` - local accounts, friends, blocking, settings, parental controls
- `studio.py`, `viewport3d.py`, `script_editor.py` - Nexora Studio (window, 3D editor view, code editor)
- `project.py`, `scripting.py` - game file format + validation; the Python scripting engine
- `nexora_server.py` - the online server (accounts, games, likes, plays, live rooms)
- `online.py`, `online_ui.py` - talking to that server; sign-in, game page and Play in the launcher
- `games.py` - built-in games and loading of published Studio games
- `theme.py`, `widgets.py` - colours/themes and shared UI pieces
- `meshio.py`, `pictureio.py`, `meshshade.py`, `avatar.py` - importing 3D models and pictures for the Workshop, and the avatar format
- `assets/` - logo and icon (optional: the app runs without them)


## Hosting the online server (free option: Render)
The server is `nexora_server.py` (needs `pip install aiohttp`). With no server address set, Nexora and Studio
work exactly as before (local accounts, LAN servers).
1. Put this folder on GitHub (the `Dockerfile` and `render.yaml` are included).
2. On https://render.com: New + > Blueprint > pick the repo > Deploy. You get an address like
   `https://nexora-server-xxxx.onrender.com`.
3. Put the address in `online.py` as `DEFAULT_SERVER` (the apps always use that one; players cannot change it). For testing, set `NEXORA_ALLOW_SERVER_CHANGE=1` to get the **Server…** button back, or `NEXORA_SERVER=<address>`. Then sign up.
4. To test on your own PC first: `py -m pip install aiohttp`, `py nexora_server.py`, server address `http://127.0.0.1:8080`.

**Free-plan limits (important):** Render's free server sleeps after ~15 minutes idle (the first request then takes
up to a minute) and **its disk is wiped on every restart/redeploy, so accounts, games and likes are lost**.
For lasting data use a paid plan with a disk (see `render.yaml`) or another host. There is no backup yet.

## Online play
- Click a game card to open its page: thumbnails, description, plays, likes, live servers, Like and Play.
- **Play** puts you in a server of that game that has room (default 12 players); if none exists it starts one.
  Join a specific server from the list on the game page.
- Player names in online servers come from the signed-in account, so the [DEV] badge can't be faked there.
- Creators publish from Nexora Studio (Publish uploads to the server). **Add thumbnail from 3D view** in Game settings.
- **Scripts from other creators are OFF by default** (Settings > Gameplay). Scripts are only guarded, not sandboxed;
  turn them on only for creators you trust. Your own games always run their scripts.
- Still local to each PC: friends, blocks, settings and parental controls. Changing username/password and deleting
  an online account aren't available yet. No moderation or word filter.

## Playing with others
- **Host a server** (Servers page): pick a game, name and max players. Nexora starts a server and joins it.
  Anyone on the same network sees it in the Servers list. The server keeps running until you press
  Stop or close Nexora.
- **Over the internet**: forward the server's port (shown in the banner, TCP and UDP) on your router and give
  friends `your-public-ip:port`; they use **Join by address**. Windows may ask to allow Nexora through the firewall.
- In games: WASD move, Space jump, scroll zoom, Tab player list, Enter chat, Esc (or the Menu button, top left; hold Alt to use the mouse) opens the menu: Resume, Players, Settings, Leave game.

## Known limits (v0.1)
- Accounts live on each PC. Friends, search and blocks only work between accounts on the same PC.
  In a server, names are not verified, so two PCs can use the same name on different servers.
- Servers relay positions only. There is no anti-cheat; players are not solid to each other.
- No chat, sound, payments, followers or moderation yet. Those settings pages say so instead of faking it.
- Games from other people's servers are not downloaded; everyone needs the game on their PC.
- Not yet built: online friends/blocks, moderation, account recovery, backups.
- Everything was tested on Linux only; the Windows .exe builds are untested.

## Nexei, the Shop and gamepasses (0.6)
- Needs the online server. Wallet = top bar. Free 100 Nexei per day in the Shop. No real money is involved.
- **Staff accounts** (default `Aces22378`, `Ivy`; change with env `NEXORA_STAFF="Name1,Name2"`) have unlimited Nexei.
  On the server set `NEXORA_STAFF_CODE` to a long secret (Render: Environment tab). Without it nobody can register those names.
  To create a staff account, set the same value as an environment variable `NEXORA_STAFF_CODE` on your PC, then sign up in Nexora with that username (PowerShell: `$env:NEXORA_STAFF_CODE="your-secret"; python main.py`).
- Staff add clothing in the Shop page. Creators add gamepasses in Studio > Game settings > Gamepasses.
- In scripts: `if player.has_pass("VIP"): player.speed = 20`. Scripts run on the player's PC, so this is trust-based.
- Not built: buying Nexei with real money, refunds, trading, selling clothing made by players.

## Keep the data on Cloudflare D1 (0.6.1)
The Python server stays on Render, but accounts, Nexei, purchases and games are also saved to a free Cloudflare D1 database, so a restart or redeploy no longer wipes them.
1. Cloudflare dashboard > Storage & databases > **D1** > Create database (name it `nexora`). Copy its **Database ID**.
2. Copy your **Account ID** (dashboard home, right side).
3. My Profile > API Tokens > Create Token > Custom: permission **Account > D1 > Edit**. Copy the token.
4. On Render > your service > Environment, add `CF_ACCOUNT_ID`, `CF_D1_DATABASE_ID`, `CF_API_TOKEN` (and `NEXORA_STAFF_CODE`). Redeploy.
5. The Render log should say `Cloudflare D1 backup is on.` After a restart it says `Restored N rows from Cloudflare D1.`
Tables are created for you. The server still reads from its own fast local file; D1 is the safe copy. If D1 is unreachable the server keeps working and retries. A change made in the last second or two before a crash can be lost.

## Running the server on Cloudflare instead (0.7.1)
The `worker/` folder is the whole server rewritten for Cloudflare Workers + D1 + Durable Objects. See `worker/README.md`. It speaks the same API, so nothing changes in Nexora/Studio except `DEFAULT_SERVER` in `online.py`. Read its "Limits" section first (CPU time and Durable Object allowances on the free plan).

## Accessories and clothes (0.8)
- **Shirts/pants** (0.9): paint a 32 x 32 picture with 16 colours (shirts also get a 16 x 32 picture for the sleeves), or *Import PNG / JPG...* (fitted to the part you are editing).
- **Accessories**: up to 8 boxes and/or one imported 3D model (OBJ, STL, PLY, GLB, glTF). Limits: 1,000 triangles and 700 points (bigger models are simplified), flat colours only, no textures or animation. A model travels with your avatar to everyone in the room, so it is kept small.
- If a model looks sideways or lying down, tick **Model is Z-up** or change **Turn**. Front is +z.

## Discord "Playing Nexora" (0.9.2)
1. Go to https://discord.com/developers/applications and make two applications, named exactly **Nexora** and **Nexora Studio** (the name is what Discord shows after "Playing"). Give each its logo as the app icon.
2. Copy each one's **Application ID** (General Information page).
3. Paste them into `NEXORA_ID` and `STUDIO_ID` at the top of `discordrpc.py`, then run or rebuild the apps. (Or set the environment variables `NEXORA_DISCORD_ID` / `STUDIO_DISCORD_ID`.)
4. Keep the Discord desktop app open. In Discord: Settings > Activity Privacy > turn on "Share your detected activities with others".

Richer presence (0.9.4): upload `nexora_logo` to the Nexora Discord application and `studio_logo` to the Nexora Studio one (Rich Presence > Art Assets, 1024 x 1024) for the big picture. Change `DOWNLOAD_URL` in `discordrpc.py` to your real download page for the "Get Nexora" button. Buttons show only to other people, never on your own profile.
