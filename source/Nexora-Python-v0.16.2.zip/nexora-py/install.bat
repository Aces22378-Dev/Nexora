@echo off
title Nexora Setup
echo Installing Nexora dependencies...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Install failed. Make sure Python 3.10+ is installed: https://python.org
  pause
  exit /b 1
)
echo.
echo Done. Starting Nexora...
python main.py
