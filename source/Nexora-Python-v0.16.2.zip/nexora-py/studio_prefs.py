"""Nexora Studio's own settings (how the editor behaves), kept in the Nexora data folder as studio.json.
These belong to the person using Studio, not to a game. (A game's own world settings live in the game file.)"""
import json

import accounts

DEFAULTS = {
    "snap": "1",            # "Off", "0.25", "0.5", "1", "2", "5"
    "show_grid": True,
    "grid_step": 4,         # one grid line every N units: 1, 2, 4, 8
    "orbit_speed": 100,     # percent
    "invert_orbit": False,
    "zoom_speed": 100,      # percent
    "fly_speed": 100,       # percent (WASD/QE)
    "fov": 60,              # degrees, 40..100
    "autosave": 0,          # minutes, 0 = off
}
LIMITS = {"grid_step": (1, 16), "orbit_speed": (30, 300), "zoom_speed": (30, 300), "fly_speed": (30, 300),
          "fov": (40, 100), "autosave": (0, 60)}
SNAPS = ("Off", "0.25", "0.5", "1", "2", "5")


def _file():
    return accounts.data_dir() / "studio.json"


def clean(d) -> dict:
    out = dict(DEFAULTS)
    d = d if isinstance(d, dict) else {}
    for k, dv in DEFAULTS.items():
        v = d.get(k, dv)
        if isinstance(dv, bool):
            out[k] = bool(v)
        elif k == "snap":
            out[k] = v if v in SNAPS else dv
        else:
            try:
                lo, hi = LIMITS[k]
                out[k] = int(max(lo, min(hi, float(v))))
            except (TypeError, ValueError):
                out[k] = dv
    return out


def load() -> dict:
    try:
        return clean(json.loads(_file().read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return dict(DEFAULTS)


def save(prefs: dict) -> None:
    try:
        _file().write_text(json.dumps(clean(prefs)), encoding="utf-8")
    except OSError:
        pass
