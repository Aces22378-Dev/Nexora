"""Verified / Staff badges shown next to names. The server says who has which (GET /api/badges); a person with both
shows only the highest one (staff). Everything here fails quietly: with no answer there are simply no badges."""
import json
import os
import sys
import tkinter as tk
import urllib.request

import online

_self = set()   # names we know are staff because the server said so about our own account
_map = {}      # lower-case name -> "staff" | "verified"
_imgs = {}     # (kind, size) -> PhotoImage (kept so Tk doesn't drop them)
SIZES = (16, 20, 28)
TITLE = {"staff": "Nexora staff", "verified": "Verified"}
_ORDER = {"verified": 1, "staff": 2}


def _asset(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def load(timeout: float = 4) -> bool:
    """Fetch the badge list. Returns True when it changed. Safe to call from a background thread."""
    global _map
    base = online.server_url()
    if not base:
        return False
    try:
        req = urllib.request.Request(base + "/api/badges", headers={"User-Agent": "Nexora/0.10"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8")).get("badges", {})
    except Exception:
        return False
    new = {}
    for n, k in (data.items() if isinstance(data, dict) else []):
        if isinstance(n, str) and k in _ORDER:
            new[n.lower()] = k   # only the highest badge per name ever comes down; keep the higher if repeated
    changed = new != _map
    keep = {n: k for n, k in _map.items() if k == "staff" and n not in new and n in _self}
    _map = {**new, **keep}
    return changed


def note_self(user: dict) -> bool:
    """The server tells you whether *you* are staff (in your own account data), even when the badge list can't be
    fetched. Returns True when that added a badge."""
    n = ((user or {}).get("username") or "").lower()
    if n and (user or {}).get("staff") and _map.get(n) != "staff":
        _map[n] = "staff"
        _self.add(n)
        return True
    return False


def kind(name) -> str | None:
    return _map.get((name or "").lower())


def image(k: str, size: int = 16):
    """The badge picture as a Tk image, or None when there's no such badge/file."""
    if k not in _ORDER:
        return None
    size = min(SIZES, key=lambda s: abs(s - size))
    key = (k, size)
    if key not in _imgs:
        try:
            _imgs[key] = tk.PhotoImage(file=_asset(f"assets/badge_{k}_{size}.png"))
        except tk.TclError:
            return None
    return _imgs[key]


def name_row(parent, name, bg, fg, font, size=16, prefix="", suffix="", **pack):
    """prefix + name + badge (+ suffix) in one row. Packs itself with **pack when given."""
    row = tk.Frame(parent, bg=bg)
    fill_row(row, [prefix, ("name", name), suffix], bg, fg, font, size)
    if pack is not None and pack.pop("_pack", True):
        row.pack(**pack)
    return row


def fill_row(row, parts, bg, fg, font, size=16):
    """(Re)build a row. parts: text, or ("name", n) for a name followed by its badge."""
    for w in row.winfo_children():
        w.destroy()
    for p in parts:
        if isinstance(p, tuple):
            n = p[1]
            tk.Label(row, text=n, bg=bg, fg=fg, font=font).pack(side="left")
            k = kind(n)
            img = image(k, size) if k else None
            if img:
                lb = tk.Label(row, image=img, bg=bg)
                lb.image = img
                lb.pack(side="left", padx=(4, 0))
        elif p:
            tk.Label(row, text=p, bg=bg, fg=fg, font=font).pack(side="left")
