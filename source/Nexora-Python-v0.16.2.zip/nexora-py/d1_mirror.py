"""Keeps the Nexora server's data safe on Cloudflare D1 while the server itself keeps running on a free host.

How it works: the server still uses a fast local SQLite file. Every change that is committed is also sent, in order, to
a D1 database (in a background thread). When the server starts with an empty local file (a free host wipes the disk on
restart), everything is copied back from D1 first. So accounts, Nexei, purchases and games survive restarts.

Turn it on with three environment variables on the server (all three, otherwise it stays off):
    CF_ACCOUNT_ID   CF_D1_DATABASE_ID   CF_API_TOKEN   (a token with "D1 Edit" permission)
Uses Cloudflare's D1 HTTP API: POST /accounts/<id>/d1/database/<db>/query
"""
import json
import os
import queue
import threading
import time
import urllib.error
import urllib.request

API = "https://api.cloudflare.com/client/v4"
WRITE_WORDS = ("INSERT", "UPDATE", "DELETE", "REPLACE", "ALTER", "CREATE", "DROP")
TABLES = ("users", "tokens", "games", "likes", "items", "purchases")   # copied back, in this order
MAX_QUEUE = 20000


class D1Error(Exception):
    pass


class D1:
    """The tiny part of the D1 HTTP API we need."""

    def __init__(self, account, database, token, base=None):
        self.url = f"{(base or API)}/accounts/{account}/d1/database/{database}/query"
        self.token = token

    def _post(self, payload):
        req = urllib.request.Request(self.url, data=json.dumps(payload).encode(), method="POST")
        req.add_header("Authorization", "Bearer " + self.token)
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                res = json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            raise D1Error(f"D1 said {e.code}: {e.read().decode(errors='replace')[:300]}") from None
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise D1Error(f"couldn't reach D1: {e}") from None
        if not res.get("success", False):
            raise D1Error(f"D1 error: {res.get('errors')}")
        return res.get("result") or []

    def query(self, sql, params=()):
        """One statement. Returns its rows as a list of dicts."""
        out = self._post({"sql": sql, "params": list(params)})
        return (out[0].get("results") if out else None) or []

    def batch(self, statements):
        """Several statements in order, applied together. statements = [(sql, params), ...]"""
        self._post({"batch": [{"sql": s, "params": list(p)} for s, p in statements]})


class Mirror:
    """Wraps a sqlite3 connection. Reads and writes behave exactly the same; committed writes are also sent to D1."""

    def __init__(self, conn, d1):
        self._c, self._d1 = conn, d1
        self._pending = []
        self._q = queue.Queue()
        self.sent, self.failures = 0, 0
        self.idle = threading.Event()
        self.idle.set()
        threading.Thread(target=self._worker, daemon=True).start()

    # ---- the sqlite3 connection API the server uses
    def execute(self, sql, params=()):
        cur = self._c.execute(sql, params)
        head = sql.lstrip().split(None, 1)[0].upper() if sql.strip() else ""
        if head in WRITE_WORDS:
            self._pending.append((sql, tuple(params)))
        elif head == "ROLLBACK":
            self._pending.clear()
        return cur

    def executescript(self, script):
        return self._c.executescript(script)

    def commit(self):
        self._c.commit()
        if self._pending:
            if self._q.qsize() < MAX_QUEUE:
                self.idle.clear()
                self._q.put(list(self._pending))
            self._pending.clear()

    def rollback(self):
        self._c.rollback()
        self._pending.clear()

    def __getattr__(self, name):
        return getattr(self._c, name)

    # ---- sending
    def _worker(self):
        while True:
            group = self._q.get()
            delay = 1.0
            while True:
                try:
                    self._d1.batch(group)
                    self.sent += len(group)
                    break
                except D1Error as e:
                    self.failures += 1
                    print(f"[d1] {e} (retrying in {delay:.0f}s)", flush=True)
                    time.sleep(delay)
                    delay = min(delay * 2, 60)
            if self._q.empty():
                self.idle.set()

    def flush(self, timeout=30):
        """Wait until everything committed so far has reached D1 (used when the server shuts down, and in tests)."""
        return self.idle.wait(timeout)


def from_env():
    acc, db, tok = (os.environ.get(k, "") for k in ("CF_ACCOUNT_ID", "CF_D1_DATABASE_ID", "CF_API_TOKEN"))
    if not (acc and db and tok):
        return None
    return D1(acc, db, tok, os.environ.get("CF_API_BASE"))


def prepare(d1, schema_statements, upgrades):
    """Make sure the tables exist on D1 (safe to run every start)."""
    for s in schema_statements:
        d1.query(s)
    for s in upgrades:
        try:
            d1.query(s)
        except D1Error:
            pass  # column already there


def restore(conn, d1) -> int:
    """Copy everything from D1 into an empty local database. Returns the number of rows copied."""
    n = 0
    for t in TABLES:
        rows = d1.query(f"SELECT * FROM {t}")
        for r in rows:
            cols = list(r)
            conn.execute(f"INSERT OR REPLACE INTO {t} ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                         [r[c] for c in cols])
            n += 1
    conn.commit()
    return n
