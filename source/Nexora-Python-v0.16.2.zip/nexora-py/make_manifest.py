"""Release tool: record the official file hashes for the current version.

Run `python make_manifest.py` after bumping version.py and before zipping. It writes integrity_manifest.json
(used by nexora_server.py) and worker/src/manifest.json (used by the Cloudflare Worker). Older versions stay in the
file, so people on an earlier release are still checked correctly.
"""
import json
from pathlib import Path

from integrity import file_hashes
from version import VERSION

here = Path(__file__).resolve().parent
for target in (here / "integrity_manifest.json", here / "worker" / "src" / "manifest.json"):
    if target.parent.exists():
        old = json.loads(target.read_text()) if target.exists() else {}
        old[VERSION] = file_hashes(here)
        target.write_text(json.dumps(old, indent=1, sort_keys=True) + "\n")
        print("wrote", target.relative_to(here), "for", VERSION)
