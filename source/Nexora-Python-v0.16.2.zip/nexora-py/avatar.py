"""What an avatar is, and the one function that cleans it. Used by the launcher, the game, the LAN server and the online
server, so a bad or hand-made avatar can never carry anything but colours, an 8x8 picture and a few little boxes.

avatar = {
  "skin": "#rrggbb", "shirt": "#rrggbb", "pants": "#rrggbb",
  "shirt_tex": None | {"pal": ["#rrggbb", ...up to 16], "px": 1024 characters (a 32 x 32 picture, row by row) or 64 (an old
                8 x 8 one): "0".."9","a".."f" = palette colour, "." = the garment's base colour shows through},
  "pants_tex": the same,
  "sleeve_tex": None | the same kind of picture, 512 characters (16 wide x 32 tall) or 128 (8 x 16): the front of both arms,
  "shirt_item": None | "item id", "pants_item": None | "item id",    (which shop items these came from)
  "acc": [ {"id": "item id", "name": "Cool Hat", "slot": "head"|"face"|"back"|"neck"
                                                   | "nohead"|"noleftleg"|"norightleg" (body items: they hide that part, no boxes),
            "boxes": [ {"p": [x, y, z], "s": [w, h, d], "c": "#rrggbb"}, ... up to 8 ],      (may be empty if there is a mesh)
            "mesh": None | {"v": [[x, y, z], ...], "f": [[a, b, c], ...], "c": "#rrggbb",
                            "pal": [up to 8 colours], "fc": one digit per triangle = palette colour (both optional)}
          }, ... one per slot ]
}
Box numbers are in game units from the avatar's feet: x sideways, y up (head centre = 1.85), z forward (front = +z).
"""
import re

HEX_RE = re.compile(r"#[0-9a-fA-F]{6}")
DEFAULT = {"skin": "#f1c27d", "shirt": "#7c5cff", "pants": "#2b2b4a"}
BODIES = ("male", "female")                  # the look of the body: Body tab in the avatar editor
SIZE_RANGE = (0.85, 1.15)                    # height and width, 1.0 = normal
SLOTS = ("head", "face", "back", "neck")
HIDE_SLOTS = ("nohead", "noleftleg", "norightleg")   # "Headless" and "Legless" (one leg at a time): looks only
LEG_SLOTS = ("noleftleg", "norightleg")
ALL_SLOTS = SLOTS + HIDE_SLOTS
TEX = 32                # a shirt front or pants picture is 32 x 32 pixels (8 x 8 pictures from before still work)
TEX_SIZES = {64: (8, 8), 1024: (32, 32)}      # number of pixels -> (width, height)
SLEEVE_SIZES = {128: (8, 16), 512: (16, 32)}
MAX_PAL = 16
PAL_CHARS = "0123456789abcdef"
MAX_BOXES = 8
BOX_POS = {"x": (-0.9, 0.9), "y": (0.0, 2.8), "z": (-0.9, 0.9)}
BOX_SIZE = (0.05, 1.0)
NAME_MAX = 30
MAX_VERTS = 700         # an imported 3D model: at most this many points and 1000 triangles (it travels with the avatar
MAX_TRIS = 1000         # to everyone in the room, so it has to stay small)


def _hex(v, default=None):
    return v.lower() if isinstance(v, str) and HEX_RE.fullmatch(v) else default


def _num(v, lo, hi):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or v in (float("inf"), float("-inf")):
        return None
    return round(max(lo, min(hi, float(v))), 2)


def clean_tex(t, sizes=None):
    """A picture (body: 32x32 or 8x8, sleeves: 16x32 or 8x16) or None."""
    sizes = sizes or TEX_SIZES
    if not isinstance(t, dict):
        return None
    pal, px = t.get("pal"), t.get("px")
    if not isinstance(pal, list) or not isinstance(px, str) or len(px) not in sizes:
        return None
    pal = [_hex(c) for c in pal[:MAX_PAL]]
    if not pal or any(c is None for c in pal):
        return None
    if any(ch != "." and not (ch in PAL_CHARS and PAL_CHARS.index(ch) < len(pal)) for ch in px):
        return None
    if set(px) == {"."}:
        return None  # nothing drawn
    return {"pal": pal, "px": px}


def clean_sleeve(t):
    return clean_tex(t, SLEEVE_SIZES)


def hidden_slots(acc) -> set:
    """Which body parts the worn accessories take away: a set of "nohead", "noleftleg", "norightleg"."""
    return {a.get("slot") for a in acc or [] if isinstance(a, dict) and a.get("slot") in HIDE_SLOTS}


def clean_box(b):
    if not isinstance(b, dict):
        return None
    p, s, c = b.get("p"), b.get("s"), _hex(b.get("c"))
    if not (isinstance(p, list) and isinstance(s, list) and len(p) == 3 and len(s) == 3) or c is None:
        return None
    pos = [_num(v, *BOX_POS[k]) for v, k in zip(p, "xyz")]
    size = [_num(v, *BOX_SIZE) for v in s]
    if None in pos or None in size:
        return None
    return {"p": pos, "s": size, "c": c}


def clean_mesh(m):
    """An imported 3D model (points + triangles + colours) or None. Points are clamped into the same space as boxes."""
    if not isinstance(m, dict):
        return None
    v, f, c = m.get("v"), m.get("f"), _hex(m.get("c"), "#cccccc")
    if not isinstance(v, list) or not isinstance(f, list) or not (3 <= len(v) <= MAX_VERTS) or not (1 <= len(f) <= MAX_TRIS):
        return None
    verts = []
    for p in v:
        if not (isinstance(p, list) and len(p) == 3):
            return None
        q = [_num(x, *BOX_POS[k]) for x, k in zip(p, "xyz")]
        if None in q:
            return None
        verts.append([round(x, 3) for x in q])
    tris = []
    for t in f:
        if not (isinstance(t, list) and len(t) == 3):
            return None
        if any(isinstance(i, bool) or not isinstance(i, int) or not 0 <= i < len(verts) for i in t):
            return None
        if len(set(t)) == 3:
            tris.append([int(i) for i in t])
    if not tris:
        return None
    out = {"v": verts, "f": tris, "c": c}
    pal, fc = m.get("pal"), m.get("fc")
    if isinstance(pal, list) and isinstance(fc, str):
        pal = [_hex(x) for x in pal[:MAX_PAL]]
        if pal and None not in pal and len(fc) == len(f) and all(ch.isdigit() and int(ch) < len(pal) for ch in fc):
            # triangles that were dropped above (degenerate) must drop their colour too
            keep = [i for i, t in enumerate(f) if len(set(t)) == 3]
            out["pal"], out["fc"] = pal, "".join(fc[i] for i in keep)
    return out


def clean_acc(a):
    """One accessory or None."""
    if not isinstance(a, dict) or a.get("slot") not in ALL_SLOTS:
        return None
    if a["slot"] in HIDE_SLOTS:  # nothing to draw: wearing it just hides the part
        name = " ".join(str(a.get("name", "")).split())[:NAME_MAX]
        return {"id": str(a.get("id", ""))[:20], "name": name, "slot": a["slot"], "boxes": []}
    raw = a.get("boxes") if isinstance(a.get("boxes"), list) else []
    boxes = [clean_box(b) for b in raw[:MAX_BOXES]]
    boxes = [b for b in boxes if b]
    mesh = clean_mesh(a.get("mesh"))
    if not boxes and not mesh:
        return None
    name = " ".join(str(a.get("name", "")).split())[:NAME_MAX]
    out = {"id": str(a.get("id", ""))[:20], "name": name, "slot": a["slot"], "boxes": boxes}
    if mesh:
        out["mesh"] = mesh
    return out


def clean(av) -> dict:
    out = dict(DEFAULT)
    out.update(shirt_tex=None, pants_tex=None, sleeve_tex=None, shirt_item=None, pants_item=None, acc=[],
               height=1.0, width=1.0, body="male")
    if isinstance(av, dict):
        for k in ("height", "width"):
            n = _num(av.get(k), *SIZE_RANGE)
            out[k] = 1.0 if n is None else n
        out["body"] = av.get("body") if av.get("body") in BODIES else "male"
        for k in DEFAULT:
            out[k] = _hex(av.get(k), out[k])
        out["shirt_tex"] = clean_tex(av.get("shirt_tex"))
        out["pants_tex"] = clean_tex(av.get("pants_tex"))
        out["sleeve_tex"] = clean_sleeve(av.get("sleeve_tex"))
        for k in ("shirt_item", "pants_item"):
            v = av.get(k)
            out[k] = v[:20] if isinstance(v, str) and v else None
        seen = set()
        for a in (av.get("acc") if isinstance(av.get("acc"), list) else [])[:len(ALL_SLOTS)]:
            a = clean_acc(a)
            if a and a["slot"] not in seen:
                seen.add(a["slot"])
                out["acc"].append(a)
        legs = [a for a in out["acc"] if a["slot"] in LEG_SLOTS]
        if len(legs) > 1:  # only one leg can be taken off at a time: the one asked for last wins
            out["acc"].remove(legs[0])
    return out
