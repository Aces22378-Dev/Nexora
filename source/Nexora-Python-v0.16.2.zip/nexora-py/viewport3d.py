"""The 3D view inside Nexora Studio: drawn in software on a tkinter canvas (no GPU, no extra packages).

Same conventions as the game: x right, y up, z forward, rotation_y turns clockwise seen from above.
Controls: left-click select, drag to move on the ground, right-drag orbit, middle-drag (or Shift+right-drag) pan,
wheel zoom, F focus selection, W/A/S/D/Q/E fly, Delete remove.
"""
import math
import tkinter as tk

import shapes
import theme as th

NEAR = 0.15
LIGHT = (-0.35, 0.85, -0.4)
MAX_TILE = 2.0
MAX_TILES = 8          # most tiles along one side of a big face (a floor is cut into tiles so things on it sort right)
GRID_RANGE = 60
AXIS_COLORS = {"x": "#ef4444", "y": "#22c55e", "z": "#3b82f6"}


# ---------------------------------------------------------------- tiny vector helpers
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def mul(a, k): return (a[0] * k, a[1] * k, a[2] * k)
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def norm(a):
    n = math.sqrt(dot(a, a)) or 1.0
    return (a[0] / n, a[1] / n, a[2] / n)


def hex_rgb(c):
    return int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)


def shade(c, k):
    r, g, b = hex_rgb(c)
    return "#%02x%02x%02x" % (min(255, int(r * k)), min(255, int(g * k)), min(255, int(b * k)))


def blend(c1, c2, t):
    a, b = hex_rgb(c1), hex_rgb(c2)
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def rot_axes(rot_y):
    """World directions of a part's local x, y and z axes."""
    r = math.radians(rot_y)
    c, s = math.cos(r), math.sin(r)
    return (c, 0.0, -s), (0.0, 1.0, 0.0), (s, 0.0, c)


class Camera:
    def __init__(self):
        self.target = (0.0, 2.0, 0.0)
        self.yaw = 0.6
        self.pitch = 0.5
        self.dist = 26.0
        self.fov = 60.0

    def forward(self):
        cp = math.cos(self.pitch)
        return (math.sin(self.yaw) * cp, -math.sin(self.pitch), math.cos(self.yaw) * cp)

    def basis(self):
        f = self.forward()
        r = norm(cross((0, 1, 0), f))
        return f, r, cross(f, r)

    def position(self):
        return sub(self.target, mul(self.forward(), self.dist))


def clip_near(poly):
    """Cut a polygon (camera-space points, z = forward) to the part in front of the near plane."""
    out = []
    for i, a in enumerate(poly):
        b = poly[(i + 1) % len(poly)]
        ain, bin_ = a[2] >= NEAR, b[2] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[2]) / (b[2] - a[2])
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR))
    return out


# ---------------------------------------------------------------- meshes in unit space (box spans -0.5..0.5)
def _box_faces():
    faces = []
    for axis in range(3):
        for sign in (-1, 1):
            n = [0, 0, 0]
            n[axis] = sign
            u = [0, 0, 0]
            v = [0, 0, 0]
            u[(axis + 1) % 3] = 1
            v[(axis + 2) % 3] = 1
            faces.append((tuple(n), tuple(u), tuple(v)))
    return faces


BOX_FACES = _box_faces()


def _sphere_faces(seg=10, rings=6):
    pts = [[None] * (seg + 1) for _ in range(rings + 1)]
    for i in range(rings + 1):
        phi = math.pi * i / rings
        for j in range(seg + 1):
            th_ = 2 * math.pi * j / seg
            pts[i][j] = (0.5 * math.sin(phi) * math.cos(th_), 0.5 * math.cos(phi), 0.5 * math.sin(phi) * math.sin(th_))
    faces = []
    for i in range(rings):
        for j in range(seg):
            quad = [pts[i][j], pts[i][j + 1], pts[i + 1][j + 1], pts[i + 1][j]]
            cen = (sum(p[0] for p in quad) / 4, sum(p[1] for p in quad) / 4, sum(p[2] for p in quad) / 4)
            faces.append((norm(cen), quad))
    return faces


SPHERE_LODS = (_sphere_faces(10, 6), _sphere_faces(8, 4), _sphere_faces(6, 3))   # near ... far: fewer faces far away


class Viewport:
    def __init__(self, parent, project, on_select=None, on_change=None, on_commit=None, on_status=None,
                 on_delete=None):
        self.project = project
        self.on_select = on_select or (lambda pid: None)
        self.on_change = on_change or (lambda: None)
        self.on_commit = on_commit or (lambda: None)
        self.on_status = on_status or (lambda t: None)
        self.on_delete = on_delete or (lambda: None)
        self.cam = Camera()
        self.selected = None
        self.tool = "select"
        self.snap = 1.0
        self.prefs = {"show_grid": True, "grid_step": 4, "orbit_speed": 100, "invert_orbit": False, "zoom_speed": 100,
                      "fly_speed": 100}   # replaced by Studio's settings (apply_prefs)
        self.canvas = tk.Canvas(parent, bg=project.data["sky"], highlightthickness=0, takefocus=True)
        self._idle = False
        self._geo = {}   # part id -> (key, faces): world-space faces, reused while the camera moves
        self._drag = None
        self._last = (0, 0)
        self._moved = False
        c = self.canvas
        c.bind("<Configure>", lambda e: self.request_redraw())
        c.bind("<ButtonPress-1>", self._press)
        c.bind("<B1-Motion>", self._motion)
        c.bind("<ButtonRelease-1>", self._release)
        for b in (2, 3):
            c.bind(f"<ButtonPress-{b}>", self._cam_press)
            c.bind(f"<B{b}-Motion>", self._cam_motion)
        c.bind("<MouseWheel>", lambda e: self._zoom(1 if e.delta < 0 else -1))
        c.bind("<Button-4>", lambda e: self._zoom(-1))
        c.bind("<Button-5>", lambda e: self._zoom(1))
        c.bind("<Key>", self._key)
        c.bind("<Delete>", lambda e: self.on_delete())
        c.bind("<Enter>", lambda e: c.focus_set())

    # ---------------------------------------------------------------- projection
    def _size(self):
        return max(2, self.canvas.winfo_width()), max(2, self.canvas.winfo_height())

    def _setup(self):
        w, h = self._size()
        f, r, u = self.cam.basis()
        self._f, self._r, self._u = f, r, u
        self._cp = self.cam.position()
        self._scale = (h / 2) / math.tan(math.radians(self.cam.fov) / 2)
        self._cx, self._cy = w / 2, h / 2

    def to_cam(self, p):
        v = sub(p, self._cp)
        return (dot(v, self._r), dot(v, self._u), dot(v, self._f))

    def to_screen(self, cp):
        z = max(cp[2], NEAR)
        return self._cx + cp[0] * self._scale / z, self._cy - cp[1] * self._scale / z

    def world_to_screen(self, p):
        """Pixel position of a world point, or None if it is behind the camera."""
        self._setup()
        c = self.to_cam(p)
        return None if c[2] < NEAR else self.to_screen(c)

    def screen_ray(self, sx, sy):
        self._setup()
        d = add(self._f, add(mul(self._r, (sx - self._cx) / self._scale), mul(self._u, -(sy - self._cy) / self._scale)))
        return self._cp, norm(d)

    def ground_point(self, sx, sy, y=0.0):
        o, d = self.screen_ray(sx, sy)
        if abs(d[1]) < 1e-6:
            return None
        t = (y - o[1]) / d[1]
        if t <= 0 or t > 5000:
            return None
        return add(o, mul(d, t))

    # ---------------------------------------------------------------- drawing
    def request_redraw(self):
        if not self._idle:
            self._idle = True
            self.canvas.after_idle(self.redraw)

    def _lod(self, rec):
        """0 = most detailed. A sphere far away (or small on screen) doesn't need 60 faces."""
        if rec["shape"] != "sphere":
            return 0
        pos = rec["pos"]
        cp = self._cp
        d = math.sqrt((pos[0] - cp[0]) ** 2 + (pos[1] - cp[1]) ** 2 + (pos[2] - cp[2]) ** 2)
        ratio = d / max(0.3, max(rec["size"]))
        return 2 if ratio > 8 else 1 if ratio > 3.5 else 0

    def _static_faces(self, rec):
        """The faces of a part in world space, with their shade: [(normal, quad, centre, tiled, fill, outline)].
        Doesn't depend on the camera, so it is worked out once per part and reused while the camera moves."""
        key = (tuple(rec["pos"]), tuple(rec["size"]), rec["rot_y"], rec["shape"], rec["color"])
        lod = self._lod(rec)
        hit = self._geo.get(rec["id"])
        if hit and hit[0] == key and lod in hit[1]:
            return hit[1][lod]
        store = hit[1] if hit and hit[0] == key else {}
        size = rec["size"]
        pos = rec["pos"]
        ax, ay, az = rot_axes(rec["rot_y"])
        base = rec["color"]
        light = norm(LIGHT)

        def world(local):
            x, y, z = local[0] * size[0], local[1] * size[1], local[2] * size[2]
            return (pos[0] + ax[0] * x + az[0] * z, pos[1] + y, pos[2] + ax[2] * x + az[2] * z)

        def wnormal(n):
            return norm((ax[0] * n[0] + az[0] * n[2], n[1], ax[2] * n[0] + az[2] * n[2]))

        faces = []
        if rec["shape"] == "sphere":
            for n, quad in SPHERE_LODS[lod]:
                faces.append((wnormal(n), [world(p) for p in quad], False))
        elif rec["shape"] in ("cylinder", "cone", "wedge"):
            for n, poly in shapes.faces(rec["shape"]):
                faces.append((wnormal(n), [world(p) for p in poly], False))
        else:
            for n, u, v in BOX_FACES:
                ui = max(range(3), key=lambda i: u[i])
                vi = max(range(3), key=lambda i: v[i])
                nu = min(MAX_TILES, max(1, math.ceil(size[ui] / MAX_TILE)))
                nv = min(MAX_TILES, max(1, math.ceil(size[vi] / MAX_TILE)))
                cen = tuple(0.5 * n[i] for i in range(3))
                wn = wnormal(n)
                for i in range(nu):
                    for j in range(nv):
                        u0, u1 = -0.5 + i / nu, -0.5 + (i + 1) / nu
                        v0, v1 = -0.5 + j / nv, -0.5 + (j + 1) / nv
                        quad = []
                        for a_, b_ in ((u0, v0), (u1, v0), (u1, v1), (u0, v1)):
                            quad.append(tuple(cen[k] + u[k] * a_ + v[k] * b_ for k in range(3)))
                        faces.append((wn, [world(p) for p in quad], nu * nv > 1))
        out = []
        for n, quad, tiled in faces:
            m = len(quad)
            centre = (sum(p[0] for p in quad) / m, sum(p[1] for p in quad) / m, sum(p[2] for p in quad) / m)
            k = 0.5 + 0.5 * max(0.0, dot(n, light))
            fill = shade(base, k)
            out.append((n, quad, centre, tiled, fill, fill if tiled else shade(base, k * 0.7)))
        store[lod] = out
        self._geo[rec["id"]] = (key, store)
        return out

    def _part_faces(self, rec):
        """[(depth, screen_points, fill, outline, ghost)] for one part, seen from the current camera."""
        ghost = not rec.get("visible", True)
        cp = self._cp
        cpx, cpy, cpz = cp
        rx, ry, rz = self._r
        ux, uy, uz = self._u
        fx, fy, fz = self._f
        scale, cx, cy = self._scale, self._cx, self._cy
        out = []
        for n, quad, centre, tiled, fill, outline in self._static_faces(rec):
            if n[0] * (cpx - centre[0]) + n[1] * (cpy - centre[1]) + n[2] * (cpz - centre[2]) <= 0:
                continue  # facing away
            cam = []
            for p in quad:
                vx, vy, vz = p[0] - cpx, p[1] - cpy, p[2] - cpz
                cam.append((vx * rx + vy * ry + vz * rz, vx * ux + vy * uy + vz * uz, vx * fx + vy * fy + vz * fz))
            if any(c[2] < NEAR for c in cam):
                cam = clip_near(cam)
                if len(cam) < 3:
                    continue
            pts = []
            for x, y, z in cam:
                pts.append(cx + x * scale / z)
                pts.append(cy - y * scale / z)
            xs, ys = pts[0::2], pts[1::2]
            if max(xs) < 0 or min(xs) > self._cx * 2 or max(ys) < 0 or min(ys) > self._cy * 2:
                continue   # entirely off screen: nothing to draw
            # distance from the camera (not view depth); big tiled faces use their farthest corner, so things
            # standing on them are drawn after them
            if tiled:
                depth = max(math.dist(p, cp) for p in quad)
            else:
                depth = math.sqrt((centre[0] - cpx) ** 2 + (centre[1] - cpy) ** 2 + (centre[2] - cpz) ** 2)
            out.append((depth, pts, fill, outline, ghost))
        return out

    def _line(self, a, b, **kw):
        ca, cb = self.to_cam(a), self.to_cam(b)
        if ca[2] < NEAR and cb[2] < NEAR:
            return None
        if ca[2] < NEAR:
            t = (NEAR - ca[2]) / (cb[2] - ca[2])
            ca = tuple(ca[i] + (cb[i] - ca[i]) * t for i in range(3))
        elif cb[2] < NEAR:
            t = (NEAR - cb[2]) / (ca[2] - cb[2])
            cb = tuple(cb[i] + (ca[i] - cb[i]) * t for i in range(3))
        x0, y0 = self.to_screen(ca)
        x1, y1 = self.to_screen(cb)
        return self.canvas.create_line(x0, y0, x1, y1, **kw)

    def redraw(self):
        self._idle = False
        c = self.canvas
        if not c.winfo_exists():
            return
        c.delete("all")
        c.configure(bg=self.project.data["sky"])
        self._setup()
        sky = self.project.data["sky"]
        gcol = blend(sky, "#ffffff", 0.4)
        # ground grid + axes
        t = self.cam.target
        step = max(1, int(self.prefs.get("grid_step", 4)))
        gx, gz = int(t[0] // step) * step, int(t[2] // step) * step
        span = GRID_RANGE
        if self.prefs.get("show_grid", True):
            for i in range(-span, span + 1, step):
                self._line((gx + i, 0, gz - span), (gx + i, 0, gz + span), fill=gcol, tags="grid")
                self._line((gx - span, 0, gz + i), (gx + span, 0, gz + i), fill=gcol, tags="grid")
        self._line((-500, 0, 0), (500, 0, 0), fill=AXIS_COLORS["x"], tags="grid")
        self._line((0, 0, -500), (0, 0, 500), fill=AXIS_COLORS["z"], tags="grid")

        if len(self._geo) > len(self.project.parts) + 20:   # forget parts that were deleted
            live = {r["id"] for r in self.project.parts}
            self._geo = {k: v for k, v in self._geo.items() if k in live}
        faces = []
        for rec in self.project.parts:
            for f in self._part_faces(rec):
                faces.append((f, rec["id"]))
        faces.sort(key=lambda it: -it[0][0])
        call, cw = c.tk.call, c._w   # straight to Tk: skips tkinter's option handling, which is slow for thousands of items
        for (depth, pts, fill, outline, ghost), pid in faces:
            if ghost:
                call(cw, "create", "polygon", *pts, "-fill", fill, "-outline", outline, "-width", 1, "-stipple", "gray50",
                     "-tags", ("part", f"p_{pid}"))
            else:
                call(cw, "create", "polygon", *pts, "-fill", fill, "-outline", outline, "-width", 1,
                     "-tags", ("part", f"p_{pid}"))

        sel = self.project.part(self.selected) if self.selected else None
        if sel:
            self._draw_selection(sel)
            self._draw_gizmo(sel)
        w, h = self._size()
        c.create_text(10, h - 10, anchor="sw", fill="#1b1b2f", font=(th.FONT, 9),
                      text=f"{self.tool.capitalize()} tool   |   snap {self.snap:g}" if self.snap else
                      f"{self.tool.capitalize()} tool   |   snap off")

    def _draw_selection(self, rec):
        size, pos = rec["size"], rec["pos"]
        ax, ay, az = rot_axes(rec["rot_y"])
        corners = []
        for sx in (-0.5, 0.5):
            for sy in (-0.5, 0.5):
                for sz in (-0.5, 0.5):
                    x, y, z = sx * size[0], sy * size[1], sz * size[2]
                    corners.append((pos[0] + ax[0] * x + az[0] * z, pos[1] + y, pos[2] + ax[2] * x + az[2] * z))
        for a in range(8):
            for b in range(a + 1, 8):
                if bin(a ^ b).count("1") == 1:
                    self._line(corners[a], corners[b], fill="#ffd23f", width=2, tags="sel")
        top = self.world_to_screen((pos[0], pos[1] + size[1] / 2 + 0.2, pos[2]))
        if top:
            self.canvas.create_text(top[0], top[1] - 8, text=rec["name"], fill="#1b1b2f", font=(th.FONT, 10, "bold"),
                                    tags="sel")

    # ---- gizmos
    def _gizmo_len(self, centre):
        d = max(NEAR, self.to_cam(centre)[2])
        return d * 90 / self._scale  # about 90 pixels long on screen

    def _draw_gizmo(self, rec):
        c, tool = tuple(rec["pos"]), self.tool
        if tool == "select":
            return
        L = self._gizmo_len(c)
        axes = {"x": (1, 0, 0), "y": (0, 1, 0), "z": (0, 0, 1)}
        if tool == "move":
            for name, a in axes.items():
                tip = add(c, mul(a, L))
                self._line(c, tip, fill=AXIS_COLORS[name], width=3, tags=(f"g_move_{name}", "gizmo"))
                p = self.world_to_screen(tip)
                if p:
                    self.canvas.create_oval(p[0] - 8, p[1] - 8, p[0] + 8, p[1] + 8, fill=AXIS_COLORS[name],
                                            outline="white", tags=(f"g_move_{name}", "gizmo"))
        elif tool == "scale":
            lx, ly, lz = rot_axes(rec["rot_y"])
            for name, a, half in (("x", lx, rec["size"][0] / 2), ("y", ly, rec["size"][1] / 2),
                                  ("z", lz, rec["size"][2] / 2)):
                for sgn, tag in ((1, "p"), (-1, "n")):
                    tip = add(c, mul(a, sgn * (half + L * 0.35)))
                    self._line(add(c, mul(a, sgn * half)), tip, fill=AXIS_COLORS[name], width=2, tags="gizmo")
                    p = self.world_to_screen(tip)
                    if p:
                        self.canvas.create_rectangle(p[0] - 7, p[1] - 7, p[0] + 7, p[1] + 7, fill=AXIS_COLORS[name],
                                                     outline="white", tags=(f"g_scale_{name}{tag}", "gizmo"))
        elif tool == "rotate":
            R = max(rec["size"][0], rec["size"][2]) * 0.75 + L * 0.4
            prev = None
            for i in range(49):
                a = 2 * math.pi * i / 48
                pt = (c[0] + math.sin(a) * R, c[1], c[2] + math.cos(a) * R)
                if prev is not None:
                    self._line(prev, pt, fill=AXIS_COLORS["y"], width=4, tags=("g_rotate", "gizmo"))
                prev = pt

    # ---------------------------------------------------------------- picking
    def pick(self, x, y):
        """('gizmo', name) | ('part', id) | None for what is under a pixel."""
        items = self.canvas.find_overlapping(x - 2, y - 2, x + 2, y + 2)
        for it in reversed(items):  # last = on top
            tags = self.canvas.gettags(it)
            for t in tags:
                if t.startswith("g_"):
                    return ("gizmo", t)
        for it in reversed(items):
            for t in self.canvas.gettags(it):
                if t.startswith("p_"):
                    return ("part", t[2:])
        return None

    # ---------------------------------------------------------------- mouse
    def _press(self, e):
        self.canvas.focus_set()
        self._last = (e.x, e.y)
        self._moved = False
        hit = self.pick(e.x, e.y)
        self._drag = None
        sel = self.project.part(self.selected) if self.selected else None
        if hit and hit[0] == "gizmo" and sel:
            self._begin_gizmo(hit[1], sel, e)
        elif hit and hit[0] == "part":
            self.set_selected(hit[1], notify=True)
            rec = self.project.part(hit[1])
            if self.tool == "select":
                gp = self.ground_point(e.x, e.y, rec["pos"][1])
                if gp:
                    self._drag = {"kind": "body", "offset": (rec["pos"][0] - gp[0], rec["pos"][2] - gp[2]),
                                  "y": rec["pos"][1], "start": list(rec["pos"])}
        else:
            self.set_selected(None, notify=True)

    def _begin_gizmo(self, tag, rec, e):
        parts = tag.split("_")  # g, move, x  |  g, scale, xp  |  g, rotate
        kind = parts[1]
        d = {"kind": kind, "press": (e.x, e.y), "pos": list(rec["pos"]), "size": list(rec["size"]),
             "rot": rec["rot_y"]}
        if kind == "move":
            d["axis"] = {"x": (1, 0, 0), "y": (0, 1, 0), "z": (0, 0, 1)}[parts[2]]
            d["idx"] = "xyz".index(parts[2])
        elif kind == "scale":
            name, sgn = parts[2][0], 1 if parts[2][1] == "p" else -1
            idx = "xyz".index(name)
            d["idx"], d["sgn"] = idx, sgn
            d["axis"] = rot_axes(rec["rot_y"])[idx]
        elif kind == "rotate":
            s = self.world_to_screen(rec["pos"])
            d["centre"] = s or (e.x, e.y)
            d["a0"] = math.atan2(e.y - d["centre"][1], e.x - d["centre"][0])
        self._drag = d

    def _snapv(self, v):
        return round(v / self.snap) * self.snap if self.snap else v

    def _motion(self, e):
        d = self._drag
        if not d:
            return
        if abs(e.x - self._last[0]) + abs(e.y - self._last[1]) < 1 and not self._moved:
            return
        self._moved = True
        rec = self.project.part(self.selected)
        if not rec:
            return
        try:
            if d["kind"] == "body":
                gp = self.ground_point(e.x, e.y, d["y"])
                if gp:
                    nx, nz = gp[0] + d["offset"][0], gp[2] + d["offset"][1]
                    self.project.update_part(rec["id"], pos=[round(self._snapv(nx), 3), rec["pos"][1],
                                                               round(self._snapv(nz), 3)])
            elif d["kind"] == "move":
                c = tuple(d["pos"])
                p0 = self.world_to_screen(c)
                p1 = self.world_to_screen(add(c, d["axis"]))
                if not p0 or not p1:
                    return
                sv = (p1[0] - p0[0], p1[1] - p0[1])
                den = dot((sv[0], sv[1], 0), (sv[0], sv[1], 0))
                if den < 1e-6:
                    return
                t = ((e.x - d["press"][0]) * sv[0] + (e.y - d["press"][1]) * sv[1]) / den
                new = list(d["pos"])
                new[d["idx"]] = round(self._snapv(new[d["idx"]] + t), 3)
                self.project.update_part(rec["id"], pos=new)
            elif d["kind"] == "scale":
                c = tuple(d["pos"])
                a = mul(d["axis"], d["sgn"])
                tip = add(c, mul(a, d["size"][d["idx"]] / 2))
                p0, p1 = self.world_to_screen(tip), self.world_to_screen(add(tip, a))
                if not p0 or not p1:
                    return
                sv = (p1[0] - p0[0], p1[1] - p0[1])
                den = sv[0] ** 2 + sv[1] ** 2
                if den < 1e-6:
                    return
                t = ((e.x - d["press"][0]) * sv[0] + (e.y - d["press"][1]) * sv[1]) / den
                new_len = max(0.05, d["size"][d["idx"]] + t)
                if self.snap:
                    new_len = max(self.snap, self._snapv(new_len))
                grow = new_len - d["size"][d["idx"]]
                size = list(d["size"])
                size[d["idx"]] = round(new_len, 3)
                pos = [round(d["pos"][i] + a[i] * grow / 2, 3) for i in range(3)]
                self.project.update_part(rec["id"], size=size, pos=pos)
            elif d["kind"] == "rotate":
                a1 = math.atan2(e.y - d["centre"][1], e.x - d["centre"][0])
                delta = math.degrees(a1 - d["a0"])
                rot = d["rot"] + delta
                if self.snap:
                    rot = round(rot / 15) * 15
                self.project.update_part(rec["id"], rot_y=rot % 360)
        except ValueError:
            return
        self.on_change()
        self.request_redraw()

    def _release(self, e):
        if self._drag and self._moved:
            self.project.commit()
            self.on_commit()
        self._drag = None

    def _cam_press(self, e):
        self._last = (e.x, e.y)

    def _cam_motion(self, e):
        dx, dy = e.x - self._last[0], e.y - self._last[1]
        self._last = (e.x, e.y)
        if e.state & 0x0001 or getattr(e, "num", 0) == 2 or e.state & 0x0200:  # shift or middle button: pan
            f, r, u = self.cam.basis()
            k = self.cam.dist * 0.0015
            self.cam.target = add(self.cam.target, add(mul(r, -dx * k), mul(u, dy * k)))
        else:
            k = 0.008 * self.prefs.get("orbit_speed", 100) / 100
            sgn = -1 if self.prefs.get("invert_orbit") else 1
            self.cam.yaw += dx * k
            self.cam.pitch = max(-1.45, min(1.45, self.cam.pitch + sgn * dy * k))
        self.request_redraw()

    def _zoom(self, direction):
        f = 1 + 0.12 * self.prefs.get("zoom_speed", 100) / 100
        self.cam.dist = max(2.0, min(500.0, self.cam.dist * (f if direction > 0 else 1 / f)))
        self.request_redraw()

    def _key(self, e):
        k = e.keysym.lower()
        f, r, u = self.cam.basis()
        flat = norm((f[0], 0, f[2]))
        step = max(1.0, self.cam.dist * 0.08) * self.prefs.get("fly_speed", 100) / 100
        moves = {"w": flat, "s": mul(flat, -1), "a": mul(r, -1), "d": r, "e": (0, 1, 0), "q": (0, -1, 0)}
        if k in moves and not (e.state & 0x4):
            self.cam.target = add(self.cam.target, mul(moves[k], step))
            self.request_redraw()
        elif k == "f":
            self.focus_selection()

    # ---------------------------------------------------------------- public helpers
    def set_selected(self, pid, notify=False):
        if pid == self.selected:
            return
        self.selected = pid
        if notify:
            self.on_select(pid)
        self.request_redraw()

    def set_tool(self, tool):
        self.tool = tool
        self.request_redraw()

    def apply_prefs(self, prefs):
        self.prefs = dict(self.prefs, **prefs)
        self.cam.fov = float(prefs.get("fov", self.cam.fov))
        self.set_snap(0 if prefs.get("snap", "1") == "Off" else float(prefs.get("snap", "1")))

    def set_snap(self, v):
        self.snap = float(v)
        self.request_redraw()

    def focus_selection(self):
        rec = self.project.part(self.selected) if self.selected else None
        if rec:
            self.cam.target = tuple(rec["pos"])
            self.cam.dist = max(6.0, max(rec["size"]) * 2.5)
            self.request_redraw()

    def spawn_point(self):
        """Where a new part should appear: the ground under the middle of the view (or in front of the camera)."""
        w, h = self._size()
        gp = self.ground_point(w / 2, h / 2, 0.0)
        if gp and math.dist(gp, self.cam.target) < 200:
            return (round(self._snapv(gp[0]), 3), 2.0, round(self._snapv(gp[2]), 3))
        t = self.cam.target
        return (round(self._snapv(t[0]), 3), round(max(t[1], 2.0), 3), round(self._snapv(t[2]), 3))

    def snapshot(self, w=320, h=180):
        """A picture of the current view (without selection handles), drawn with Pillow so it doesn't depend on
        screen scaling. Used for game thumbnails."""
        from PIL import Image, ImageDraw
        prev, self.selected = self.selected, None
        try:
            self.redraw()
            W, H = self._size()
            k = 2 * max(w / W, h / H)
            ox, oy = (2 * w - W * k) / 2, (2 * h - H * k) / 2
            img = Image.new("RGB", (2 * w, 2 * h), self.project.data["sky"])
            d = ImageDraw.Draw(img)
            c = self.canvas
            for item in c.find_all():
                kind = c.type(item)
                if kind not in ("polygon", "line"):
                    continue
                co = c.coords(item)
                pts = [(co[i] * k + ox, co[i + 1] * k + oy) for i in range(0, len(co) - 1, 2)]
                fill = c.itemcget(item, "fill") or None
                if kind == "polygon" and len(pts) >= 3:
                    d.polygon(pts, fill=fill, outline=c.itemcget(item, "outline") or None)
                elif kind == "line" and len(pts) >= 2 and fill:
                    d.line(pts, fill=fill, width=2)
            return img.resize((w, h), Image.LANCZOS)
        finally:
            self.selected = prev
            self.redraw()
