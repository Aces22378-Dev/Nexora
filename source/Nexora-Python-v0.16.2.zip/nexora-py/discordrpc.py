"""Shows what you are doing in Nexora / Nexora Studio on your Discord profile, like "Playing Nexora" in Discord's own
activity card:  the app name and a timer, two lines of text, how many people are in your server, a big picture and
two buttons.

How it works: the Discord desktop app, if it is open, accepts a small message from a program saying "this person is
playing <application>". Nothing is sent anywhere except to the Discord app on the same computer. If Discord is not
open or pypresence is not installed this quietly does nothing. Set NEXORA_NO_DISCORD=1 to switch it off.

Pictures: in each Discord application (https://discord.com/developers/applications > Rich Presence > Art Assets)
upload a picture named as in LARGE_IMAGE (and one named in SMALL_IMAGE if you want a little badge). If there is
none with that name Discord just shows no picture. Buttons only show to OTHER people, and can only open web links.
"""
import os
import threading
import time

NEXORA_ID = "1564079070768005210"   # Application ID of the Discord application named "Nexora"
STUDIO_ID = "1566446917381001434"   # Application ID of the Discord application named "Nexora Studio"
LARGE_IMAGE = {"nexora": "nexora_logo", "studio": "studio_logo"}   # Art Asset name of each app's big picture
SMALL_IMAGE = ""                    # Art Asset name of a small badge picture ("" = none)
DOWNLOAD_URL = "https://github.com/Aces22378-Dev"          # the "Get Nexora" button (change to your download page)
DISCORD_URL = "https://discord.gg/zEzJUzzAPj"              # the "Join our Discord" button
RETRY = 30       # seconds between tries when Discord isn't open (and the longest gap between refreshes)
MIN_GAP = 15     # Discord allows one change every 15 seconds

NAMES = {"nexora": "Nexora", "studio": "Nexora Studio"}
_state = {"details": None, "state": None, "party": None}
_lock = threading.Lock()


def client_id(which: str) -> str:
    """The Application ID for "nexora" or "studio" (environment variables NEXORA_DISCORD_ID / STUDIO_DISCORD_ID win)."""
    env = os.environ.get("NEXORA_DISCORD_ID" if which == "nexora" else "STUDIO_DISCORD_ID", "").strip()
    return env or (NEXORA_ID if which == "nexora" else STUDIO_ID).strip()


def set(details=None, state=None, party=None):  # noqa: A001 - short name on purpose: discordrpc.set(...)
    """Change what is shown. details = first line, state = second line, party = (people now, most people) or None.
    Safe to call at any time, from any thread; it is sent within a few seconds."""
    with _lock:
        _state.update(details=details, state=state, party=tuple(party) if party else None)


def _clip(text, n=128):
    return text if text is None or len(text) <= n else text[:n - 1] + "…"


def fields(which: str, snap: dict, started: int) -> dict:
    """The arguments for pypresence's update(): only what has a value."""
    f = {"start": started, "large_text": NAMES[which]}
    if snap["details"]:
        f["details"] = _clip(snap["details"])
    if snap["state"]:
        f["state"] = _clip(snap["state"])
    if snap["party"] and snap["party"][0] >= 1 and snap["party"][1] >= snap["party"][0]:
        f["party_size"] = [int(snap["party"][0]), int(snap["party"][1])]
    if LARGE_IMAGE.get(which):
        f["large_image"] = LARGE_IMAGE[which]
    if SMALL_IMAGE:
        f["small_image"] = SMALL_IMAGE
        f["small_text"] = NAMES[which]
    buttons = [{"label": l, "url": u} for l, u in (("Get " + NAMES[which], DOWNLOAD_URL), ("Join our Discord", DISCORD_URL))
               if u.startswith("https://")]
    if buttons:
        f["buttons"] = buttons
    return f


def start(which: str):
    """Start showing it in the background. `which` is "nexora" or "studio". Returns the thread, or None if it's off."""
    cid = client_id(which)
    if os.environ.get("NEXORA_NO_DISCORD") or not cid.isdigit():
        return None
    t = threading.Thread(target=_run, args=(which, cid), name="discord-presence", daemon=True)
    t.start()
    return t


def _run(which: str, cid: str):
    started = int(time.time())
    while True:
        rpc = None
        try:
            from pypresence import Presence
            rpc = Presence(cid)
            rpc.connect()
            sent, last = None, 0.0
            while True:
                with _lock:
                    snap = dict(_state)
                now = time.time()
                if (snap != sent and now - last >= MIN_GAP) or now - last >= RETRY:
                    rpc.update(**fields(which, snap, started))   # fails if Discord was closed: we then reconnect
                    sent, last = snap, now
                time.sleep(1)
        except Exception:  # noqa: BLE001 - Discord not open, closed, or pypresence missing: try again later
            try:
                if rpc:
                    rpc.close()
            except Exception:  # noqa: BLE001
                pass
            time.sleep(RETRY)
