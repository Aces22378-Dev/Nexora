"""Nexora Studio project: parts + scripts, saved as JSON. Also loading/validating games for the runner."""
import copy
import json
import math
import os
import re
import secrets
import time
from pathlib import Path

import accounts

FORMAT = 1
MAX_PARTS = 2000
MAX_SCRIPTS = 100
MAX_NAME = 40
MAX_DEVS = 10
MAX_THUMBS = 3
MAX_THUMB_CHARS = 300_000
_B64 = re.compile(r"[A-Za-z0-9+/=]*")
_USER = re.compile(r"[A-Za-z0-9_]{3,20}")
MAX_FILE_BYTES = 8_000_000
KINDS = ("part", "coin", "spawn", "goal")
SHAPES = ("box", "sphere", "cylinder", "cone", "wedge")
_HEX = re.compile(r"#[0-9a-fA-F]{6}")
_ID = re.compile(r"[A-Za-z0-9_\-]{1,24}")
LIMIT = 100_000.0

KIND_DEFAULTS = {
    "part": dict(name="Part", shape="box", size=[4.0, 1.0, 4.0], color="#a3a3a3", collide=True),
    "coin": dict(name="Coin", shape="sphere", size=[1.0, 1.0, 0.25], color="#facc15", collide=False),
    "spawn": dict(name="Spawn", shape="box", size=[4.0, 0.4, 4.0], color="#22d3ee", collide=True),
    "goal": dict(name="Goal", shape="box", size=[3.0, 0.3, 3.0], color="#facc15", collide=True),
}
DEFAULT_SKY = "#7fb8ff"
# World settings of a game (Studio > Game settings). Ranges: (default, low, high)
WORLD = {"fog": (0.0, 0.0, 1.0), "gravity": (1.0, 0.1, 3.0), "walk_speed": (9.0, 2.0, 40.0), "jump_height": (2.2, 0.5, 8.0)}


# ---------------------------------------------------------------- folders
def projects_dir() -> Path:
    d = accounts.data_dir() / "projects"
    d.mkdir(parents=True, exist_ok=True)
    return d


def games_dir() -> Path:
    d = accounts.data_dir() / "games"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _write_json(path: Path, data: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    os.replace(tmp, path)


# ---------------------------------------------------------------- validation
def _num(v, what, lo=-LIMIT, hi=LIMIT):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ValueError(f"{what} must be a number")
    return float(min(hi, max(lo, v)))


def _vec(v, what, lo=-LIMIT, hi=LIMIT):
    if not isinstance(v, (list, tuple)) or len(v) != 3:
        raise ValueError(f"{what} must be three numbers")
    return [round(_num(c, what, lo, hi), 3) for c in v]


def _text(v, what, default="", limit=MAX_NAME):
    if v is None:
        return default
    if not isinstance(v, str):
        raise ValueError(f"{what} must be text")
    return v.strip()[:limit] or default


def clean_part(d) -> dict:
    if not isinstance(d, dict):
        raise ValueError("a part is malformed")
    kind = d.get("kind", "part")
    if kind not in KINDS:
        raise ValueError(f"unknown part kind {kind!r}")
    base = KIND_DEFAULTS[kind]
    pid = d.get("id")
    if not isinstance(pid, str) or not _ID.fullmatch(pid):
        raise ValueError("a part has a bad id")
    shape = d.get("shape", base["shape"])
    if shape not in SHAPES:
        raise ValueError(f"unknown shape {shape!r}")
    color = d.get("color", base["color"])
    if not isinstance(color, str) or not _HEX.fullmatch(color):
        raise ValueError("a part has a bad color")
    out = {
        "id": pid, "name": _text(d.get("name"), "name", base["name"]), "kind": kind, "shape": shape,
        "pos": _vec(d.get("pos", [0, 0, 0]), "position"),
        "size": _vec(d.get("size", base["size"]), "size", 0.05, 10000),
        "rot_y": round(_num(d.get("rot_y", 0.0), "rotation") % 360, 3),
        "color": color.lower(),
        "collide": bool(d.get("collide", base["collide"])),
        "visible": bool(d.get("visible", True)),
    }
    if kind == "coin":
        out["value"] = int(_num(d.get("value", 1), "coin value", 1, 1000))
    return out


def clean_world(d) -> dict:
    d = d if isinstance(d, dict) else {}
    out = {k: round(_num(d.get(k, dv), k, lo, hi), 3) for k, (dv, lo, hi) in WORLD.items()}
    fc = d.get("fog_color")
    out["fog_color"] = fc.lower() if isinstance(fc, str) and _HEX.fullmatch(fc) else None   # None = the sky colour
    return out


def clean_script(d) -> dict:
    if not isinstance(d, dict):
        raise ValueError("a script is malformed")
    sid = d.get("id")
    if not isinstance(sid, str) or not _ID.fullmatch(sid):
        raise ValueError("a script has a bad id")
    src = d.get("source", "")
    if not isinstance(src, str):
        raise ValueError("a script's code must be text")
    target = d.get("target")
    if target is not None and (not isinstance(target, str) or not _ID.fullmatch(target)):
        raise ValueError("a script has a bad target")
    return {"id": sid, "name": _text(d.get("name"), "name", "Script"), "target": target, "source": src[:60_000]}


def clean_project(d) -> dict:
    """Validate and normalise a project dict. Raises ValueError with a readable reason."""
    if not isinstance(d, dict):
        raise ValueError("This isn't a Nexora game file.")
    fmt = d.get("format", FORMAT)
    if not isinstance(fmt, int) or fmt > FORMAT:
        raise ValueError("This game was made with a newer version of Nexora Studio. Update Nexora to open it.")
    parts_in, scripts_in = d.get("parts", []), d.get("scripts", [])
    if not isinstance(parts_in, list) or not isinstance(scripts_in, list):
        raise ValueError("This game file is damaged.")
    if len(parts_in) > MAX_PARTS:
        raise ValueError(f"Too many parts (the limit is {MAX_PARTS}).")
    if len(scripts_in) > MAX_SCRIPTS:
        raise ValueError(f"Too many scripts (the limit is {MAX_SCRIPTS}).")
    parts, seen = [], set()
    for p in parts_in:
        c = clean_part(p)
        if c["id"] in seen:
            raise ValueError("Two parts share the same id.")
        seen.add(c["id"])
        parts.append(c)
    scripts, sseen = [], set()
    for s in scripts_in:
        c = clean_script(s)
        if c["id"] in sseen:
            raise ValueError("Two scripts share the same id.")
        sseen.add(c["id"])
        scripts.append(c)
    gid = d.get("id")
    if not isinstance(gid, str) or not _ID.fullmatch(gid):
        raise ValueError("This game has no valid id.")
    sky = d.get("sky", DEFAULT_SKY)
    thumb = d.get("thumb", "#4f46e5")
    if not isinstance(sky, str) or not _HEX.fullmatch(sky) or not isinstance(thumb, str) or not _HEX.fullmatch(thumb):
        raise ValueError("This game has a bad color.")
    emoji = d.get("emoji", "🧱")
    thumbs_in = d.get("thumbs", [])
    if not isinstance(thumbs_in, list) or len(thumbs_in) > MAX_THUMBS:
        raise ValueError(f"A game can have at most {MAX_THUMBS} thumbnails.")
    thumbs = []
    for t in thumbs_in:
        if not isinstance(t, str) or len(t) > MAX_THUMB_CHARS or not _B64.fullmatch(t):
            raise ValueError("A thumbnail is not a valid image.")
        thumbs.append(t)
    owner = _text(d.get("owner"), "owner", "", 20)
    devs_in = d.get("devs", [])
    if not isinstance(devs_in, list) or len(devs_in) > MAX_DEVS:
        raise ValueError(f"A game can have at most {MAX_DEVS} developers.")
    devs = []
    for n in devs_in:
        if not isinstance(n, str) or not _USER.fullmatch(n):
            raise ValueError("A developer name is invalid.")
        if n.lower() != owner.lower() and n.lower() not in (x.lower() for x in devs):
            devs.append(n)
    return {
        "format": FORMAT, "id": gid, "name": _text(d.get("name"), "name", "Untitled game"),
        "desc": _text(d.get("desc"), "description", "", 140), "owner": owner, "devs": devs, "thumbs": thumbs,
        "author": owner or _text(d.get("author"), "author", "", 20),
        "emoji": emoji[:4] if isinstance(emoji, str) and emoji else "🧱",
        "sky": sky.lower(), "thumb": thumb.lower(),
        "kill_y": round(_num(d.get("kill_y", -50.0), "kill height", -10000, 10000), 3),
        "world": clean_world(d.get("world")),
        "parts": parts, "scripts": scripts, "modified": int(_num(d.get("modified", 0), "time", 0, 4e12)),
    }


def is_dev(game: dict, username: str) -> bool:
    """True if `username` is the owner or a developer of this game (used for the dev badge and for editing)."""
    n = (username or "").lower()
    return bool(n) and (n == (game.get("owner") or "").lower() or n in (d.lower() for d in game.get("devs", [])))


def spawn_position(parts) -> tuple:
    """Where the player appears: just above the first spawn part (or above the origin)."""
    for p in parts:
        if p["kind"] == "spawn":
            x, y, z = p["pos"]
            return (x, y + p["size"][1] / 2 + 1.2, z)
    return (0.0, 3.0, 0.0)


def to_game(p: dict) -> dict:
    """What the runner and the launcher need, from a validated project."""
    return dict(p, user=True, spawn=spawn_position(p["parts"]))


def slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:16] or "game"
    return f"u-{s}-{secrets.token_hex(2)}"


# ---------------------------------------------------------------- the editable project
class Project:
    """A game being edited in Studio, with undo/redo."""

    def __init__(self, data: dict | None = None, path: Path | None = None):
        self.path = path
        self.data = clean_project(data) if data else self._blank()
        self.undo_stack, self.redo_stack = [self._snap()], []
        self.saved_snapshot = self._snap()

    # ---- creation
    @staticmethod
    def _blank() -> dict:
        d = {"format": FORMAT, "id": slug("game"), "name": "My first game", "desc": "", "author": "",
             "sky": DEFAULT_SKY, "kill_y": -50.0, "parts": [], "scripts": []}
        c = clean_project(d)
        c["parts"] = [
            clean_part({"id": "p1", "name": "Baseplate", "kind": "part", "pos": [0, -0.5, 0], "size": [60, 1, 60],
                        "color": "#4ade80"}),
            clean_part({"id": "p2", "name": "Spawn", "kind": "spawn", "pos": [0, 0.2, 0]}),
        ]
        return c

    @classmethod
    def new(cls, name="My first game", owner=""):
        p = cls()
        p.data["name"] = _text(name, "name", "My first game")
        p.data["owner"] = p.data["author"] = owner
        p.data["id"] = slug(p.data["name"])
        p.saved_snapshot = p._snap()
        return p

    # ---- history
    def _snap(self) -> str:
        d = dict(self.data)
        d.pop("modified", None)
        return json.dumps(d, sort_keys=True)

    @property
    def dirty(self) -> bool:
        return self._snap() != self.saved_snapshot

    def commit(self) -> None:
        """Call after a finished change so it can be undone."""
        snap = self._snap()
        if self.undo_stack and self.undo_stack[-1] == snap:
            return
        self.undo_stack.append(snap)
        del self.undo_stack[:-200]
        self.redo_stack.clear()

    def undo(self) -> bool:
        if len(self.undo_stack) < 2:
            return False
        self.redo_stack.append(self.undo_stack.pop())
        self.data = clean_project(json.loads(self.undo_stack[-1]))
        return True

    def redo(self) -> bool:
        if not self.redo_stack:
            return False
        snap = self.redo_stack.pop()
        self.undo_stack.append(snap)
        self.data = clean_project(json.loads(snap))
        return True

    # ---- parts
    @property
    def parts(self):
        return self.data["parts"]

    @property
    def scripts(self):
        return self.data["scripts"]

    def part(self, pid):
        return next((p for p in self.parts if p["id"] == pid), None)

    def script(self, sid):
        return next((s for s in self.scripts if s["id"] == sid), None)

    def _new_id(self, prefix, existing):
        n = len(existing) + 1
        used = {x["id"] for x in existing}
        while f"{prefix}{n}" in used:
            n += 1
        return f"{prefix}{n}"

    def add_part(self, kind="part", pos=(0, 2, 0), **over) -> dict:
        if len(self.parts) >= MAX_PARTS:
            raise ValueError(f"A game can have at most {MAX_PARTS} parts.")
        d = dict(KIND_DEFAULTS[kind], kind=kind, pos=list(pos), id=self._new_id("p", self.parts))
        d.update(over)
        rec = clean_part(d)
        self.parts.append(rec)
        return rec

    def duplicate_part(self, pid):
        src = self.part(pid)
        if not src:
            return None
        d = copy.deepcopy(src)
        d["id"] = self._new_id("p", self.parts)
        d["pos"] = [src["pos"][0] + 2, src["pos"][1], src["pos"][2] + 2]
        if len(self.parts) >= MAX_PARTS:
            raise ValueError(f"A game can have at most {MAX_PARTS} parts.")
        rec = clean_part(d)
        self.parts.append(rec)
        for s in [s for s in self.scripts if s["target"] == pid]:  # copies keep their scripts
            self.add_script(s["name"], rec["id"], s["source"])
        return rec

    def remove_part(self, pid) -> None:
        self.data["parts"] = [p for p in self.parts if p["id"] != pid]
        self.data["scripts"] = [s for s in self.scripts if s["target"] != pid]

    def update_part(self, pid, **fields) -> dict:
        p = self.part(pid)
        if not p:
            raise KeyError(pid)
        merged = dict(p, **fields)
        new = clean_part(merged)  # raises ValueError for bad input without touching the part
        p.clear()
        p.update(new)
        return p

    # ---- scripts
    def add_script(self, name="Script", target=None, source=None) -> dict:
        if len(self.scripts) >= MAX_SCRIPTS:
            raise ValueError(f"A game can have at most {MAX_SCRIPTS} scripts.")
        if target is not None and not self.part(target):
            raise ValueError("That part doesn't exist.")
        if source is None:
            source = TEMPLATE_PART if target else TEMPLATE_GAME
        rec = clean_script({"id": self._new_id("s", self.scripts), "name": name, "target": target, "source": source})
        self.scripts.append(rec)
        return rec

    def remove_script(self, sid) -> None:
        self.data["scripts"] = [s for s in self.scripts if s["id"] != sid]

    # ---- files
    def to_dict(self) -> dict:
        d = copy.deepcopy(self.data)
        d["modified"] = int(time.time())
        return clean_project(d)

    def save(self, path: Path | None = None) -> Path:
        path = Path(path or self.path or projects_dir() / f"{self.data['id']}.json")
        _write_json(path, self.to_dict())
        self.path = path
        self.saved_snapshot = self._snap()
        return path

    @classmethod
    def load(cls, path) -> "Project":
        path = Path(path)
        if path.stat().st_size > MAX_FILE_BYTES:
            raise ValueError("That file is too big to be a Nexora game.")
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ValueError("That file isn't a Nexora game (it isn't valid JSON).") from None
        p = cls(data, path)
        p.undo_stack = [p._snap()]
        return p

    def publish(self, user: str = "") -> Path:
        """Make the game appear in Nexora's Games list."""
        d = self.to_dict()
        if not d["owner"] or not is_dev(d, user):
            raise ValueError("Only the game's owner or a developer can publish it.")
        if not any(x["kind"] == "spawn" for x in d["parts"]):
            raise ValueError("Add a Spawn part first, so players know where to start.")
        out = games_dir() / f"{d['id']}.json"
        if out.exists():  # never overwrite a game that belongs to someone else
            try:
                old = clean_project(json.loads(out.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                old = None
            if old and old["owner"] and not is_dev(old, user):
                raise ValueError(f"A game with this id is already published by {old['owner']}.")
        _write_json(out, d)
        return out


TEMPLATE_GAME = '''# A game-wide script. It runs once when the game starts.
# Handy: game.say("text"), game.score, game.win(), game.find("PartName"), game.after(seconds, function)

def on_start():
    game.say("Welcome!", 3)

def on_update(dt):
    pass  # runs every frame; dt is the time since the last frame
'''

TEMPLATE_PART = '''# This script is attached to a part. "part" is that part.

def on_touch(who):
    # runs when the player touches this part
    part.color = rgb(255, 80, 80)
    game.say("Ouch!")
'''


# ---------------------------------------------------------------- listing / loading files for the launcher
def list_projects() -> list:
    out = []
    for f in sorted(projects_dir().glob("*.json")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            out.append({"id": d["id"], "name": str(d.get("name", f.stem))[:MAX_NAME], "path": f,
                        "modified": f.stat().st_mtime, "parts": len(d.get("parts", [])),
                        "owner": str(d.get("owner", ""))[:20],
                        "devs": [x for x in d.get("devs", []) if isinstance(x, str)][:MAX_DEVS]})
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return sorted(out, key=lambda x: -x["modified"])


def delete_project(path) -> None:
    Path(path).unlink(missing_ok=True)


def unpublish(game_id: str) -> None:
    if _ID.fullmatch(game_id or ""):
        (games_dir() / f"{game_id}.json").unlink(missing_ok=True)


def load_user_games():
    """(games, problems): every published game that validates, plus messages for the ones that don't."""
    games, problems = [], []
    for f in sorted(games_dir().glob("*.json")):
        try:
            if f.stat().st_size > MAX_FILE_BYTES:
                raise ValueError("file too big")
            games.append(to_game(clean_project(json.loads(f.read_text(encoding="utf-8")))))
        except (OSError, ValueError, UnicodeDecodeError) as e:
            problems.append(f"{f.name}: {e}")
    return games, problems
