"""Reading 3D models for accessories: OBJ, STL, PLY and GLB/glTF  ->  a small mesh Nexora can show (see avatar.py).

Only the shape (points and triangles) and, when the file has them, flat colours are used. Textures, animations, bones and
lights are ignored. Anything bigger than the limits is simplified automatically.

    base = load("hat.obj")                       # a Base: centred, longest side = 1, already small enough
    mesh = place(base, "head", size=0.7)         # a mesh dict for the avatar (ready for avatar.clean_mesh)
"""
import base64
import json
import math
import os
import struct

import avatar as av

MAX_FILE = 25 * 1024 * 1024
EXTS = (".obj", ".stl", ".ply", ".glb", ".gltf")
DEFAULT_COLOR = "#cccccc"
# where each slot sits on the avatar: (x, y, z, how to line it up in height)  head: model's bottom on the top of the head
ANCHOR = {"head": (0.0, 2.1, 0.0, "bottom"), "face": (0.0, 1.88, 0.3, "middle"),
          "back": (0.0, 1.3, -0.45, "middle"), "neck": (0.0, 1.6, 0.0, "middle")}
SIZE = {"head": 0.7, "face": 0.6, "back": 0.9, "neck": 0.7}


class MeshError(Exception):
    """A problem with the file, in words a player can read."""


# ------------------------------------------------------------ loaders: each returns (verts, tris, tri_colors)
def _hexc(r, g, b):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(x * 255)))) for x in (r, g, b))


def load_obj(path, data):
    verts, tris, cols, mats, cur = [], [], [], {}, None
    mtl = []
    for line in data.decode("utf-8", "replace").splitlines():
        t = line.split("#", 1)[0].split()
        if not t:
            continue
        if t[0] == "v" and len(t) >= 4:
            verts.append([float(x) for x in t[1:4]])
        elif t[0] == "f" and len(t) >= 4:
            idx = []
            for tok in t[1:]:
                i = int(tok.split("/")[0])
                idx.append(i - 1 if i > 0 else len(verts) + i)
            for k in range(1, len(idx) - 1):  # a polygon becomes a fan of triangles
                tris.append([idx[0], idx[k], idx[k + 1]])
                cols.append(cur)
        elif t[0] == "usemtl" and len(t) > 1:
            cur = t[1]
        elif t[0] == "mtllib" and len(t) > 1:
            mtl.append(" ".join(t[1:]))
    for name in mtl:  # colours from the .mtl next to the file, if it is there
        p = os.path.join(os.path.dirname(path), os.path.basename(name))
        try:
            if os.path.getsize(p) > 1_000_000:
                continue
            m = None
            for line in open(p, encoding="utf-8", errors="replace"):
                t = line.split("#", 1)[0].split()
                if len(t) >= 2 and t[0] == "newmtl":
                    m = " ".join(t[1:])
                elif len(t) >= 4 and t[0] == "Kd" and m:
                    mats[m] = _hexc(float(t[1]), float(t[2]), float(t[3]))
        except (OSError, ValueError):
            pass
    return verts, tris, [mats.get(c) for c in cols]


def load_stl(path, data):
    verts, tris = [], []
    if data[:5].lower() == b"solid" and b"facet" in data[:2000]:
        cur = []
        for line in data.decode("utf-8", "replace").splitlines():
            t = line.split()
            if len(t) == 4 and t[0] == "vertex":
                cur.append([float(x) for x in t[1:4]])
                if len(cur) == 3:
                    tris.append([len(verts), len(verts) + 1, len(verts) + 2])
                    verts.extend(cur)
                    cur = []
    else:
        if len(data) < 84:
            raise MeshError("That STL file is too short to be a model.")
        n = struct.unpack_from("<I", data, 80)[0]
        if len(data) < 84 + 50 * n:
            raise MeshError("That STL file is cut off.")
        for i in range(n):
            f = struct.unpack_from("<12f", data, 84 + 50 * i)
            tris.append([len(verts), len(verts) + 1, len(verts) + 2])
            verts.extend([list(f[3:6]), list(f[6:9]), list(f[9:12])])
    return verts, tris, [None] * len(tris)


_PLY = {"char": "b", "int8": "b", "uchar": "B", "uint8": "B", "short": "h", "int16": "h", "ushort": "H", "uint16": "H",
        "int": "i", "int32": "i", "uint": "I", "uint32": "I", "float": "f", "float32": "f", "double": "d", "float64": "d"}


def load_ply(path, data):
    end = data.find(b"end_header")
    if not data.startswith(b"ply") or end < 0:
        raise MeshError("That doesn't look like a PLY file.")
    head = data[:end].decode("ascii", "replace").splitlines()
    body = data[data.find(b"\n", end) + 1:]
    fmt, elems = "", []
    for line in head:
        t = line.split()
        if t[:1] == ["format"]:
            fmt = t[1]
        elif t[:1] == ["element"]:
            elems.append([t[1], int(t[2]), []])
        elif t[:1] == ["property"] and elems:
            elems[-1][2].append(t[1:])
    verts, tris, vcol = [], [], []
    if fmt == "ascii":
        words = body.decode("ascii", "replace").split()
        pos = 0
    elif fmt == "binary_little_endian":
        pos = 0
    else:
        raise MeshError("Only ascii and little-endian binary PLY files are supported.")

    def read(tp):
        nonlocal pos
        if fmt == "ascii":
            v = words[pos]
            pos += 1
            return float(v) if tp in ("f", "d") else int(float(v))
        sz = struct.calcsize("<" + tp)
        v = struct.unpack_from("<" + tp, body, pos)[0]
        pos += sz
        return v

    for name, count, props in elems:
        for _ in range(count):
            row = {}
            for p in props:
                if p[0] == "list":
                    n = read(_PLY[p[1]])
                    row[p[3]] = [read(_PLY[p[2]]) for _ in range(n)]
                else:
                    row[p[1]] = read(_PLY[p[0]])
            if name == "vertex":
                verts.append([row.get("x", 0.0), row.get("y", 0.0), row.get("z", 0.0)])
                vcol.append((row["red"], row["green"], row["blue"]) if "red" in row else None)
            elif name == "face":
                idx = row.get("vertex_indices") or row.get("vertex_index") or []
                for k in range(1, len(idx) - 1):
                    tris.append([idx[0], idx[k], idx[k + 1]])
    cols = []
    for t in tris:
        cs = [vcol[i] for i in t if 0 <= i < len(vcol) and vcol[i]]
        cols.append(_hexc(*(sum(c[j] for c in cs) / len(cs) / 255 for j in range(3))) if cs else None)
    return verts, tris, cols


_CT = {5120: "b", 5121: "B", 5122: "h", 5123: "H", 5125: "I", 5126: "f"}
_NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}


def load_gltf(path, data):
    chunks = {}
    if data[:4] == b"glTF":
        pos = 12
        while pos + 8 <= len(data):
            ln, kind = struct.unpack_from("<II", data, pos)
            chunks[kind] = data[pos + 8:pos + 8 + ln]
            pos += 8 + ln
        js = json.loads(chunks.get(0x4E4F534A, b"{}"))
    else:
        js = json.loads(data.decode("utf-8", "replace"))
    bufs = []
    for i, b in enumerate(js.get("buffers", [])):
        uri = b.get("uri")
        if uri is None:
            bufs.append(chunks.get(0x004E4942, b""))
        elif uri.startswith("data:"):
            bufs.append(base64.b64decode(uri.split(",", 1)[1]))
        else:
            p = os.path.join(os.path.dirname(path), os.path.basename(uri))
            try:
                bufs.append(open(p, "rb").read() if os.path.getsize(p) <= MAX_FILE else b"")
            except OSError:
                raise MeshError(f"The model needs the file '{os.path.basename(uri)}' next to it. Use a .glb (one file) instead.")

    def accessor(i):
        a = js["accessors"][i]
        bv = js["bufferViews"][a["bufferView"]]
        buf = bufs[bv["buffer"]]
        n, ncomp, tp = a["count"], _NC[a["type"]], _CT[a["componentType"]]
        size = struct.calcsize(tp)
        stride = bv.get("byteStride") or size * ncomp
        base = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
        out = []
        for k in range(n):
            out.append(struct.unpack_from("<" + tp * ncomp, buf, base + k * stride))
        return out

    def mat_mul(a, b):  # 4x4 column-major
        return [sum(a[k * 4 + r] * b[c * 4 + k] for k in range(4)) for c in range(4) for r in range(4)]

    def node_matrix(n):
        if "matrix" in n:
            return list(n["matrix"])
        tx, ty, tz = n.get("translation", [0, 0, 0])
        qx, qy, qz, qw = n.get("rotation", [0, 0, 0, 1])
        sx, sy, sz = n.get("scale", [1, 1, 1])
        r = [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy + qz * qw), 2 * (qx * qz - qy * qw),
             2 * (qx * qy - qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz + qx * qw),
             2 * (qx * qz + qy * qw), 2 * (qy * qz - qx * qw), 1 - 2 * (qx * qx + qy * qy)]
        return [r[0] * sx, r[1] * sx, r[2] * sx, 0, r[3] * sy, r[4] * sy, r[5] * sy, 0,
                r[6] * sz, r[7] * sz, r[8] * sz, 0, tx, ty, tz, 1]

    verts, tris, cols = [], [], []
    ident = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]

    def visit(ni, parent, depth=0):
        if depth > 32:
            return
        n = js["nodes"][ni]
        m = mat_mul(parent, node_matrix(n))
        if "mesh" in n:
            for prim in js["meshes"][n["mesh"]].get("primitives", []):
                if prim.get("mode", 4) != 4 or "POSITION" not in prim.get("attributes", {}):
                    continue
                pos = accessor(prim["attributes"]["POSITION"])
                off = len(verts)
                for x, y, z in pos:
                    verts.append([m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13],
                                  m[2] * x + m[6] * y + m[10] * z + m[14]])
                idx = [i[0] for i in accessor(prim["indices"])] if "indices" in prim else list(range(len(pos)))
                col = None
                mi = prim.get("material")
                if mi is not None:
                    f = js["materials"][mi].get("pbrMetallicRoughness", {}).get("baseColorFactor")
                    if f:
                        col = _hexc(*f[:3])  # (stored as linear; close enough for a flat colour)
                for k in range(0, len(idx) - 2, 3):
                    tris.append([off + idx[k], off + idx[k + 1], off + idx[k + 2]])
                    cols.append(col)
        for c in n.get("children", []):
            visit(c, m, depth + 1)

    scene = js.get("scenes", [{}])[js.get("scene", 0)] if js.get("scenes") else {}
    roots = scene.get("nodes") or ([i for i in range(len(js.get("nodes", [])))] if not js.get("scenes") else [])
    for r in roots:
        visit(r, ident)
    return verts, tris, cols


LOADERS = {".obj": load_obj, ".stl": load_stl, ".ply": load_ply, ".glb": load_gltf, ".gltf": load_gltf}


# ------------------------------------------------------------ cleaning up
def _weld(verts, tris, cols, n):
    """Merge points that fall in the same cell of an n x n x n grid over the unit box; drop flat/duplicate triangles."""
    cell, newv, remap = {}, [], []
    sums = []
    for x, y, z in verts:
        k = (math.floor((x + 0.5) * n), math.floor((y + 0.5) * n), math.floor((z + 0.5) * n))
        i = cell.get(k)
        if i is None:
            i = cell[k] = len(sums)
            sums.append([0.0, 0.0, 0.0, 0])
        s = sums[i]
        s[0] += x; s[1] += y; s[2] += z; s[3] += 1
        remap.append(i)
    newv = [[s[0] / s[3], s[1] / s[3], s[2] / s[3]] for s in sums]
    seen, out, oc = set(), [], []
    for t, c in zip(tris, cols):
        a, b, d = remap[t[0]], remap[t[1]], remap[t[2]]
        if a == b or b == d or a == d:
            continue
        key = tuple(sorted((a, b, d)))
        if key in seen:
            continue
        seen.add(key)
        out.append([a, b, d])
        oc.append(c)
    return newv, out, oc


def _compact(verts, tris):
    """Drop points no triangle uses; renumber."""
    used = sorted({i for t in tris for i in t})
    m = {o: n for n, o in enumerate(used)}
    return [verts[i] for i in used], [[m[i] for i in t] for t in tris]


class Base:
    """A model that is ready to be placed: centred on the origin, longest side 1, within the limits."""

    def __init__(self, verts, tris, cols, name="", simplified=False, original_tris=0):
        self.verts, self.tris, self.cols = verts, tris, cols
        self.name, self.simplified, self.original_tris = name, simplified, original_tris


def prepare(verts, tris, cols, name=""):
    tris = [t for t in tris if all(0 <= i < len(verts) for i in t)]
    cols = cols[:len(tris)] if len(cols) >= len(tris) else cols + [None] * (len(tris) - len(cols))
    if not verts or not tris:
        raise MeshError("That file has no triangles in it. Export the model as triangles or quads (not just lines or points).")
    if any(not all(map(math.isfinite, v)) for v in verts):
        raise MeshError("That model contains broken numbers.")
    original = len(tris)
    verts, tris = _compact(verts, tris)
    xs, ys, zs = zip(*verts)
    mid = [(min(a) + max(a)) / 2 for a in (xs, ys, zs)]
    ext = max(max(a) - min(a) for a in (xs, ys, zs))
    if ext <= 0:
        raise MeshError("That model has no size.")
    verts = [[(v[0] - mid[0]) / ext, (v[1] - mid[1]) / ext, (v[2] - mid[2]) / ext] for v in verts]
    verts, tris, cols = _weld(verts, tris, cols, 400)  # tiny gaps and duplicate points
    simplified = False
    if len(tris) > av.MAX_TRIS or len(verts) > av.MAX_VERTS:
        simplified = True
        lo, hi, best = 2, 400, None
        while lo <= hi:  # the finest grid that still fits the limits
            mid_n = (lo + hi) // 2
            r = _weld(verts, tris, cols, mid_n)
            if len(r[1]) <= av.MAX_TRIS and len(r[0]) <= av.MAX_VERTS:
                best, lo = r, mid_n + 1
            else:
                hi = mid_n - 1
        if not best or not best[1]:
            raise MeshError("That model is too complicated to simplify. Try a lower-poly version.")
        verts, tris, cols = best
    verts, tris = _compact(verts, tris)
    if len(verts) < 3 or not tris:
        raise MeshError("That model ended up empty after cleaning.")
    return Base(verts, tris, cols, name, simplified, original)


def load(path) -> Base:
    ext = os.path.splitext(path)[1].lower()
    if ext not in LOADERS:
        raise MeshError("Use an OBJ, STL, PLY, GLB or glTF file.")
    try:
        if os.path.getsize(path) > MAX_FILE:
            raise MeshError("That file is bigger than 25 MB. Use a smaller, lower-poly model.")
        data = open(path, "rb").read()
    except OSError as e:
        raise MeshError(f"Couldn't read that file ({e.strerror or e}).")
    try:
        verts, tris, cols = LOADERS[ext](path, data)
    except MeshError:
        raise
    except (ValueError, IndexError, KeyError, struct.error, TypeError, json.JSONDecodeError, base64.binascii.Error):
        raise MeshError(f"Couldn't understand that {ext[1:].upper()} file. Is it a normal, uncompressed export?")
    return prepare(verts, tris, cols, os.path.basename(path))


# ------------------------------------------------------------ placing it on the avatar
def place(base: Base, slot, size=None, yaw=0.0, z_up=False, dx=0.0, dy=0.0, dz=0.0, color=DEFAULT_COLOR) -> dict:
    """The mesh for the avatar: turned, scaled so its longest side is `size` game units, and put where `slot` is worn."""
    ax, ay, az, how = ANCHOR[slot]
    size = SIZE[slot] if size is None else max(0.05, min(2.0, float(size)))
    c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    pts = []
    for x, y, z in base.verts:
        if z_up:
            y, z = z, -y
        pts.append([(x * c + z * s) * size, y * size, (-x * s + z * c) * size])
    ys = [p[1] for p in pts]
    lift = ay - min(ys) if how == "bottom" else ay - (min(ys) + max(ys)) / 2
    verts = [[p[0] + ax + dx, p[1] + lift + dy, p[2] + az + dz] for p in pts]
    mesh = {"v": [[round(x, 3) for x in v] for v in verts], "f": [list(t) for t in base.tris], "c": color}
    if any(base.cols):
        distinct = []
        for col in base.cols:
            if col and col not in distinct:
                distinct.append(col)
        if len(distinct) > av.MAX_PAL:
            distinct = _reduce(distinct)
        pal = list(distinct)
        if color not in pal and any(not c_ for c_ in base.cols):
            if len(pal) < av.MAX_PAL:
                pal.append(color)
        fc = "".join(str(_nearest(col or color, pal)) for col in base.cols)
        mesh["pal"], mesh["fc"] = pal, fc
    return mesh


def _rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))


def _nearest(col, pal):
    r = _rgb(col)
    return min(range(len(pal)), key=lambda i: sum((a - b) ** 2 for a, b in zip(r, _rgb(pal[i]))))


def _reduce(colors):
    """At most 8 colours standing in for many (median cut via Pillow)."""
    from PIL import Image
    im = Image.new("RGB", (len(colors), 1))
    for i, c in enumerate(colors):
        im.putpixel((i, 0), _rgb(c))
    q = im.quantize(colors=av.MAX_PAL, method=Image.Quantize.MEDIANCUT)
    p = q.getpalette()[:3 * av.MAX_PAL]
    used = sorted(set(q.getdata()))
    return ["#%02x%02x%02x" % tuple(p[i * 3:i * 3 + 3]) for i in used]
