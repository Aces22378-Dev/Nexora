"""Local account store for Nexora v0.1 (this PC only, no server yet)."""
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from pathlib import Path


def data_dir() -> Path:
    base = os.getenv("APPDATA") or os.getenv("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    d = Path(base) / "Nexora"
    d.mkdir(parents=True, exist_ok=True)
    return d


DB_FILE = data_dir() / "nexora-db.json"


def _load() -> dict:
    try:
        return json.loads(DB_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"users": {}, "session": None}


def _save(db: dict) -> None:
    tmp = DB_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(db, indent=2), encoding="utf-8")
    os.replace(tmp, DB_FILE)


def _hash(pw: str, salt: str) -> str:
    return hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1, dklen=64).hex()


def _norm(u: dict) -> dict:
    """Fill in fields that older accounts don't have yet."""
    u.setdefault("avatar", dict(DEFAULT_AVATAR))
    for k in ("friends", "incoming", "outgoing", "blocked"):
        u.setdefault(k, [])
    u.setdefault("settings", {})
    return u


def _public(u: dict) -> dict:
    _norm(u)
    return {
        "username": u["username"], "created": u["created"], "plays": u["plays"], "best": u["best"],
        "avatar": dict(u["avatar"]), "friends": list(u["friends"]),
        "incoming": list(u["incoming"]), "outgoing": list(u["outgoing"]),
        "blocked": list(u["blocked"]),
    }


RESERVED_NAMES = {"nexora", "admin", "administrator", "moderator", "staff", "support", "system", "creator"}


def register(username: str, password: str, remember: bool = True) -> dict:
    username = (username or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
        return {"ok": False, "error": "Username must be 3-20 letters, numbers or underscores."}
    if len(password or "") < 6:
        return {"ok": False, "error": "Password must be at least 6 characters."}
    db = _load()
    key = username.lower()
    if key in db["users"] or key in RESERVED_NAMES:
        return {"ok": False, "error": "That username is taken."}
    salt = secrets.token_hex(16)
    db["users"][key] = {
        "username": username, "salt": salt, "hash": _hash(password, salt),
        "created": int(time.time()), "plays": {}, "best": {},
    }
    if remember:
        db["session"] = key
    _save(db)
    return {"ok": True, "user": _public(db["users"][key])}


def login(username: str, password: str, remember: bool = True) -> dict:
    db = _load()
    key = (username or "").strip().lower()
    u = db["users"].get(key)
    if not u or not hmac.compare_digest(_hash(password or "", u["salt"]), u["hash"]):
        return {"ok": False, "error": "Wrong username or password."}
    u.pop("deactivated", None)  # logging in reactivates a deactivated account
    if remember:  # Nexora Studio signs in with remember=False so it doesn't log the player app out
        db["session"] = key
    _save(db)
    return {"ok": True, "user": _public(u)}


def session() -> dict:
    db = _load()
    u = db["users"].get(db["session"] or "")
    return {"ok": True, "user": _public(u)} if u else {"ok": False}


def canonical_name(username: str):
    """The account's real spelling of a username, or None if there is no such account."""
    u = _load()["users"].get((username or "").strip().lower())
    return u["username"] if u else None


def get_user(username: str) -> dict:
    u = _load()["users"].get((username or "").lower())
    return {"ok": True, "user": _public(u)} if u else {"ok": False}


def logout() -> None:
    db = _load()
    db["session"] = None
    _save(db)


def record_play(username: str, game_id: str, score: int) -> dict:
    db = _load()
    u = db["users"].get((username or "").lower())
    if not u:
        return {"ok": False}
    u["plays"][game_id] = u["plays"].get(game_id, 0) + 1
    u["best"][game_id] = max(u["best"].get(game_id, 0), int(score))
    _save(db)
    return {"ok": True, "user": _public(u)}


# ---------------- avatars, profiles, friends (all local to this PC for now) ----------------
DEFAULT_AVATAR = {"skin": "#f1c27d", "shirt": "#7c5cff", "pants": "#2b2b4a"}
_HEX = re.compile(r"#[0-9a-fA-F]{6}")


def _find(db: dict, name: str):
    return db["users"].get((name or "").strip().lower())


def _has(lst: list, name: str) -> bool:
    return any(x.lower() == name.lower() for x in lst)


def _drop(lst: list, name: str) -> None:
    lst[:] = [x for x in lst if x.lower() != name.lower()]


def _add(lst: list, name: str) -> None:
    if not _has(lst, name):
        lst.append(name)


def _status(me: dict, other: dict) -> str:
    if me is other:
        return "self"
    if _has(me["blocked"], other["username"]):
        return "blocked"
    if _has(me["friends"], other["username"]):
        return "friends"
    if _has(me["incoming"], other["username"]):
        return "incoming"
    if _has(me["outgoing"], other["username"]):
        return "outgoing"
    return "none"


def _blocked_either(me: dict, other: dict) -> bool:
    return _has(_norm(me)["blocked"], other["username"]) or _has(_norm(other)["blocked"], me["username"])


def blocked_between(a_name: str, b_name: str) -> bool:
    """True if either local account has blocked the other (used to hide players in games)."""
    db = _load()
    a, b = _find(db, a_name), _find(db, b_name)
    return bool(a and b and a is not b and _blocked_either(a, b))


def _card(other: dict, me: dict | None = None) -> dict:
    _norm(other)
    status = _status(_norm(me), other) if me else "none"
    # Respect the profile-stats privacy setting: everyone / friends / nobody (you always see yourself).
    vis = _setting(other, "profile_stats")
    show = status == "self" or vis == "everyone" or (vis == "friends" and status == "friends")
    return {
        "username": other["username"], "created": other["created"], "avatar": dict(other["avatar"]),
        "total_plays": sum(other["plays"].values()) if show else None,
        "friend_count": len(other["friends"]) if show else None,
        "friend_status": status,
    }


def profile(username: str, viewer: str | None = None) -> dict:
    db = _load()
    u = _find(db, username)
    me = _find(db, viewer) if viewer else None
    if not u or u.get("deactivated") or (me and u is not me and _has(_norm(u)["blocked"], me["username"])):
        return {"ok": False}
    return {"ok": True, "user": _card(u, me)}


def search_users(query: str, viewer: str | None = None) -> list:
    """Users whose name contains `query` (everyone if empty), excluding the viewer,
    deactivated accounts and anyone blocked either way."""
    db = _load()
    me = _find(db, viewer) if viewer else None
    q = (query or "").strip().lower()
    if me and _restricted(me, "restrict_friends"):
        return []  # parental controls: no looking for new people
    out = []
    for _, u in sorted(db["users"].items()):
        if u is me or u.get("deactivated") or q not in u["username"].lower():
            continue
        if not _setting(u, "searchable") or _restricted(u, "restrict_friends"):
            continue
        if me and _blocked_either(me, u):
            continue
        out.append(_card(u, me))
    return out[:50]


def set_avatar(username: str, avatar: dict) -> dict:
    db = _load()
    u = _find(db, username)
    if not u:
        return {"ok": False, "error": "Not logged in."}
    _norm(u)
    import avatar as av_mod
    u["avatar"] = av_mod.clean({**u["avatar"], **(avatar or {})})  # colours, pictures and accessories, all checked
    _save(db)
    return {"ok": True, "user": _public(u)}


def _pair(db: dict, a: str, b: str):
    me, other = _find(db, a), _find(db, b)
    if not me or not other or me is other:
        return None
    return _norm(me), _norm(other)


def _done(db: dict, me: dict) -> dict:
    _save(db)
    return {"ok": True, "user": _public(me)}


def send_request(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    if _has(me["friends"], other["username"]):
        return {"ok": True, "user": _public(me)}
    if other.get("deactivated") or _blocked_either(me, other):
        return {"ok": False, "error": "You can't send a friend request to this user."}
    if _restricted(me, "restrict_friends") or _restricted(other, "restrict_friends"):
        return {"ok": False, "error": "Friend requests are turned off by parental controls."}
    if _has(me["incoming"], other["username"]):  # they already asked you, so just accept
        return accept_request(me_name, other_name)
    if _setting(other, "friend_requests") == "nobody":
        return {"ok": False, "error": "This user isn't accepting friend requests."}
    _add(other["incoming"], me["username"])
    _add(me["outgoing"], other["username"])
    return _done(db, me)


def accept_request(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    if not _has(me["incoming"], other["username"]):
        return {"ok": False, "error": "No request from that user."}
    if _restricted(me, "restrict_friends") or _restricted(other, "restrict_friends"):
        return {"ok": False, "error": "Friend requests are turned off by parental controls."}
    for lst, name in ((me["incoming"], other["username"]), (other["outgoing"], me["username"]),
                      (me["outgoing"], other["username"]), (other["incoming"], me["username"])):
        _drop(lst, name)
    _add(me["friends"], other["username"])
    _add(other["friends"], me["username"])
    return _done(db, me)


def decline_request(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    _drop(me["incoming"], other["username"])
    _drop(other["outgoing"], me["username"])
    return _done(db, me)


def cancel_request(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    _drop(me["outgoing"], other["username"])
    _drop(other["incoming"], me["username"])
    return _done(db, me)


def remove_friend(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    _drop(me["friends"], other["username"])
    _drop(other["friends"], me["username"])
    return _done(db, me)


# ---------------- settings ----------------
THEME_NAMES = ("midnight", "ocean", "sunset", "forest", "light", "contrast")
LOCKED_KEYS = ("friend_requests", "profile_stats", "searchable", "chat")  # need the parental PIN when one is set
_SERVER_RE = re.compile(r"[A-Za-z0-9_.\-]{1,100}:\d{1,5}")
_EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")


def _is_bool(v) -> bool:
    return isinstance(v, bool)


def _int_range(lo: int, hi: int):
    return lambda v: isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi


# key: (default, validator)
SETTINGS = {
    "email": ("", lambda v: isinstance(v, str) and len(v) <= 120 and (v == "" or _EMAIL_RE.fullmatch(v) is not None)),
    "friend_requests": ("everyone", lambda v: v in ("everyone", "nobody")),
    "profile_stats": ("everyone", lambda v: v in ("everyone", "friends", "nobody")),
    "searchable": (True, _is_bool),
    "notify_requests": (True, _is_bool),
    "online_scripts": (False, _is_bool),
    "chat": ("everyone", lambda v: v in ("everyone", "friends", "off")),
    "fullscreen": (False, _is_bool),
    "vsync": (True, _is_bool),
    "show_fps": (False, _is_bool),
    "invert_y": (False, _is_bool),
    "fov": (90, _int_range(60, 110)),
    "mouse_sens": (50, _int_range(10, 100)),
    "cam_distance": (9, _int_range(4, 16)),
    "theme": ("midnight", lambda v: v in THEME_NAMES),
    "text_size": ("normal", lambda v: v in ("small", "normal", "large")),
    "favorites": ([], lambda v: isinstance(v, list) and len(v) <= 100
                  and all(isinstance(s, str) and 0 < len(s) <= 100 for s in v)),
    "recent": ([], lambda v: isinstance(v, list) and len(v) <= 12
               and all(isinstance(s, str) and 0 < len(s) <= 100 for s in v)),
    "saved_servers": ([], lambda v: isinstance(v, list) and len(v) <= 30
                      and all(isinstance(s, str) and _SERVER_RE.fullmatch(s) for s in v)),
}


def _setting(u: dict, key: str):
    default, _ = SETTINGS[key]
    val = _norm(u)["settings"].get(key, default)
    return list(val) if isinstance(val, list) else val


def get_settings(username: str) -> dict:
    u = _find(_load(), username)
    if not u:
        return {k: (list(d) if isinstance(d, list) else d) for k, (d, _) in SETTINGS.items()}
    return {k: _setting(u, k) for k in SETTINGS}


def set_settings(username: str, updates: dict, pin: str | None = None) -> dict:
    db = _load()
    u = _find(db, username)
    if not u:
        return {"ok": False, "error": "Not logged in."}
    bad = [k for k, v in updates.items() if k not in SETTINGS or not SETTINGS[k][1](v)]
    if bad:
        return {"ok": False, "error": "Invalid value for: " + ", ".join(bad)}
    if u.get("parental") and any(k in LOCKED_KEYS for k in updates) and not _pin_ok(u, pin):
        return {"ok": False, "error": "Parental PIN required.", "pin_required": True}
    _norm(u)["settings"].update({k: (list(v) if isinstance(v, list) else v) for k, v in updates.items()})
    _save(db)
    return {"ok": True, "settings": {k: _setting(u, k) for k in SETTINGS}}


# ---------------- parental controls ----------------
def _pin_ok(u: dict, pin) -> bool:
    p = u.get("parental")
    return bool(p) and isinstance(pin, str) and hmac.compare_digest(_hash(pin, p["salt"]), p["hash"])


def _restricted(u: dict, what: str) -> bool:
    return bool((u.get("parental") or {}).get(what))


def parental_status(username: str) -> dict:
    u = _find(_load(), username)
    p = (u or {}).get("parental")
    return {"enabled": bool(p), "restrict_friends": bool(p and p["restrict_friends"]),
            "restrict_join": bool(p and p["restrict_join"])}


def parental_check(username: str, pin: str) -> bool:
    u = _find(_load(), username)
    return bool(u) and _pin_ok(u, pin)


def parental_enable(username: str, password: str, pin: str, restrict_friends: bool, restrict_join: bool) -> dict:
    db = _load()
    u = _find(db, username)
    if not u or not _verify(u, password):
        return {"ok": False, "error": "Password is wrong."}
    if u.get("parental"):
        return {"ok": False, "error": "Parental controls are already on."}
    if not re.fullmatch(r"\d{4,8}", pin or ""):
        return {"ok": False, "error": "The PIN must be 4-8 digits."}
    salt = secrets.token_hex(16)
    u["parental"] = {"salt": salt, "hash": _hash(pin, salt),
                     "restrict_friends": bool(restrict_friends), "restrict_join": bool(restrict_join)}
    _save(db)
    return {"ok": True, "status": parental_status(username)}


def parental_update(username: str, pin: str, restrict_friends: bool, restrict_join: bool) -> dict:
    db = _load()
    u = _find(db, username)
    if not u or not _pin_ok(u, pin):
        return {"ok": False, "error": "Wrong PIN."}
    u["parental"]["restrict_friends"] = bool(restrict_friends)
    u["parental"]["restrict_join"] = bool(restrict_join)
    _save(db)
    return {"ok": True, "status": parental_status(username)}


def parental_disable(username: str, pin: str) -> dict:
    db = _load()
    u = _find(db, username)
    if not u or not _pin_ok(u, pin):
        return {"ok": False, "error": "Wrong PIN."}
    u.pop("parental", None)
    _save(db)
    return {"ok": True}


# ---------------- account management ----------------
def _verify(u: dict, password: str) -> bool:
    return hmac.compare_digest(_hash(password or "", u["salt"]), u["hash"])


def change_password(username: str, old: str, new: str) -> dict:
    db = _load()
    u = _find(db, username)
    if not u or not _verify(u, old):
        return {"ok": False, "error": "Current password is wrong."}
    if len(new or "") < 6:
        return {"ok": False, "error": "New password must be at least 6 characters."}
    u["salt"] = secrets.token_hex(16)
    u["hash"] = _hash(new, u["salt"])
    _save(db)
    return {"ok": True}


def change_username(username: str, password: str, new_name: str) -> dict:
    db = _load()
    u = _find(db, username)
    new_name = (new_name or "").strip()
    if not u or not _verify(u, password):
        return {"ok": False, "error": "Password is wrong."}
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", new_name):
        return {"ok": False, "error": "Username must be 3-20 letters, numbers or underscores."}
    old_name, old_key, new_key = u["username"], u["username"].lower(), new_name.lower()
    if new_key != old_key and new_key in db["users"]:
        return {"ok": False, "error": "That username is taken."}
    del db["users"][old_key]
    u["username"] = new_name
    db["users"][new_key] = u
    for o in db["users"].values():  # keep other people's friend/block lists pointing at the new name
        _norm(o)
        for k in ("friends", "incoming", "outgoing", "blocked"):
            o[k] = [new_name if x.lower() == old_name.lower() else x for x in o[k]]
    if db["session"] == old_key:
        db["session"] = new_key
    _save(db)
    return {"ok": True, "user": _public(u)}


def deactivate_account(username: str, password: str) -> dict:
    db = _load()
    u = _find(db, username)
    if not u or not _verify(u, password):
        return {"ok": False, "error": "Password is wrong."}
    u["deactivated"] = True
    if db["session"] == u["username"].lower():
        db["session"] = None
    _save(db)
    return {"ok": True}


def online_mirror_names() -> list:
    """Local records of accounts that live on the Nexora server (made by ensure_local)."""
    return [u["username"] for u in _load()["users"].values() if u.get("online")]


def remove_gone(names: list) -> list:
    """The server says these accounts no longer exist: drop their local copies and every friend link to them.
    Only server mirrors are touched, never an account that only exists on this PC."""
    gone = []
    db = _load()
    for n in names:
        u = _find(db, n)
        if not u or not u.get("online"):
            continue
        del db["users"][u["username"].lower()]
        for o in db["users"].values():
            _norm(o)
            for k in ("friends", "incoming", "outgoing", "blocked"):
                _drop(o[k], u["username"])
        if db["session"] == u["username"].lower():
            db["session"] = None
        gone.append(u["username"])
    if gone:
        _save(db)
    return gone


def delete_account(username: str, password: str, verified: bool = False) -> dict:
    """verified=True: the online server already checked the password (the local copy of an online account has a
    random one nobody knows)."""
    db = _load()
    u = _find(db, username)
    if not u or not (verified or _verify(u, password)):
        return {"ok": False, "error": "Password is wrong."}
    name = u["username"]
    del db["users"][name.lower()]
    for o in db["users"].values():
        _norm(o)
        for k in ("friends", "incoming", "outgoing", "blocked"):
            _drop(o[k], name)
    if db["session"] == name.lower():
        db["session"] = None
    _save(db)
    return {"ok": True}


# ---------------- blocking ----------------
def block_user(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    for a, b in ((me, other), (other, me)):  # blocking ends friendships and pending requests
        for k in ("friends", "incoming", "outgoing"):
            _drop(a[k], b["username"])
    _add(me["blocked"], other["username"])
    return _done(db, me)


def unblock_user(me_name: str, other_name: str) -> dict:
    db = _load()
    p = _pair(db, me_name, other_name)
    if not p:
        return {"ok": False, "error": "User not found."}
    me, other = p
    _drop(me["blocked"], other["username"])
    return _done(db, me)


def blocked_users(username: str) -> list:
    u = _find(_load(), username)
    return list(_norm(u)["blocked"]) if u else []


# ---------------- help & support (saved on this PC only: there is no support team to receive it yet) ----------------
def submit_report(username: str, category: str, text: str) -> dict:
    text = (text or "").strip()
    if len(text) < 5:
        return {"ok": False, "error": "Please describe the problem (at least a few words)."}
    entry = {"time": int(time.time()), "user": username, "category": str(category)[:40], "text": text[:2000]}
    try:
        with open(data_dir() / "reports.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError as e:
        return {"ok": False, "error": f"Couldn't save the report: {e.strerror or e}"}
    return {"ok": True}


def report_count(username: str) -> int:
    try:
        lines = (data_dir() / "reports.jsonl").read_text(encoding="utf-8").splitlines()
    except OSError:
        return 0
    n = 0
    for ln in lines:
        try:
            n += json.loads(ln).get("user", "").lower() == (username or "").lower()
        except ValueError:
            pass
    return n


# ---------------- hand-off of error messages from the game process to the launcher ----------------
def set_last_error(msg: str) -> None:
    try:
        (data_dir() / "last_error.txt").write_text(msg, encoding="utf-8")
    except OSError:
        pass


def pop_last_error() -> str:
    p = data_dir() / "last_error.txt"
    try:
        msg = p.read_text(encoding="utf-8")
        p.unlink()
        return msg
    except OSError:
        return ""


def is_friend(a_name: str, b_name: str) -> bool:
    db = _load()
    a, b = _find(db, a_name), _find(db, b_name)
    return bool(a and b and _has(_norm(a)["friends"], b["username"]))


def ensure_local(username: str, avatar: dict | None = None, remember: bool = True) -> dict:
    """After signing in on the Nexora server: make sure this PC has a local record for the account (friends,
    settings and blocks are still kept on this PC). It gets a random password nobody knows, because the server
    is what checks the real one."""
    db = _load()
    key = username.lower()
    u = db["users"].get(key)
    if not u:
        salt = secrets.token_hex(16)
        u = db["users"][key] = {"username": username, "salt": salt, "hash": _hash(secrets.token_hex(24), salt),
                                "created": int(time.time()), "plays": {}, "best": {}, "online": True}
    u["username"] = username
    u.pop("deactivated", None)
    _norm(u)
    for k in ("skin", "shirt", "pants"):
        c = (avatar or {}).get(k)
        if isinstance(c, str) and _HEX.fullmatch(c):
            u["avatar"][k] = c.lower()
    if remember:
        db["session"] = key
    _save(db)
    return {"ok": True, "user": _public(u)}
