"""Small shared tkinter pieces for the launcher."""
import tkinter as tk

import theme as th

SKIN = ["#f8d9b8", "#f1c27d", "#e0ac69", "#c68642", "#8d5524", "#5c3a1e"]
SHIRT = ["#7c5cff", "#22d3ee", "#ef4444", "#f59e0b", "#4ade80", "#ec4899", "#f8fafc", "#1f2937"]
PANTS = ["#2b2b4a", "#1d4ed8", "#374151", "#7f1d1d", "#14532d", "#78350f", "#f8fafc", "#0f172a"]


ACC_SCALE = 13.33  # game units -> avatar drawing units (head top 2.1 = the top of the picture)


def draw_avatar(canvas, av, s=6, ox=0, oy=0, top=0):
    """Blocky avatar, 16 x 28 units of size `s` pixels. Draws shirt/pants pictures and accessories when it has them.
    `top` = extra units of room above the head, so tall hats are not cut off."""
    import avatar as av_h
    h, w = av.get("height") or 1.0, av.get("width") or 1.0
    female = av.get("body") == "female"
    bw = w * (0.88 if female else 1.0)            # torso and arms are a bit slimmer on the female body
    dy, dx = max(0.0, 28 * (h - 1)), max(0.0, 8 * (w - 1))
    try:   # a tall or wide avatar shrinks to stay inside a small preview instead of being cut off
        cw = max(canvas.winfo_width(), int(float(canvas.cget("width"))))
        ch = max(canvas.winfo_height(), int(float(canvas.cget("height"))))
        s = min(s, (cw - ox - 4) / (16 + 2 * dx), (ch - oy - 4) / (top + 28 + dy))
    except (tk.TclError, ValueError):
        pass
    oy = oy + (top + dy) * s
    ox = ox + dx * s
    def tx(x, k=w):
        return 8 + (x - 8) * k

    def ty(y):
        return 28 - (28 - y) * h

    def r(x0, y0, x1, y1, c, k=w):
        canvas.create_rectangle(ox + tx(x0, k) * s, oy + ty(y0) * s, ox + tx(x1, k) * s, oy + ty(y1) * s, fill=c, outline="")

    def tex(t, x0, y0, w_, h_, cols=None, k=None):
        """Draw a picture into a w x h area (only the columns cols[0]..cols[1] of it, as a fraction 0..1, when given).
        Runs of one colour along a row are drawn as a single rectangle, so a 32 x 32 picture stays cheap."""
        import avatar as av_
        pw, ph = (av_.TEX_SIZES | av_.SLEEVE_SIZES)[len(t["px"])]
        c0, c1 = (0, pw) if not cols else (round(cols[0] * pw), round(cols[1] * pw))
        cw_, ch_ = w_ / (c1 - c0), h_ / ph
        for row in range(ph):
            line = t["px"][row * pw:(row + 1) * pw]
            x = c0
            while x < c1:
                c = line[x]
                e = x
                while e < c1 and line[e] == c:
                    e += 1
                if c != ".":
                    r(x0 + (x - c0) * cw_, y0 + row * ch_, x0 + (e - c0) * cw_, y0 + (row + 1) * ch_,
                      t["pal"][av_.PAL_CHARS.index(c)], k if k is not None else w)
                x = e

    def box(b):
        (x, y, z), (bw_, bh, bd) = b["p"], b["s"]
        cx, cy = 8 + x * ACC_SCALE, 28 - y * ACC_SCALE
        r(cx - bw_ * ACC_SCALE / 2, cy - bh * ACC_SCALE / 2, cx + bw_ * ACC_SCALE / 2, cy + bh * ACC_SCALE / 2, b["c"])

    def mesh(m):
        """A 3D model seen from the front: triangles far to near, shaded by which way they face."""
        from meshshade import mesh_shades
        tris = mesh_shades(m)
        tris.sort(key=lambda t: t[0][2] + t[1][2] + t[2][2])
        for p, q, r_, c in tris:
            pts = []
            for x, y, _z in (p, q, r_):
                pts += [ox + tx(8 + x * ACC_SCALE) * s, oy + ty(28 - y * ACC_SCALE) * s]
            canvas.create_polygon(pts, fill="#%02x%02x%02x" % tuple(int(v * 255) for v in c), outline="")

    def acc_parts(a):
        for b in a["boxes"]:
            box(b)
        if a.get("mesh"):
            mesh(a["mesh"])

    skin, shirt, pants = av["skin"], av["shirt"], av["pants"]
    accs = av.get("acc") or []
    for a in accs:
        if a["slot"] == "back":
            acc_parts(a)
    hidden = av_h.hidden_slots(accs)   # "Headless" / "Legless": a part is simply not drawn
    if "noleftleg" not in hidden:        # the avatar's left leg is the one on the left of the picture
        r(4, 18, 8, 28, pants)
        if av.get("pants_tex"):
            tex(av["pants_tex"], 4, 18, 4, 10, cols=(0, 0.5))
    if "norightleg" not in hidden:
        r(8, 18, 12, 28, pants)
        if av.get("pants_tex"):
            tex(av["pants_tex"], 8, 18, 4, 10, cols=(0.5, 1))
    r(1, 8, 4, 18, shirt, bw)
    r(12, 8, 15, 18, shirt, bw)
    if av.get("sleeve_tex"):
        tex(av["sleeve_tex"], 1, 8, 3, 7, k=bw)
        tex(av["sleeve_tex"], 12, 8, 3, 7, k=bw)
    r(1, 15, 4, 18, skin, bw)
    r(12, 15, 15, 18, skin, bw)
    r(4, 8, 12, 18, shirt, bw)
    if av.get("shirt_tex"):
        tex(av["shirt_tex"], 4, 8, 8, 10, k=bw)
    if "nohead" not in hidden:
        r(4, 0, 12, 8, skin)
        r(6, 3, 7, 4, "#222222")
        r(9, 3, 10, 4, "#222222")
        if female:   # lashes and pink lips
            r(5.6, 2.5, 7.4, 3, "#222222")
            r(8.6, 2.5, 10.4, 3, "#222222")
            r(6.5, 5.5, 9.5, 6, "#d6567a")
        else:
            r(6.5, 5.5, 9.5, 6, "#aa3333")
    for a in accs:
        if a["slot"] != "back":
            acc_parts(a)


class ScrollFrame(tk.Frame):
    """A vertically scrolling area; put children in `.inner`."""

    def __init__(self, parent, bg=None):
        bg = bg or th.BG
        super().__init__(parent, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.win, width=e.width))
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.canvas.bind("<Enter>", self._bind_wheel)
        self.canvas.bind("<Leave>", self._unbind_wheel)
        self.inner.bind("<Enter>", self._bind_wheel)

    def _bind_wheel(self, _e=None):
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)  # Linux
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _unbind_wheel(self, _e=None):
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.canvas.unbind_all(ev)

    def _wheel(self, e):
        step = -1 if (e.num == 4 or e.delta > 0) else 1
        # only scroll when there is something to scroll
        if self.canvas.yview() != (0.0, 1.0):
            self.canvas.yview_scroll(step * 2, "units")
