"""Built-in game definitions. Nexora Studio will later produce data in this same shape.
Platforms: (x, y, z, width, height, depth, hex_color) - x/y/z is the box center."""

import project

GAMES = [
    {
        "id": "plaza",
        "name": "Nexora Plaza",
        "desc": "A chill open plaza. Collect every coin.",
        "emoji": "🏙️",
        "thumb": "#4f46e5",
        "sky": "#7fb8ff",
        "spawn": (0, 2, 0),
        "kill_y": -30,
        "goal": None,
        "platforms": [
            (0, -0.5, 0, 80, 1, 80, "#4ade80"),
            (10, 0.75, -8, 6, 2.5, 6, "#f59e0b"),
            (16, 1.75, -8, 4, 4.5, 4, "#ef4444"),
            (-12, 0.5, 10, 8, 2, 3, "#8b5cf6"),
            (-18, 1.5, 10, 4, 4, 3, "#6366f1"),
            (0, 0.5, -20, 14, 2, 2, "#06b6d4"),
            (-25, 0.5, -15, 3, 2, 3, "#ec4899"),
            (25, 0.5, 15, 5, 2, 5, "#eab308"),
        ],
        "coins": [
            (10, 3, -8), (16, 5, -8), (-12, 2.5, 10), (-18, 4.5, 10), (0, 2.5, -20),
            (-25, 2.5, -15), (25, 2.5, 15), (5, 1, 12), (-8, 1, -10), (30, 1, -25),
        ],
    },
    {
        "id": "skyrun",
        "name": "Sky Run",
        "desc": "An obby above the clouds. Reach the gold pad.",
        "emoji": "☁️",
        "thumb": "#db2777",
        "sky": "#ffc2e0",
        "spawn": (0, 2, 0),
        "kill_y": -15,
        "goal": (0, 6, -92),
        "platforms": [
            (0, -0.5, 0, 8, 1, 8, "#22d3ee"),
            (0, 0, -11, 4, 1, 4, "#f472b6"),
            (5, 0.8, -18, 4, 1, 4, "#a78bfa"),
            (10, 1.6, -26, 3, 1, 3, "#f472b6"),
            (4, 2.4, -34, 3, 1, 3, "#a78bfa"),
            (-3, 3.2, -41, 2.5, 1, 2.5, "#f472b6"),
            (-4, 4, -50, 6, 1, 3, "#22d3ee"),
            (2, 4.5, -58, 2.5, 1, 2.5, "#a78bfa"),
            (7, 5, -66, 2.5, 1, 2.5, "#f472b6"),
            (2, 5.5, -74, 2, 1, 2, "#a78bfa"),
            (-2, 5.5, -82, 2, 1, 2, "#f472b6"),
            (0, 5.5, -92, 8, 1, 8, "#facc15"),
        ],
        "coins": [],
    },
]

BY_ID = {g["id"]: g for g in GAMES}


# ---- everything below turns both kinds of game (built-in, made in Studio) into one shape the runner can use
def _builtin_to_project(g: dict) -> dict:
    parts = []
    for i, (x, y, z, w, h, d, c) in enumerate(g["platforms"]):
        parts.append({"id": f"p{i + 1}", "name": "Platform", "kind": "part", "pos": [x, y, z], "size": [w, h, d],
                      "color": c})
    for i, (x, y, z) in enumerate(g["coins"]):
        parts.append({"id": f"c{i + 1}", "name": "Coin", "kind": "coin", "pos": [x, y, z], "size": [0.9, 0.9, 0.15]})
    if g.get("goal"):
        parts.append({"id": "goal", "name": "Goal", "kind": "goal", "pos": list(g["goal"])})
    d = {"id": g["id"], "name": g["name"], "desc": g["desc"], "emoji": g["emoji"], "thumb": g["thumb"],
         "sky": g["sky"], "kill_y": g["kill_y"], "parts": parts, "scripts": [], "owner": "Nexora"}
    out = project.to_game(project.clean_project(d))
    out["user"] = False
    out["spawn"] = tuple(g["spawn"])
    return out


_BUILTIN = {g["id"]: _builtin_to_project(g) for g in GAMES}


def all_games() -> list:
    """Built-in games, then games published from Nexora Studio."""
    return list(_BUILTIN.values()) + project.load_user_games()[0]


def get_game(game_id: str):
    """One playable game by id (or None if this PC doesn't have it)."""
    if game_id in _BUILTIN:
        return _BUILTIN[game_id]
    for g in project.load_user_games()[0]:
        if g["id"] == game_id:
            return g
    return None
