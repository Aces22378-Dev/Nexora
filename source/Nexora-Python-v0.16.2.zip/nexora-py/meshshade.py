"""Shading for imported 3D accessories, shared by the 2D preview and the 3D avatar (no graphics libraries here)."""


LIGHT = (0.35, 0.8, 0.5)


def mesh_shades(m):
    """For each triangle: its three points and a colour shaded by which way it faces (flat, two-sided)."""
    from math import sqrt
    l = sqrt(sum(x * x for x in LIGHT))
    pal = [tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)) for h in m.get("pal") or [m["c"]]]
    fc = m.get("fc")
    out = []
    for k, (a, b, c) in enumerate(m["f"]):
        p, q, r = m["v"][a], m["v"][b], m["v"][c]
        u, w = [q[i] - p[i] for i in range(3)], [r[i] - p[i] for i in range(3)]
        n = (u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0])
        ln = sqrt(sum(x * x for x in n)) or 1.0
        lit = abs(sum(n[i] * LIGHT[i] for i in range(3))) / (ln * l)
        base = pal[int(fc[k])] if fc else pal[0]
        f = 0.55 + 0.45 * lit
        out.append((p, q, r, tuple(min(1.0, x * f) for x in base)))
    return out
