"""Nexora Studio - the creator app. A separate program from Nexora (the player app).
Build 3D games from parts, add Python scripts, test them, and publish them to Nexora.

Run:   python studio.py            (or NexoraStudio.exe)
Hidden modes (used by Studio itself):  studio.py --run <game.json>   opens the game window for Play Test
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import tkinter as tk
import traceback
from pathlib import Path
from tkinter import colorchooser, filedialog, messagebox, simpledialog, ttk

import accounts
import discordrpc
import online
from version import VERSION
import project as pj
import scripting
import studio_prefs
import theme as th
import viewport3d as vp
from script_editor import ScriptEditor

TITLE = "Nexora Studio"
KIND_ICON = {"part": "▪", "coin": "●", "spawn": "⚑", "goal": "★"}


def resource(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def arg(name, default=None):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


GUIDE = scripting.__doc__ + '''

EXAMPLES
    # make a part disappear when touched (attach to a part)
    def on_touch(who):
        part.visible = False
        game.score += 10

    # spin a part (attach to a part)
    angle = 0
    def on_update(dt):
        global angle
        angle += 90 * dt
        part.rot_y = angle

    # a game-wide script
    def on_start():
        game.say("Find the 5 coins!", 4)
        game.every(10, lambda: game.say("Hurry up!"))
'''


class Studio(tk.Tk):
    def __init__(self, open_path=None):
        super().__init__()
        self.title(TITLE)
        self.geometry("1360x840")
        self.minsize(1100, 680)
        th.apply("midnight")
        self.configure(bg=th.BG)
        for cls in ("Button", "Checkbutton", "Radiobutton", "Scrollbar"):
            self.option_add(f"*{cls}.highlightThickness", 0)
        try:
            self._icon = tk.PhotoImage(file=resource("assets/studio_64.png"))
            self.iconphoto(True, self._icon)
            if sys.platform == "win32":
                self.iconbitmap(resource("assets/studio.ico"))
        except tk.TclError:
            pass
        self._style()
        self.user = None       # signed-in Nexora account name (None = signed out)
        self.net = online.Session(persist=False)  # online account (kept in memory only); used when a server is set
        self.proj = None
        self.viewport = None
        self.editors = {}      # script id -> ScriptEditor
        self.proc = None
        self.log_path = None
        self.log_pos = 0
        self.props_busy = False
        self.home_frame = self.edit_frame = None
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.open_path = open_path
        self.show_login()

    # ================================================================ look
    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        for w in ("Treeview", "TNotebook"):  # no bright 3D borders from the clam theme
            s.configure(w, bordercolor=th.BG, lightcolor=th.BG, darkcolor=th.BG, focuscolor=th.BG)
        s.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
        s.configure("Treeview", background=th.PANEL, fieldbackground=th.PANEL, foreground=th.TEXT, borderwidth=0,
                    rowheight=24, font=(th.FONT, 10))
        s.map("Treeview", background=[("selected", th.ACCENT)], foreground=[("selected", th.ON_ACCENT)])
        s.configure("TNotebook", background=th.BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=th.PANEL2, foreground=th.DIM, padding=(12, 5), borderwidth=0,
                    focuscolor=th.PANEL2)
        s.layout("TNotebook.Tab", [("Notebook.tab", {"sticky": "nswe", "children": [("Notebook.padding", {
            "side": "top", "sticky": "nswe", "children": [("Notebook.label", {"side": "top", "sticky": ""})]})]})])
        s.map("TNotebook.Tab", background=[("selected", th.PANEL)], foreground=[("selected", th.TEXT)])
        s.configure("TCombobox", fieldbackground=th.PANEL2, background=th.PANEL2, foreground=th.TEXT)

    def btn(self, parent, text, cmd, accent=False, **kw):
        bg, fg = (th.ACCENT, th.ON_ACCENT) if accent else (th.PANEL2, th.TEXT)
        return tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg, activebackground=th.LINE,
                         activeforeground=th.TEXT, relief="flat", bd=0, padx=10, pady=4, cursor="hand2",
                         font=(th.FONT, 10, "bold" if accent else "normal"), **kw)

    def clear(self):
        for f in (self.home_frame, self.edit_frame):
            if f is not None:
                f.destroy()
        self.home_frame = self.edit_frame = None
        self.viewport = None
        self.editors = {}
        self.config(menu=tk.Menu(self))

    def bg(self, fn, done):
        """Run fn() in a thread so the window doesn't freeze; done(result, error_text) runs on the main thread."""
        import threading
        box = {}

        def work():
            try:
                box["r"] = fn()
            except online.OnlineError as e:
                box["e"] = str(e)
            except Exception as e:  # noqa: BLE001
                box["e"] = f"Something went wrong: {e}"
        t = threading.Thread(target=work, daemon=True)
        t.start()

        def poll():
            if t.is_alive():
                self.after(80, poll)
                return
            try:
                done(box.get("r"), box.get("e"))
            except tk.TclError:
                pass
        self.after(80, poll)

    def change_server(self):
        text = simpledialog.askstring(TITLE, "Address of the Nexora server (for example https://nexora-xxxx.onrender.com).\n"
                                              "Leave empty for local accounts on this PC only.",
                                      initialvalue=online.server_url(), parent=self)
        if text is None:
            return
        try:
            online.set_server_url(text)
        except online.OnlineError as e:
            messagebox.showerror(TITLE, str(e))
            return
        self.net = online.Session(persist=False)
        self.show_login()

    # ================================================================ sign in
    def show_login(self, signup=False):
        """Studio needs a Nexora account: it decides who owns a game and who may publish it."""
        self.clear()
        self.proj = None
        self.user = None
        self.title(TITLE)
        f = self.home_frame = tk.Frame(self, bg=th.BG)
        f.pack(fill="both", expand=True)
        card = tk.Frame(f, bg=th.PANEL, padx=36, pady=30)
        card.place(relx=0.5, rely=0.45, anchor="center")
        try:
            self._logo = tk.PhotoImage(file=resource("assets/studio_120.png"))
            tk.Label(card, image=self._logo, bg=th.PANEL).pack(pady=(0, 8))
        except tk.TclError:
            pass
        tk.Label(card, text="Nexora Studio", bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 20, "bold")).pack()
        tk.Label(card, text="Create account to start building" if signup else "Sign in with your Nexora account",
                 bg=th.PANEL, fg=th.DIM, font=(th.FONT, 10)).pack(pady=(2, 14))
        vars_ = {}
        for key, label, show in (("u", "Username", ""), ("p", "Password", "•"), *((("p2", "Repeat password", "•"),) if signup else ())):
            tk.Label(card, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9), anchor="w").pack(fill="x")
            v = tk.StringVar()
            e = tk.Entry(card, textvariable=v, show=show, width=30, bg=th.PANEL2, fg=th.TEXT, insertbackground=th.TEXT,
                         relief="flat", font=(th.FONT, 11), highlightthickness=1, highlightbackground=th.LINE,
                         highlightcolor=th.ACCENT)
            e.pack(fill="x", ipady=4, pady=(0, 8))
            e.bind("<Return>", lambda ev: go())
            vars_[key] = v
            if key == "u":
                e.focus_set()
        msg = tk.Label(card, text="", bg=th.PANEL, fg=th.DANGER, font=(th.FONT, 9), wraplength=260, justify="left")
        msg.pack(fill="x")

        def go():
            u, p = vars_["u"].get().strip(), vars_["p"].get()
            if signup and p != vars_["p2"].get():
                msg.config(text="The passwords don't match.")
                return
            def finish(name):
                self.user = name
                self.show_home()
                if self.open_path:
                    path, self.open_path = self.open_path, None
                    self.open_saved(path)

            if online.enabled():
                msg.config(text="Contacting the server… (the first request can take a minute)", fg=th.DIM)
                fn = lambda: (self.net.register if signup else self.net.login)(u, p)  # noqa: E731

                def done(user, err):
                    if err:
                        msg.config(text=err, fg=th.DANGER)
                    else:
                        accounts.ensure_local(user["username"], user["avatar"], remember=False)
                        finish(user["username"])
                self.bg(fn, done)
                return
            res = (accounts.register if signup else accounts.login)(u, p, remember=False)
            if not res["ok"]:
                msg.config(text=res["error"])
                return
            finish(res["user"]["username"])

        self.btn(card, "Create account" if signup else "Sign in", go, accent=True).pack(fill="x", pady=(8, 6))
        tk.Button(card, text="I already have an account" if signup else "New here? Create an account",
                  command=lambda: self.show_login(not signup), bg=th.PANEL, fg=th.CYAN, activebackground=th.PANEL,
                  activeforeground=th.TEXT, relief="flat", bd=0, cursor="hand2", font=(th.FONT, 9)).pack()
        row = tk.Frame(card, bg=th.PANEL)
        row.pack(fill="x", pady=(12, 0))
        url = online.server_url()
        tk.Label(row, text=("Online: " + url.split("://", 1)[1]) if url else "Local accounts on this PC", bg=th.PANEL,
                 fg=th.DIM, font=(th.FONT, 8)).pack(side="left")
        if not online.server_locked():
            tk.Button(row, text="Server…", command=self.change_server, bg=th.PANEL, fg=th.CYAN, relief="flat", bd=0,
                      activebackground=th.PANEL, activeforeground=th.TEXT, cursor="hand2",
                      font=(th.FONT, 8)).pack(side="right")

    def sign_out(self):
        if self.ask_save():
            self.stop_test()
            self.show_login()

    # ================================================================ home screen
    def show_home(self):
        self.clear()
        self.proj = None
        discordrpc.set(details="Choosing a project", state="In Nexora Studio")
        self.title(TITLE)
        f = self.home_frame = tk.Frame(self, bg=th.BG)
        f.pack(fill="both", expand=True)
        head = tk.Frame(f, bg=th.BG)
        head.pack(fill="x", padx=40, pady=(34, 10))
        try:
            self._logo = tk.PhotoImage(file=resource("assets/studio_44.png"))
            tk.Label(head, image=self._logo, bg=th.BG).pack(side="left", padx=(0, 12))
        except tk.TclError:
            pass
        tk.Label(head, text="Nexora Studio", bg=th.BG, fg=th.TEXT, font=(th.FONT, 24, "bold")).pack(side="left")
        self.btn(head, "Sign out", self.sign_out).pack(side="right")
        tk.Label(head, text=f"Signed in as {self.user}", bg=th.BG, fg=th.DIM, font=(th.FONT, 10)).pack(side="right",
                                                                                                    padx=12)
        tk.Label(f, text="Build 3D games with parts and Python. Publish them to Nexora.", bg=th.BG, fg=th.DIM,
                 font=(th.FONT, 11)).pack(anchor="w", padx=40)
        bar = tk.Frame(f, bg=th.BG)
        bar.pack(fill="x", padx=40, pady=18)
        self.btn(bar, "＋  New game", self.new_game, accent=True).pack(side="left")
        self.btn(bar, "Open file…", self.open_file).pack(side="left", padx=8)
        tk.Label(f, text="YOUR GAMES", bg=th.BG, fg=th.DIM, font=(th.FONT, 9, "bold")).pack(anchor="w", padx=40)
        box = tk.Frame(f, bg=th.PANEL)
        box.pack(fill="both", expand=True, padx=40, pady=(6, 34))
        projects = [p for p in pj.list_projects() if not p["owner"] or pj.is_dev(p, self.user)]
        published = {g["id"] for g in pj.load_user_games()[0]}
        if not projects:
            tk.Label(box, text="No games yet. Press “New game” to start your first one.", bg=th.PANEL, fg=th.DIM,
                     font=(th.FONT, 12)).pack(pady=60)
        for p in projects:
            row = tk.Frame(box, bg=th.PANEL2)
            row.pack(fill="x", padx=10, pady=(10, 0))
            tk.Label(row, text=p["name"], bg=th.PANEL2, fg=th.TEXT, font=(th.FONT, 12, "bold")).pack(side="left", padx=12,
                                                                                                     pady=10)
            when = time.strftime("%b %d, %H:%M", time.localtime(p["modified"]))
            role = "" if p["owner"].lower() == self.user.lower() or not p["owner"] else f"  ·  by {p['owner']} (you're a developer)"
            tag = role + ("  ·  published" if p["id"] in published else "")
            tk.Label(row, text=f"{p['parts']} parts  ·  edited {when}{tag}", bg=th.PANEL2, fg=th.DIM,
                     font=(th.FONT, 10)).pack(side="left")
            self.btn(row, "Delete", lambda p=p: self.delete_saved(p)).pack(side="right", padx=8)
            self.btn(row, "Open", lambda p=p: self.open_saved(p["path"]), accent=True).pack(side="right")

    def new_game(self):
        name = simpledialog.askstring(TITLE, "Name your game:", parent=self)
        if name is None:
            return
        try:
            self.open_project(pj.Project.new(name.strip() or "My first game", owner=self.user))
        except ValueError as e:
            messagebox.showerror(TITLE, str(e))

    def open_saved(self, path):
        try:
            self.open_project(pj.Project.load(path))
        except (OSError, ValueError) as e:
            messagebox.showerror(TITLE, f"Couldn't open that game.\n\n{e}")

    def open_file(self):
        path = filedialog.askopenfilename(parent=self, title="Open a Nexora game", initialdir=str(pj.projects_dir()),
                                          filetypes=[("Nexora game", "*.json"), ("All files", "*.*")])
        if path:
            self.open_saved(path)

    def delete_saved(self, p):
        if p["owner"] and p["owner"].lower() != self.user.lower():
            messagebox.showinfo(TITLE, f"Only the owner ({p['owner']}) can delete this game.", parent=self)
            return
        if messagebox.askyesno(TITLE, f"Delete “{p['name']}” from this PC?\nThis can't be undone. "
                                      "(If it's published, it stays in Nexora until you unpublish it.)", parent=self):
            pj.delete_project(p["path"])
            self.show_home()

    # ================================================================ editor layout
    def open_project(self, proj):
        d = proj.data
        if not d["owner"]:  # an older game with no owner: the first signed-in person to open it claims it
            d["owner"] = d["author"] = self.user
            proj.saved_snapshot = proj._snap()
        elif not pj.is_dev(d, self.user):
            messagebox.showerror(TITLE, f"“{d['name']}” belongs to {d['owner']}.\n\nAsk {d['owner']} to add you as a "
                                        "developer (Game settings → Developers) and you'll be able to open it.")
            return
        self.clear()
        self.proj = proj
        discordrpc.set(details=f"Editing {d['name']}"[:100], state="In Nexora Studio")
        self.build_menu()
        f = self.edit_frame = tk.Frame(self, bg=th.BG)
        f.pack(fill="both", expand=True)
        self.build_toolbar(f)
        self.status = tk.Label(f, text="", bg=th.PANEL, fg=th.DIM, anchor="w", font=(th.FONT, 9), padx=10)
        self.status.pack(side="bottom", fill="x")
        outer = tk.PanedWindow(f, orient="vertical", bg=th.BG, sashwidth=5, bd=0)
        outer.pack(fill="both", expand=True)
        top = tk.PanedWindow(outer, orient="horizontal", bg=th.BG, sashwidth=5, bd=0)
        outer.add(top, stretch="always")
        self.build_explorer(top)
        self.notebook = ttk.Notebook(top)
        top.add(self.notebook, stretch="always", minsize=400)
        vf = tk.Frame(self.notebook, bg=th.BG)
        self.notebook.add(vf, text="  3D View  ")
        self.viewport = vp.Viewport(vf, proj, on_select=self.on_viewport_select, on_change=self.refresh_props_values,
                                    on_commit=self.after_edit, on_status=self.set_status, on_delete=self.delete_selected)
        self.viewport.canvas.pack(fill="both", expand=True)
        self.prefs = studio_prefs.load()
        self.viewport.apply_prefs(self.prefs)
        self.snap_var.set(self.prefs["snap"])
        self.settings_tab = None
        self.autosave_job = None
        self.schedule_autosave()
        self.build_props(top)
        self.build_output(outer)
        self.notebook.bind("<<NotebookTabChanged>>", lambda e: self.update_title())
        self.bind_keys()
        self.refresh_all()
        self.set_status("Left-drag to select and move. Right-drag orbits, Shift+right-drag pans, wheel zooms, F focuses.")
        self.after(100, self.viewport.request_redraw)

    def build_menu(self):
        m = tk.Menu(self)
        mk = lambda label, items: self._menu(m, label, items)  # noqa: E731
        mk("File", [("New game…", self.new_game, ""), ("Open…", self.open_file, "Ctrl+O"), None,
                    ("Save", self.save, "Ctrl+S"), ("Save as…", self.save_as, ""), None,
                    ("Publish to Nexora", self.publish, "Ctrl+P"), ("Unpublish", self.unpublish, ""), None,
                    ("Close game (Home)", self.close_game, ""), ("Exit", self.on_close, "")])
        mk("Edit", [("Undo", self.undo, "Ctrl+Z"), ("Redo", self.redo, "Ctrl+Y"), None,
                    ("Duplicate", self.duplicate_selected, "Ctrl+D"), ("Delete", self.delete_selected, "Del"), None,
                    ("Game settings…", lambda: self.select_part(None), ""),
                    ("Studio settings…", self.open_settings, "")])
        mk("Insert", [("Part", lambda: self.insert("part"), ""), ("Sphere", lambda: self.insert("part", shape="sphere"), ""),
                      ("Cylinder", lambda: self.insert("part", shape="cylinder"), ""),
                      ("Cone", lambda: self.insert("part", shape="cone"), ""),
                      ("Wedge (ramp)", lambda: self.insert("part", shape="wedge"), ""),
                      ("Coin", lambda: self.insert("coin"), ""), ("Spawn", lambda: self.insert("spawn"), ""),
                      ("Goal pad", lambda: self.insert("goal"), ""), None,
                      ("Script (game)", lambda: self.insert_script(None), ""),
                      ("Script (on selected part)", lambda: self.insert_script(self.selected_id()), "")])
        mk("Test", [("Play Test", self.play_test, "F5"), ("Stop", self.stop_test, "Shift+F5"), None,
                    ("Check all scripts", self.check_all, "")])
        mk("Help", [("Scripting guide", self.show_guide, "F1"), ("About", lambda: messagebox.showinfo(
            TITLE, f"Nexora Studio {VERSION}\nBuild games with parts and Python.\n\nScripts are guarded, not sandboxed: "
                   "only run games from people you trust."), "")])
        self.config(menu=m)

    def _menu(self, bar, label, items):
        sub = tk.Menu(bar, tearoff=0)
        for it in items:
            if it is None:
                sub.add_separator()
            else:
                sub.add_command(label=it[0], command=it[1], accelerator=it[2])
        bar.add_cascade(label=label, menu=sub)

    def build_toolbar(self, parent):
        bar = tk.Frame(parent, bg=th.PANEL)
        bar.pack(fill="x")
        self.tool_var = tk.StringVar(value="select")
        for key, label in (("select", "Select"), ("move", "Move"), ("scale", "Scale"), ("rotate", "Rotate")):
            tk.Radiobutton(bar, text=label, value=key, variable=self.tool_var, indicatoron=False, bg=th.PANEL2,
                           fg=th.TEXT, selectcolor=th.ACCENT, activebackground=th.LINE, activeforeground=th.TEXT,
                           relief="flat", bd=0, padx=12, pady=5, font=(th.FONT, 10), cursor="hand2",
                           command=lambda: self.viewport.set_tool(self.tool_var.get())).pack(side="left", padx=(6, 0),
                                                                                              pady=6)
        tk.Label(bar, text="Snap", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).pack(side="left", padx=(16, 4))
        self.snap_var = tk.StringVar(value="1")
        om = tk.OptionMenu(bar, self.snap_var, "Off", "0.25", "0.5", "1", "2", "5",
                           command=lambda v: self.viewport.set_snap(0 if v == "Off" else float(v)))
        om.configure(bg=th.PANEL2, fg=th.TEXT, activebackground=th.LINE, activeforeground=th.TEXT, relief="flat",
                     bd=0, highlightthickness=0, font=(th.FONT, 10))
        om["menu"].configure(bg=th.PANEL2, fg=th.TEXT)
        om.pack(side="left")
        tk.Frame(bar, bg=th.LINE, width=1).pack(side="left", fill="y", padx=12, pady=8)
        for label, kind, extra in (("＋ Part", "part", {}), ("＋ Sphere", "part", {"shape": "sphere"}),
                                   ("＋ Cylinder", "part", {"shape": "cylinder"}), ("＋ Cone", "part", {"shape": "cone"}),
                                   ("＋ Wedge", "part", {"shape": "wedge"}),
                                   ("＋ Coin", "coin", {}), ("＋ Spawn", "spawn", {}), ("＋ Goal", "goal", {})):
            self.btn(bar, label, lambda k=kind, e=extra: self.insert(k, **e)).pack(side="left", padx=(0, 4), pady=6)
        self.btn(bar, "⚙ Settings", self.open_settings).pack(side="right", padx=(0, 6))
        self.btn(bar, "Publish", self.publish).pack(side="right", padx=6)
        self.btn(bar, "■ Stop", self.stop_test).pack(side="right", padx=(0, 4))
        self.btn(bar, "▶ Play Test", self.play_test, accent=True).pack(side="right", padx=4)

    def build_explorer(self, top):
        f = tk.Frame(top, bg=th.PANEL, width=240)
        top.add(f, minsize=170)
        tk.Label(f, text="EXPLORER", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9, "bold"), anchor="w").pack(fill="x", padx=10,
                                                                                                          pady=(8, 4))
        self.tree = ttk.Treeview(f, show="tree", selectmode="browse")
        sb = tk.Scrollbar(f, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True, padx=(6, 0), pady=(0, 6))
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        self.tree.bind("<Double-1>", self.on_tree_double)
        self.tree.bind("<Button-3>", self.on_tree_menu)
        self.tree.bind("<Delete>", lambda e: self.delete_selected())

    def build_props(self, top):
        f = tk.Frame(top, bg=th.PANEL, width=270)
        top.add(f, minsize=220)
        tk.Label(f, text="PROPERTIES", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9, "bold"), anchor="w").pack(fill="x", padx=10,
                                                                                                           pady=(8, 4))
        self.props = tk.Frame(f, bg=th.PANEL)
        self.props.pack(fill="both", expand=True, padx=10)
        self.fields = {}

    def build_output(self, outer):
        f = tk.Frame(outer, bg=th.PANEL, height=150)
        outer.add(f, minsize=70)
        head = tk.Frame(f, bg=th.PANEL)
        head.pack(fill="x")
        tk.Label(head, text="OUTPUT", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9, "bold")).pack(side="left", padx=10, pady=4)
        self.btn(head, "Clear", lambda: self.out.delete("1.0", "end")).pack(side="right", padx=6, pady=2)
        self.out = tk.Text(f, height=7, bg=th.BG, fg=th.TEXT, relief="flat", font=("Consolas", 10), wrap="word",
                           highlightthickness=0, padx=8, pady=4)
        sb = tk.Scrollbar(f, command=self.out.yview)
        self.out.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.out.pack(fill="both", expand=True)
        self.out.tag_configure("err", foreground=th.DANGER)
        self.out.tag_configure("ok", foreground="#4ade80")
        self.out.tag_configure("dim", foreground=th.DIM)

    def bind_keys(self):
        for seq, fn in (("<Control-s>", self.save), ("<Control-o>", self.open_file), ("<Control-p>", self.publish),
                        ("<Control-d>", self.duplicate_selected), ("<F5>", self.play_test),
                        ("<Shift-F5>", self.stop_test), ("<F1>", self.show_guide)):
            self.bind(seq, lambda e, fn=fn: (fn(), "break")[1])
        self.bind("<Control-z>", lambda e: self.key_undo())
        self.bind("<Control-y>", lambda e: self.key_redo())

    # ================================================================ output / status
    # ================================================================ Studio settings (a tab, not a window)
    def open_settings(self):
        tab = getattr(self, "settings_tab", None)
        if tab is None or not tab.winfo_exists():
            tab = self.settings_tab = tk.Frame(self.notebook, bg=th.BG)
            self.notebook.add(tab, text="  ⚙ Settings  ")
            self.build_settings(tab)
        self.notebook.select(tab)

    def build_settings(self, tab):
        for w in tab.winfo_children():
            w.destroy()
        inner = tk.Frame(tab, bg=th.BG)
        inner.pack(anchor="nw", padx=24, pady=18)
        tk.Label(inner, text="Studio settings", bg=th.BG, fg=th.TEXT, font=(th.FONT, 16, "bold")).pack(anchor="w")
        tk.Label(inner, text="How the editor behaves. They're saved on this PC and apply to every game you open. "
                             "(A game's own world settings are in Edit > Game settings.)", bg=th.BG, fg=th.DIM,
                 font=(th.FONT, 9), wraplength=520, justify="left").pack(anchor="w", pady=(2, 12))
        vars_ = {}

        def save(*_):
            prefs = {}
            for k, v in vars_.items():
                try:
                    prefs[k] = v.get()
                except tk.TclError:
                    return
            self.prefs = studio_prefs.clean(prefs)
            studio_prefs.save(self.prefs)
            self.viewport.apply_prefs(self.prefs)
            self.snap_var.set(self.prefs["snap"])
            self.schedule_autosave()

        def section(text):
            tk.Label(inner, text=text, bg=th.BG, fg=th.ACCENT, font=(th.FONT, 10, "bold")).pack(anchor="w", pady=(12, 2))

        def slider(key, label, lo, hi, unit):
            row = tk.Frame(inner, bg=th.BG)
            row.pack(anchor="w", pady=2)
            tk.Label(row, text=label, bg=th.BG, fg=th.TEXT, font=(th.FONT, 10), width=24, anchor="w").pack(side="left")
            var = tk.IntVar(value=self.prefs[key])
            vars_[key] = var
            tk.Scale(row, from_=lo, to=hi, orient="horizontal", variable=var, length=240, showvalue=True,
                     bg=th.BG, fg=th.TEXT, troughcolor=th.PANEL, highlightthickness=0, bd=0,
                     command=lambda _v: save()).pack(side="left")
            tk.Label(row, text=unit, bg=th.BG, fg=th.DIM, font=(th.FONT, 9)).pack(side="left", padx=4)

        def check(key, label):
            var = tk.BooleanVar(value=self.prefs[key])
            vars_[key] = var
            tk.Checkbutton(inner, text=label, variable=var, bg=th.BG, fg=th.TEXT, selectcolor=th.PANEL2,
                           activebackground=th.BG, activeforeground=th.TEXT, font=(th.FONT, 10),
                           command=save).pack(anchor="w", pady=1)

        section("3D view")
        slider("fov", "Field of view", *studio_prefs.LIMITS["fov"], "degrees")
        slider("orbit_speed", "Orbit speed (right-drag)", *studio_prefs.LIMITS["orbit_speed"], "%")
        slider("zoom_speed", "Zoom speed (wheel)", *studio_prefs.LIMITS["zoom_speed"], "%")
        slider("fly_speed", "Fly speed (W A S D Q E)", *studio_prefs.LIMITS["fly_speed"], "%")
        check("invert_orbit", "Invert vertical orbit")
        section("Grid and snapping")
        check("show_grid", "Show the ground grid")
        slider("grid_step", "Grid spacing", *studio_prefs.LIMITS["grid_step"], "units")
        row = tk.Frame(inner, bg=th.BG)
        row.pack(anchor="w", pady=2)
        tk.Label(row, text="Snap to", bg=th.BG, fg=th.TEXT, font=(th.FONT, 10), width=24, anchor="w").pack(side="left")
        sv = tk.StringVar(value=self.prefs["snap"])
        vars_["snap"] = sv
        om = tk.OptionMenu(row, sv, *studio_prefs.SNAPS, command=lambda v: save())
        om.configure(bg=th.PANEL2, fg=th.TEXT, activebackground=th.LINE, activeforeground=th.TEXT, relief="flat",
                     bd=0, highlightthickness=0, font=(th.FONT, 10))
        om["menu"].configure(bg=th.PANEL2, fg=th.TEXT)
        om.pack(side="left")
        section("Saving")
        slider("autosave", "Autosave every (0 = off)", *studio_prefs.LIMITS["autosave"], "minutes")
        tk.Label(inner, text="Autosave only saves games that already have a file (use File > Save once first).",
                 bg=th.BG, fg=th.DIM, font=(th.FONT, 9)).pack(anchor="w")
        self.btn(inner, "Reset to defaults", lambda: (studio_prefs.save(dict(studio_prefs.DEFAULTS)),
                                                      setattr(self, "prefs", studio_prefs.load()),
                                                      self.viewport.apply_prefs(self.prefs),
                                                      self.snap_var.set(self.prefs["snap"]), self.schedule_autosave(),
                                                      self.build_settings(tab))).pack(anchor="w", pady=(16, 0))

    def schedule_autosave(self):
        job = getattr(self, "autosave_job", None)
        if job:
            try:
                self.after_cancel(job)
            except tk.TclError:
                pass
        self.autosave_job = None
        mins = getattr(self, "prefs", {}).get("autosave", 0)
        if mins:
            self.autosave_job = self.after(mins * 60_000, self.autosave_tick)

    def autosave_tick(self):
        self.autosave_job = None
        try:
            if self.proj and self.proj.path and self.proj.dirty:
                self.proj.save()
                self.update_title()
                self.set_status("Autosaved.")
        except Exception as e:  # noqa: BLE001 - never let autosave break editing
            self.set_status(f"Autosave failed: {e}")
        self.schedule_autosave()

    def set_status(self, text):
        if getattr(self, "status", None) is not None and self.status.winfo_exists():
            self.status.config(text=text)

    def log(self, text, tag=None):
        self.out.insert("end", text + "\n", tag or ())
        self.out.see("end")

    def update_title(self):
        if self.proj:
            self.title(f"{self.proj.data['name']}{' *' if self.proj.dirty else ''} - {TITLE}")

    # ================================================================ selection / explorer
    def selected_id(self):
        return self.viewport.selected if self.viewport else None

    def refresh_all(self):
        """Rebuild explorer, properties and 3D view from the project (after undo, load, delete...)."""
        sel = self.selected_id()
        if sel and not self.proj.part(sel):
            self.viewport.selected = sel = None
        self.rebuild_tree()
        self.build_prop_fields()
        self.sync_editors()
        self.viewport.request_redraw()
        self.update_title()

    def rebuild_tree(self):
        t = self.tree
        t.unbind("<<TreeviewSelect>>")
        t.delete(*t.get_children())
        d = self.proj.data
        t.insert("", "end", "game", text=f"🎮  {d['name']}", open=True)
        t.insert("game", "end", "parts", text="Workspace", open=True)
        for p in self.proj.parts:
            t.insert("parts", "end", f"part:{p['id']}", text=f"{KIND_ICON[p['kind']]}  {p['name']}", open=True)
        for s in self.proj.scripts:
            parent = f"part:{s['target']}" if s["target"] else "game"
            t.insert(parent, "end", f"script:{s['id']}", text=f"📜  {s['name']}")
        sel = self.selected_id()
        if sel and t.exists(f"part:{sel}"):
            t.selection_set(f"part:{sel}")
            t.see(f"part:{sel}")
        t.bind("<<TreeviewSelect>>", self.on_tree_select)

    def on_tree_select(self, _e=None):
        s = self.tree.selection()
        if not s:
            return
        kind, _, ident = s[0].partition(":")
        if kind == "part":
            self.viewport.set_selected(ident)
            self.build_prop_fields()
        elif kind in ("game", "parts"):
            self.viewport.set_selected(None)
            self.build_prop_fields()

    def on_tree_double(self, _e=None):
        s = self.tree.selection()
        if s and s[0].startswith("script:"):
            self.open_script(s[0].split(":", 1)[1])
        elif s and s[0].startswith("part:"):
            self.viewport.focus_selection()

    def on_viewport_select(self, pid):
        self.rebuild_tree()
        self.build_prop_fields()

    def select_part(self, pid):
        self.viewport.set_selected(pid)
        self.rebuild_tree()
        self.build_prop_fields()

    def on_tree_menu(self, e):
        iid = self.tree.identify_row(e.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        kind, _, ident = iid.partition(":")
        m = tk.Menu(self, tearoff=0)
        if kind == "part":
            m.add_command(label="Add script to this part", command=lambda: self.insert_script(ident))
            m.add_command(label="Duplicate", command=self.duplicate_selected)
            m.add_command(label="Rename…", command=lambda: self.rename("part", ident))
            m.add_command(label="Delete", command=self.delete_selected)
        elif kind == "script":
            m.add_command(label="Open", command=lambda: self.open_script(ident))
            m.add_command(label="Rename…", command=lambda: self.rename("script", ident))
            m.add_command(label="Delete", command=lambda: self.delete_script(ident))
        else:
            m.add_command(label="Add game script", command=lambda: self.insert_script(None))
        m.tk_popup(e.x_root, e.y_root)

    def rename(self, what, ident):
        rec = self.proj.part(ident) if what == "part" else self.proj.script(ident)
        if not rec:
            return
        name = simpledialog.askstring(TITLE, "New name:", initialvalue=rec["name"], parent=self)
        if not name:
            return
        try:
            if what == "part":
                self.proj.update_part(ident, name=name.strip())
            else:
                rec["name"] = pj._text(name.strip(), "name", "Script")
        except ValueError as e:
            messagebox.showerror(TITLE, str(e))
            return
        self.after_edit()
        self.refresh_all()

    # ================================================================ edits
    def after_edit(self):
        self.proj.commit()
        self.update_title()
        self.refresh_props_values()
        self.rebuild_tree()

    def insert(self, kind, **over):
        try:
            rec = self.proj.add_part(kind, pos=self.viewport.spawn_point(), **over)
        except ValueError as e:
            messagebox.showerror(TITLE, str(e))
            return
        self.proj.commit()
        self.viewport.set_selected(rec["id"])
        self.refresh_all()
        self.set_status(f"Added {rec['name']}. Drag it, or use the Properties panel.")

    def duplicate_selected(self):
        sel = self.selected_id()
        if not sel:
            return
        try:
            rec = self.proj.duplicate_part(sel)
        except ValueError as e:
            messagebox.showerror(TITLE, str(e))
            return
        self.proj.commit()
        self.viewport.set_selected(rec["id"])
        self.refresh_all()

    def delete_selected(self):
        sel = self.selected_id()
        if not sel:
            return
        rec = self.proj.part(sel)
        n = len([s for s in self.proj.scripts if s["target"] == sel])
        if n and not messagebox.askyesno(TITLE, f"“{rec['name']}” has {n} script(s). Delete them too?", parent=self):
            return
        self.proj.remove_part(sel)
        self.proj.commit()
        self.viewport.selected = None
        self.refresh_all()

    def insert_script(self, target):
        try:
            rec = self.proj.add_script("Script", target)
        except ValueError as e:
            messagebox.showerror(TITLE, str(e))
            return
        self.proj.commit()
        self.rebuild_tree()
        self.open_script(rec["id"])
        self.update_title()

    def delete_script(self, sid):
        s = self.proj.script(sid)
        if s and messagebox.askyesno(TITLE, f"Delete the script “{s['name']}”?", parent=self):
            self.proj.remove_script(sid)
            self.proj.commit()
            self.refresh_all()

    # ---- undo / redo
    def undo(self):
        if self.proj.undo():
            self.refresh_all()
        else:
            self.set_status("Nothing to undo.")

    def redo(self):
        if self.proj.redo():
            self.refresh_all()
        else:
            self.set_status("Nothing to redo.")

    def _in_editor(self):
        w = self.focus_get()
        return isinstance(w, tk.Text) and w is not self.out

    def key_undo(self):
        if self._in_editor():
            return None  # the code editor has its own undo
        self.undo()
        return "break"

    def key_redo(self):
        if self._in_editor():
            return None
        self.redo()
        return "break"

    # ================================================================ properties panel
    def build_prop_fields(self):
        for w in self.props.winfo_children():
            w.destroy()
        self.fields = {}
        sel = self.selected_id()
        rec = self.proj.part(sel) if sel else None
        if rec:
            self._head(f"{KIND_ICON[rec['kind']]}  {rec['name']}  ({rec['kind']})")
            self._entry("name", "Name", rec["name"])
            if rec["kind"] != "coin":
                self._choice("shape", "Shape", rec["shape"], pj.SHAPES)
            for i, ax in enumerate("xyz"):
                self._entry(f"pos{i}", f"Position {ax.upper()}", fmt(rec["pos"][i]))
            for i, ax in enumerate("xyz"):
                self._entry(f"size{i}", f"Size {ax.upper()}", fmt(rec["size"][i]))
            self._entry("rot_y", "Rotation (°)", fmt(rec["rot_y"]))
            self._color("color", "Color", rec["color"])
            if rec["kind"] == "coin":
                self._entry("value", "Coin value", str(rec.get("value", 1)))
            self._check("collide", "Solid (player can stand on it)", rec["collide"])
            self._check("visible", "Visible", rec["visible"])
            self.btn(self.props, "Add script to this part", lambda: self.insert_script(rec["id"])).pack(fill="x", pady=(10, 0))
        else:
            d = self.proj.data
            self._head("🎮  Game settings")
            self._entry("g_name", "Name", d["name"])
            self._entry("g_desc", "Description", d["desc"])
            self._entry("g_emoji", "Icon (emoji)", d["emoji"])
            self._static("Creator", d["owner"])
            if d["owner"].lower() == self.user.lower():
                self._entry("g_devs", "Developers", ", ".join(d["devs"]))
                tk.Label(self.props, text="Usernames separated by commas. Developers can edit and publish.",
                         bg=th.PANEL, fg=th.DIM, font=(th.FONT, 8), wraplength=240, justify="left").pack(anchor="w")
            else:
                self._static("Developers", ", ".join(d["devs"]) or "none")
            self._color("g_sky", "Sky color", d["sky"])
            self._color("g_thumb", "Card color", d["thumb"])
            self._entry("g_kill_y", "Void height (Y)", fmt(d["kill_y"]))
            w = d["world"]
            self._head2("World")
            self._entry("w_fog", "Fog (0 - 1)", fmt(w["fog"]))
            self._color("w_fog_color", "Fog color", w["fog_color"] or d["sky"])
            self._entry("w_gravity", "Gravity (x)", fmt(w["gravity"]))
            self._entry("w_walk_speed", "Walk speed", fmt(w["walk_speed"]))
            self._entry("w_jump_height", "Jump height", fmt(w["jump_height"]))
            r = self._row("Thumbnails")
            tk.Label(r, text=f"{len(d['thumbs'])} of {pj.MAX_THUMBS}", bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 10)).pack(side="left")
            self.btn(r, "Clear", self.clear_thumbnails).pack(side="right")
            self.btn(self.props, "Add thumbnail from 3D view", self.add_thumbnail).pack(fill="x", pady=(4, 0))
            self.btn(self.props, "◈ Gamepasses (Nexei)...", self.manage_passes).pack(fill="x", pady=(4, 0))
            tk.Label(self.props, text=f"{len(self.proj.parts)} parts · {len(self.proj.scripts)} scripts", bg=th.PANEL,
                     fg=th.DIM, font=(th.FONT, 9)).pack(anchor="w", pady=(10, 0))

    def _head(self, text):
        tk.Label(self.props, text=text, bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11, "bold"), anchor="w").pack(fill="x",
                                                                                                            pady=(0, 8))

    def _head2(self, text):
        tk.Label(self.props, text=text, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9, "bold"), anchor="w").pack(
            fill="x", pady=(10, 2))

    def _row(self, label):
        r = tk.Frame(self.props, bg=th.PANEL)
        r.pack(fill="x", pady=2)
        tk.Label(r, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9), width=13, anchor="w").pack(side="left")
        return r

    def _static(self, label, value):
        r = self._row(label)
        tk.Label(r, text=value, bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 10), anchor="w").pack(side="left")

    def _entry(self, key, label, value):
        r = self._row(label)
        var = tk.StringVar(value=value)
        e = tk.Entry(r, textvariable=var, bg=th.PANEL2, fg=th.TEXT, insertbackground=th.TEXT, relief="flat",
                     font=(th.FONT, 10), highlightthickness=1, highlightbackground=th.LINE, highlightcolor=th.ACCENT)
        e.pack(side="left", fill="x", expand=True, ipady=3)
        e.bind("<Return>", lambda ev: self.apply_field(key))
        e.bind("<FocusOut>", lambda ev: self.apply_field(key))
        self.fields[key] = var

    def _choice(self, key, label, value, options):
        r = self._row(label)
        var = tk.StringVar(value=value)
        om = tk.OptionMenu(r, var, *options, command=lambda v: self.apply_field(key))
        om.configure(bg=th.PANEL2, fg=th.TEXT, activebackground=th.LINE, activeforeground=th.TEXT, relief="flat", bd=0,
                     highlightthickness=0, font=(th.FONT, 10), anchor="w")
        om["menu"].configure(bg=th.PANEL2, fg=th.TEXT)
        om.pack(side="left", fill="x", expand=True)
        self.fields[key] = var

    def _check(self, key, label, value):
        var = tk.BooleanVar(value=value)
        tk.Checkbutton(self.props, text=label, variable=var, bg=th.PANEL, fg=th.TEXT, selectcolor=th.PANEL2,
                       activebackground=th.PANEL, activeforeground=th.TEXT, font=(th.FONT, 10),
                       command=lambda: self.apply_field(key)).pack(anchor="w", pady=1)
        self.fields[key] = var

    def _color(self, key, label, value):
        r = self._row(label)
        var = tk.StringVar(value=value)
        sw = tk.Label(r, bg=value, width=3, relief="flat", cursor="hand2")
        sw.pack(side="left", padx=(0, 6), ipady=3)
        e = tk.Entry(r, textvariable=var, bg=th.PANEL2, fg=th.TEXT, insertbackground=th.TEXT, relief="flat",
                     font=(th.FONT, 10), width=9, highlightthickness=1, highlightbackground=th.LINE,
                     highlightcolor=th.ACCENT)
        e.pack(side="left", ipady=3)
        e.bind("<Return>", lambda ev: self.apply_field(key))
        e.bind("<FocusOut>", lambda ev: self.apply_field(key))

        def pick(_e=None):
            c = colorchooser.askcolor(color=var.get(), parent=self)[1]
            if c:
                var.set(c)
                self.apply_field(key)
        sw.bind("<Button-1>", pick)
        var.swatch = sw
        self.fields[key] = var

    def refresh_props_values(self):
        """Update the numbers while dragging in the 3D view, without rebuilding the panel."""
        sel = self.selected_id()
        rec = self.proj.part(sel) if sel else None
        if not rec or not self.fields or "pos0" not in self.fields:
            return
        self.props_busy = True
        try:
            for i in range(3):
                self.fields[f"pos{i}"].set(fmt(rec["pos"][i]))
                self.fields[f"size{i}"].set(fmt(rec["size"][i]))
            self.fields["rot_y"].set(fmt(rec["rot_y"]))
        finally:
            self.props_busy = False
        self.update_title()

    def apply_field(self, key):
        if self.props_busy or not self.fields or key not in self.fields:
            return
        try:
            self._apply(key)
        except ValueError as e:
            self.set_status(f"Not changed: {e}")
            bell = getattr(self, "bell", None)
            if bell:
                bell()
            self.build_prop_fields()
            return
        self.after_edit()
        self.viewport.request_redraw()

    def _apply(self, key):
        f, p = self.fields, self.proj
        if key == "g_devs":
            if p.data["owner"].lower() != self.user.lower():
                raise ValueError("Only the owner can change developers.")
            names = []
            for raw in f[key].get().replace(";", ",").split(","):
                raw = raw.strip()
                if not raw:
                    continue
                real = self.net.account_exists(raw) if online.enabled() else accounts.canonical_name(raw)
                if not real:
                    raise ValueError(f"There's no Nexora account called “{raw}”.")
                names.append(real)
            p.data["devs"] = pj.clean_project(dict(p.data, devs=names))["devs"]
            f[key].set(", ".join(p.data["devs"]))
            return
        if key.startswith("w_"):
            name = key[2:]
            raw = f[key].get().strip()
            w = dict(p.data["world"])
            if name == "fog_color":
                w["fog_color"] = raw.lower() if raw else None
            elif not _isnum(raw):
                raise ValueError(f"{name.replace('_', ' ').capitalize()} must be a number.")
            else:
                w[name] = float(raw)
            p.data["world"] = pj.clean_world(w)   # numbers outside the allowed range are clamped to it
            if name == "fog_color":
                f[key].set(p.data["world"]["fog_color"] or p.data["sky"])
                if hasattr(f[key], "swatch"):
                    f[key].swatch.config(bg=f[key].get())
            else:
                f[key].set(fmt(p.data["world"][name]))
            return
        if key.startswith("g_"):
            d = p.data
            new = dict(d)
            name = key[2:]
            val = f[key].get().strip()
            new[name] = float(val) if name == "kill_y" else val
            if name == "kill_y" and not _isnum(f[key].get()):
                raise ValueError("Respawn height must be a number.")
            cleaned = pj.clean_project(new)
            d.update({k: cleaned[k] for k in ("name", "desc", "emoji", "sky", "thumb", "kill_y")})
            f[key].set(fmt(d[name]) if name == "kill_y" else d[name])
            if name in ("sky", "thumb") and hasattr(f[key], "swatch"):
                f[key].swatch.config(bg=d[name])
            return
        sel = self.selected_id()
        rec = p.part(sel)
        if not rec:
            return
        if key.startswith("pos") or key.startswith("size"):
            base = "pos" if key.startswith("pos") else "size"
            vec = []
            for i in range(3):
                txt = f[f"{base}{i}"].get()
                if not _isnum(txt):
                    raise ValueError(f"{base.capitalize()} must be numbers.")
                vec.append(float(txt))
            if base == "size" and min(vec) < 0.05:
                raise ValueError("Sizes must be at least 0.05.")
            p.update_part(sel, **{base: vec})
        elif key == "rot_y":
            if not _isnum(f[key].get()):
                raise ValueError("Rotation must be a number.")
            p.update_part(sel, rot_y=float(f[key].get()))
        elif key == "value":
            if not _isnum(f[key].get()):
                raise ValueError("Coin value must be a whole number.")
            p.update_part(sel, value=int(float(f[key].get())))
        elif key in ("collide", "visible"):
            p.update_part(sel, **{key: bool(f[key].get())})
        else:
            p.update_part(sel, **{key: f[key].get().strip()})
        rec = p.part(sel)
        if key == "color" and hasattr(f[key], "swatch"):
            f[key].swatch.config(bg=rec["color"])

    # ================================================================ scripts
    def open_script(self, sid):
        s = self.proj.script(sid)
        if not s:
            return
        if sid not in self.editors:
            ed = ScriptEditor(self.notebook, s["source"], on_edit=lambda text, sid=sid: self.script_edited(sid, text))
            self.editors[sid] = ed
            self.notebook.add(ed, text=f"  📜 {s['name']}  ")
        self.notebook.select(self.editors[sid])
        self.editors[sid].text.focus_set()
        self.update_tab_names()

    def update_tab_names(self):
        for sid, ed in self.editors.items():
            s = self.proj.script(sid)
            if s:
                self.notebook.tab(ed, text=f"  📜 {s['name']}  ")

    def script_edited(self, sid, text):
        s = self.proj.script(sid)
        if not s:
            return
        s["source"] = text[:60_000]
        self.proj.commit()
        self.update_title()

    def sync_editors(self):
        """After undo/redo/delete: drop tabs for scripts that are gone, reload the rest."""
        for sid in list(self.editors):
            ed = self.editors[sid]
            s = self.proj.script(sid)
            if not s:
                self.notebook.forget(ed)
                ed.destroy()
                del self.editors[sid]
            elif ed.get() != s["source"]:
                ed.set(s["source"])
        self.update_tab_names()

    def check_script(self, s) -> list:
        return scripting.check_source(s["source"])

    def check_all(self) -> bool:
        ok = True
        for s in self.proj.scripts:
            errs = self.check_script(s)
            where = f"on {self.proj.part(s['target'])['name']}" if s["target"] else "game"
            if errs:
                ok = False
                for line, msg in errs:
                    self.log(f"✖ {s['name']} ({where}) line {line}: {msg}", "err")
                if s["id"] in self.editors or errs:
                    self.open_script(s["id"])
                    self.editors[s["id"]].mark_errors([ln for ln, _ in errs])
            else:
                if s["id"] in self.editors:
                    self.editors[s["id"]].mark_errors([])
        if ok:
            self.log(f"✔ {len(self.proj.scripts)} script(s) checked, no problems found.", "ok")
        return ok

    def show_guide(self):
        w = tk.Toplevel(self)
        w.title("Nexora Studio - scripting guide")
        w.geometry("760x640")
        w.configure(bg=th.BG)
        t = tk.Text(w, bg=th.BG, fg=th.TEXT, font=("Consolas", 11), wrap="word", relief="flat", padx=16, pady=12)
        t.insert("1.0", GUIDE)
        t.config(state="disabled")
        t.pack(fill="both", expand=True)

    # ================================================================ play test
    def play_test(self):
        if self.proc and self.proc.poll() is None:
            self.log("A test is already running. Press Stop first.", "dim")
            return
        self.out.delete("1.0", "end")
        if not self.check_all():
            self.log("Fix the marked problems, then press Play Test again.", "err")
            return
        try:
            spawn = any(p["kind"] == "spawn" for p in self.proj.parts)
            path = Path(tempfile.gettempdir()) / "nexora-studio-playtest.json"
            pj._write_json(path, self.proj.to_dict())
            self.log_path = Path(tempfile.gettempdir()) / "nexora-studio-playtest.log"
            self.log_path.write_text("", encoding="utf-8")
            self.log_pos = 0
            env = dict(os.environ, NEXORA_LOG=str(self.log_path), NEXORA_PASSES=json.dumps("*"))  # test: you own every pass
            cmd = self.self_cmd() + ["--run", str(path), "--user", self.user]
            self.proc = subprocess.Popen(cmd, env=env)
        except (OSError, ValueError) as e:
            self.log(f"Couldn't start the test: {e}", "err")
            return
        self.log("▶ Test started" + ("" if spawn else " (no Spawn part: you'll start above the middle)") +
                 ". Press Esc in the game to leave.", "ok")
        self.set_status("Testing…")
        discordrpc.set(details=f"Testing {self.proj.data['name']}"[:100] if self.proj else "Testing a game", state="In Nexora Studio")
        self.after(300, self.poll_test)

    def self_cmd(self):
        if getattr(sys, "frozen", False):
            return [sys.executable]
        return [sys.executable, os.path.abspath(__file__)]

    def poll_test(self):
        if not self.edit_frame or not self.edit_frame.winfo_exists():
            return
        try:
            with open(self.log_path, "r", encoding="utf-8", errors="replace") as f:
                f.seek(self.log_pos)
                chunk = f.read()
                self.log_pos = f.tell()
        except (OSError, TypeError):
            chunk = ""
        for line in chunk.splitlines():
            self.log(line, "err" if line.startswith("ERROR") or "Error" in line[:40] else None)
        if self.proc and self.proc.poll() is None:
            self.after(300, self.poll_test)
            return
        code = self.proc.returncode if self.proc else 0
        self.log("■ Test ended." if code in (0, None) else f"■ Test ended with an error (code {code}).",
                 "dim" if code in (0, None) else "err")
        self.set_status("Test ended.")
        self.proc = None

    def stop_test(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()

    # ================================================================ files / publish
    def save(self):
        try:
            path = self.proj.save()
        except (OSError, ValueError) as e:
            messagebox.showerror(TITLE, f"Couldn't save.\n\n{e}")
            return False
        self.set_status(f"Saved to {path}")
        self.update_title()
        return True

    def save_as(self):
        path = filedialog.asksaveasfilename(parent=self, defaultextension=".json", initialdir=str(pj.projects_dir()),
                                            initialfile=f"{self.proj.data['id']}.json",
                                            filetypes=[("Nexora game", "*.json")])
        if not path:
            return
        try:
            self.proj.save(Path(path))
        except (OSError, ValueError) as e:
            messagebox.showerror(TITLE, f"Couldn't save.\n\n{e}")
            return
        self.set_status(f"Saved to {path}")
        self.update_title()

    def publish(self):
        if not self.check_all():
            messagebox.showwarning(TITLE, "Some scripts have problems. Fix them before publishing.", parent=self)
            return
        if not self.save():
            return
        if online.enabled():
            self.set_status("Uploading to the Nexora server…")
            data = self.proj.to_dict()
            if not any(p["kind"] == "spawn" for p in data["parts"]):
                messagebox.showerror(TITLE, "Add a Spawn part first, so players know where to start.")
                return

            def done(game, err):
                if err:
                    self.log("✖ Couldn't publish: " + err, "err")
                    self.set_status("Publish failed.")
                    return
                self.log(f"✔ Published “{game['name']}” online. Everyone on this Nexora server can find it in Games.",
                         "ok")
                self.set_status("Published online.")
            self.bg(lambda: self.net.publish(data), done)
            return
        try:
            out = self.proj.publish(self.user)
        except (OSError, ValueError) as e:
            messagebox.showerror(TITLE, f"Couldn't publish.\n\n{e}")
            return
        self.log(f"✔ Published “{self.proj.data['name']}”. Open Nexora → Games to play it, or host it in Servers.", "ok")
        self.log(f"   ({out})", "dim")
        self.set_status("Published to Nexora on this PC.")

    def unpublish(self):
        if not messagebox.askyesno(TITLE, "Remove this game from Nexora's Games list?\n"
                                          "Your project stays here in Studio.", parent=self):
            return
        if online.enabled():
            self.bg(lambda: self.net.unpublish(self.proj.data["id"]),
                    lambda r, err: self.log("✖ " + err, "err") if err else self.log("Unpublished online.", "dim"))
            return
        pj.unpublish(self.proj.data["id"])
        self.log("Unpublished. It no longer shows in Nexora.", "dim")

    # ---- gamepasses
    def manage_passes(self):
        """List, add and remove this game's gamepasses (sold for Nexei). Needs the game published online first."""
        if not (online.enabled() and self.net.token):
            messagebox.showinfo(TITLE, "Gamepasses need a Nexora server. Sign in online and publish the game first.")
            return
        gid = self.proj.data["id"]
        win = tk.Toplevel(self)
        win.title("Gamepasses")
        win.configure(bg=th.PANEL, padx=16, pady=14)
        win.geometry("460x420")
        win.transient(self)
        tk.Label(win, text="Gamepasses", bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 13, "bold")).pack(anchor="w")
        tk.Label(win, text="Players buy these with Nexei and you get 70%. In a script: if player.has_pass(\"VIP\"): ... "
                           "(in Play Test you own every pass). Scripts run on the player's PC, so this is an honour "
                           "system, not copy protection.", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9), wraplength=420,
                 justify="left").pack(anchor="w", pady=(2, 8))
        listbox = tk.Frame(win, bg=th.PANEL)
        listbox.pack(fill="both", expand=True)
        msg = tk.Label(win, text="", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 9), wraplength=420, justify="left")
        msg.pack(anchor="w")
        form = tk.Frame(win, bg=th.PANEL)
        form.pack(fill="x", pady=(6, 0))
        fields = {}
        for key, label, w in (("name", "Name", 16), ("desc", "Description", 22), ("price", "Price", 7)):
            col = tk.Frame(form, bg=th.PANEL)
            col.pack(side="left", padx=(0, 6))
            tk.Label(col, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 8)).pack(anchor="w")
            e = tk.Entry(col, width=w, bg=th.BG, fg=th.TEXT, insertbackground=th.TEXT, relief="flat")
            e.pack(ipady=3)
            fields[key] = e

        def render(res, err):
            if not win.winfo_exists():
                return
            for w in listbox.winfo_children():
                w.destroy()
            if err:
                msg.configure(text=err, fg=th.DANGER)
                return
            if not res["can_manage"]:
                msg.configure(text="Publish this game online first (File > Publish).", fg=th.DANGER)
            for p in res["passes"]:
                row = tk.Frame(listbox, bg=th.PANEL2, padx=8, pady=4)
                row.pack(fill="x", pady=2)
                tk.Label(row, text=f"{p['name']}  ·  ◈ {p['price']:,}", bg=th.PANEL2, fg=th.TEXT,
                         font=(th.FONT, 10)).pack(side="left")
                self.btn(row, "Remove", lambda p=p: self.bg(lambda: self.net.remove_item(p["id"]),
                                                            lambda r, e: reload())).pack(side="right")

        def reload():
            self.bg(lambda: self.net.passes(gid), render)

        def add():
            try:
                price = int(fields["price"].get().replace(",", ""))
            except ValueError:
                msg.configure(text="The price must be a whole number.", fg=th.DANGER)
                return

            def done(r, e):
                msg.configure(text=e or "Added.", fg=th.DANGER if e else th.CYAN)
                if not e:
                    for f in fields.values():
                        f.delete(0, "end")
                reload()
            name, desc = fields["name"].get(), fields["desc"].get()  # read here: widgets can't be touched in the thread
            self.bg(lambda: self.net.add_pass(gid, name, desc, price), done)
        self.btn(form, "Add", add).pack(side="left", anchor="s")
        reload()

    # ---- thumbnails
    def add_thumbnail(self):
        import base64
        import io
        self.notebook.select(0)
        self.update_idletasks()
        try:
            img = self.viewport.snapshot(320, 180)
            buf = io.BytesIO()
            img.save(buf, "PNG", optimize=True)
            b64 = base64.b64encode(buf.getvalue()).decode()
            self.proj.data["thumbs"] = (self.proj.data["thumbs"] + [b64])[-pj.MAX_THUMBS:]
            pj.clean_project(self.proj.data)
        except (ValueError, OSError, ImportError) as e:
            messagebox.showerror(TITLE, f"Couldn't make a thumbnail.\n\n{e}")
            return
        self.proj.commit()
        self.update_title()
        self.build_prop_fields()
        self.set_status("Thumbnail added from the current 3D view.")

    def clear_thumbnails(self):
        self.proj.data["thumbs"] = []
        self.proj.commit()
        self.update_title()
        self.build_prop_fields()

    # ================================================================ closing
    def ask_save(self) -> bool:
        """True if it's fine to leave the current game."""
        if not self.proj or not self.proj.dirty:
            return True
        r = messagebox.askyesnocancel(TITLE, f"Save changes to “{self.proj.data['name']}”?", parent=self)
        if r is None:
            return False
        return self.save() if r else True

    def close_game(self):
        if self.ask_save():
            self.stop_test()
            self.show_home()

    def on_close(self):
        if self.ask_save():
            self.stop_test()
            self.destroy()


def fmt(v) -> str:
    return f"{v:.3f}".rstrip("0").rstrip(".") if isinstance(v, float) else str(v)


def _isnum(s) -> bool:
    try:
        v = float(s)
        return v == v and abs(v) != float("inf")
    except (TypeError, ValueError):
        return False


def run_mode() -> bool:
    """`--run game.json`: open the game window for a Play Test (no editor)."""
    path = arg("--run")
    if not path:
        return False
    try:
        from runner import run
        run("studio-test", arg("--user", "Creator"), None, path)
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001 - report anything to the Output window
        from runner import emit
        emit("ERROR The game crashed: " + traceback.format_exc(limit=3))
        sys.exit(1)
    return True


if __name__ == "__main__":
    import bootstrap
    if "--run" not in sys.argv and not bootstrap.ensure_dependencies("Nexora Studio"):
        sys.exit(1)
    if not run_mode():
        discordrpc.set(details="Choosing a project", state="In Nexora Studio")
        discordrpc.start("studio")  # "Playing Nexora Studio" on Discord
        app = Studio(arg("--open"))
        bootstrap.close_splash()
        app.mainloop()
