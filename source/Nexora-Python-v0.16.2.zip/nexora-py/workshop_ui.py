"""The Workshop: a window where anyone can design a shirt, pants or accessory and send it to the Shop.

Shirts and pants: pick a base colour and paint a 32x32 picture (shirts also get a picture for the sleeves), or import a
PNG/JPG. Accessories: build from up to 8
coloured boxes and/or import a 3D model (OBJ, STL, PLY, GLB, glTF). Staff items go on sale at once; everyone else's wait
for a staff review."""
import tkinter as tk
from tkinter import colorchooser, filedialog

import avatar as av_mod
import meshio
import pictureio
import theme as th
from widgets import PANTS, SHIRT, draw_avatar

PICTURE_COLORS = ["#ffffff", "#000000", "#ef4444", "#f59e0b", "#facc15", "#4ade80", "#22d3ee", "#7c5cff",
                  "#f472b6", "#a16207", "#1d4ed8", "#14532d", "#9ca3af", "#374151", "#fca5a5", "#bae6fd"]
SIZES = {"front": (av_mod.TEX, av_mod.TEX), "sleeve": (16, 32)}   # width x height of each picture
CELL = 13


class Workshop(tk.Toplevel):
    def __init__(self, app, on_done=None):
        super().__init__(app)
        self.app, self.on_done = app, on_done
        self.title("Workshop")
        self.configure(bg=th.PANEL, padx=16, pady=14)
        self.geometry("900x720")
        self.transient(app)
        self.kind = tk.StringVar(value="shirt")
        self.base = tk.StringVar(value="#7c5cff")
        self.tex = {k: {"px": ["."] * (w * h), "pal": list(PICTURE_COLORS)} for k, (w, h) in SIZES.items()}
        self.part = tk.StringVar(value="front")     # which picture is being painted: "front" or "sleeve"
        self.tool = tk.StringVar(value="paint")     # paint / fill / pick
        self.cur = 2
        self.show_grid = tk.IntVar(value=1)         # grid lines over the picture while painting
        self._pv_job = None
        self.slot = tk.StringVar(value="head")
        self.boxes = []          # [{"p":[x,y,z], "s":[w,h,d], "c":"#hex"}]
        self.mbase = None        # an imported model (meshio.Base) and how it is placed
        self.mesh = None         # ... and the finished mesh for the avatar
        self.mv = {"size": tk.StringVar(), "yaw": tk.StringVar(value="0"), "zup": tk.IntVar(value=0),
                   "dx": tk.StringVar(value="0"), "dy": tk.StringVar(value="0"), "dz": tk.StringVar(value="0")}
        self.mcolor = "#cccccc"
        self.sel = None
        self._loading = False

        tk.Label(self, text="Workshop", bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 15, "bold")).pack(anchor="w")
        top = tk.Frame(self, bg=th.PANEL)
        top.pack(fill="x", pady=8)
        for k, label in (("shirt", "Shirt"), ("pants", "Pants"), ("acc", "Accessory")):
            tk.Radiobutton(top, text=label, value=k, variable=self.kind, command=self.rebuild, bg=th.PANEL, fg=th.TEXT,
                           selectcolor=th.PANEL2, activebackground=th.PANEL, activeforeground=th.TEXT,
                           font=(th.FONT, 11, "bold"), indicatoron=False, padx=14, pady=5, relief="flat",
                           bd=0).pack(side="left", padx=(0, 6))
        self.body = tk.Frame(self, bg=th.PANEL)
        self.body.pack(fill="both", expand=True)
        bottom = tk.Frame(self, bg=th.PANEL)
        bottom.pack(fill="x", pady=(8, 0))
        self.name = self._entry(bottom, "Name", 20)
        self.price = self._entry(bottom, "Price (Nexei)", 8)
        self.price.insert(0, "50")
        app.button(bottom, "Submit", self.submit, primary=True).pack(side="right")
        self.msg = tk.Label(self, text="", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 10), wraplength=800, justify="left",
                            anchor="w")
        self.msg.pack(fill="x", pady=(6, 0))
        self.rebuild()

    # ------------------------------------------------------------ small helpers
    def _entry(self, parent, label, width):
        col = tk.Frame(parent, bg=th.PANEL)
        col.pack(side="left", padx=(0, 10))
        tk.Label(col, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).pack(anchor="w")
        e = tk.Entry(col, width=width, bg=th.BG, fg=th.TEXT, insertbackground=th.TEXT, relief="flat",
                     font=(th.FONT, 11))
        e.pack(ipady=4)
        return e

    def say(self, text, bad=False):
        self.msg.configure(text=text, fg=th.DANGER if bad else th.CYAN)

    @property
    def px(self):          # the front picture's pixels (kept as a name other code and tests use)
        return self.tex["front"]["px"]

    @px.setter
    def px(self, v):
        self.tex["front"]["px"] = list(v)

    @property
    def pal(self):
        return self.tex["front"]["pal"]

    def preview_avatar(self) -> dict:
        look = dict(self.app.user["avatar"])
        look = av_mod.clean(look)
        k = self.kind.get()
        if k in ("shirt", "pants"):
            look[k] = self.base.get() if av_mod.HEX_RE.fullmatch(self.base.get()) else look[k]
            look[k + "_tex"] = self.texture()
            if k == "shirt":
                look["sleeve_tex"] = self.sleeve_texture()
        else:
            look["acc"] = [a for a in look["acc"] if a["slot"] != self.slot.get()]
            cleaned = av_mod.clean_acc({"slot": self.slot.get(), "boxes": self.boxes, "mesh": self.mesh})
            if cleaned:
                look["acc"].append(cleaned)
        return look

    def texture(self):
        t = self.tex["front"]
        return av_mod.clean_tex({"pal": t["pal"], "px": "".join(t["px"])})

    def sleeve_texture(self):
        t = self.tex["sleeve"]
        return av_mod.clean_sleeve({"pal": t["pal"], "px": "".join(t["px"])})

    def redraw_preview(self):
        c = getattr(self, "pv", None)
        if c is None or not c.winfo_exists():
            return
        c.delete("all")
        draw_avatar(c, self.preview_avatar(), s=8, ox=14, oy=6, top=11)

    def soon_preview(self):
        """Redraw the avatar preview shortly, once, however many pixels were painted in the meantime."""
        if self._pv_job is None:
            def go():
                self._pv_job = None
                if self.winfo_exists():
                    self.redraw_preview()
            self._pv_job = self.after(60, go)

    # ------------------------------------------------------------ layout
    def rebuild(self):
        for w in self.body.winfo_children():
            w.destroy()
        self.msg.configure(text="")
        left = tk.Frame(self.body, bg=th.PANEL)
        left.pack(side="left", anchor="n")
        self.pv = tk.Canvas(left, width=16 * 8 + 28, height=39 * 8 + 12, bg=th.BG, highlightthickness=1,
                            highlightbackground=th.LINE)
        self.pv.pack()
        tk.Label(left, text="Preview (front, approximate)", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 8)).pack()
        right = tk.Frame(self.body, bg=th.PANEL)
        right.pack(side="left", fill="both", expand=True, padx=(18, 0))
        if self.kind.get() == "acc":
            self.build_acc(right)
        else:
            self.build_picture(right)
        self.redraw_preview()

    # ------------------------------------------------------------ shirt / pants
    def build_picture(self, parent):
        palette = SHIRT if self.kind.get() == "shirt" else PANTS
        if self.kind.get() != "shirt":
            self.part.set("front")
        tk.Label(parent, text="Base colour", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 10, "bold")).pack(anchor="w")
        row = tk.Frame(parent, bg=th.PANEL)
        row.pack(anchor="w", pady=(2, 6))
        for col in palette:
            tk.Button(row, bg=col, activebackground=col, width=2, relief="flat", bd=0, cursor="hand2",
                      command=lambda c=col: self.set_base(c)).pack(side="left", padx=2)
        tk.Button(row, text="Custom...", command=self.pick_base, bg=th.PANEL2, fg=th.TEXT, relief="flat", bd=0,
                  padx=8).pack(side="left", padx=8)
        pr = tk.Frame(parent, bg=th.PANEL)
        pr.pack(anchor="w", pady=(0, 4))
        if self.kind.get() == "shirt":
            for k, label in (("front", "Front"), ("sleeve", "Sleeves")):
                tk.Radiobutton(pr, text=label, value=k, variable=self.part, command=self.rebuild_grid, bg=th.PANEL,
                               fg=th.TEXT, selectcolor=th.PANEL2, activebackground=th.PANEL, activeforeground=th.TEXT,
                               font=(th.FONT, 10, "bold"), indicatoron=False, padx=12, pady=3, relief="flat",
                               bd=0).pack(side="left", padx=(0, 4))
            tk.Label(pr, text="(the same sleeve picture goes on both arms)", bg=th.PANEL, fg=th.DIM,
                     font=(th.FONT, 8)).pack(side="left", padx=8)
        else:
            tk.Label(pr, text="Picture across both legs", bg=th.PANEL, fg=th.DIM,
                     font=(th.FONT, 10, "bold")).pack(side="left")
        tools = tk.Frame(parent, bg=th.PANEL)
        tools.pack(anchor="w", pady=(0, 4))
        for k, label in (("paint", "Paint"), ("fill", "Fill"), ("pick", "Pick colour")):
            tk.Radiobutton(tools, text=label, value=k, variable=self.tool, bg=th.PANEL, fg=th.TEXT, selectcolor=th.PANEL2,
                           activebackground=th.PANEL, activeforeground=th.TEXT, font=(th.FONT, 9), indicatoron=False,
                           padx=10, pady=2, relief="flat", bd=0).pack(side="left", padx=(0, 4))
        tk.Checkbutton(tools, text="Grid", variable=self.show_grid, command=self.apply_grid, bg=th.PANEL, fg=th.TEXT,
                       selectcolor=th.PANEL2, activebackground=th.PANEL, activeforeground=th.TEXT,
                       font=(th.FONT, 9, "bold")).pack(side="left", padx=(8, 0))
        tk.Label(tools, text="  click = use the tool, right-click = erase", bg=th.PANEL, fg=th.DIM,
                 font=(th.FONT, 8)).pack(side="left")
        self.wrap = tk.Frame(parent, bg=th.PANEL)
        self.wrap.pack(anchor="w", pady=4)
        self.rebuild_grid()

    def rebuild_grid(self):
        for w in self.wrap.winfo_children():
            w.destroy()
        w_, h_ = SIZES[self.part.get()]
        self.grid_c = tk.Canvas(self.wrap, width=w_ * CELL, height=h_ * CELL, bg=th.BG, highlightthickness=1,
                                highlightbackground=th.LINE, cursor="hand2")
        self.grid_c.pack(side="left")
        self.grid_c.bind("<Button-1>", lambda e: self.paint(e, True, first=True))
        self.grid_c.bind("<B1-Motion>", lambda e: self.paint(e, True))
        self.grid_c.bind("<Button-3>", lambda e: self.paint(e, False))
        self.grid_c.bind("<B3-Motion>", lambda e: self.paint(e, False))
        side = tk.Frame(self.wrap, bg=th.PANEL)
        side.pack(side="left", padx=14, anchor="n")
        tk.Label(side, text="Paint colours (16)", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).pack(anchor="w")
        sw = tk.Frame(side, bg=th.PANEL)
        sw.pack(anchor="w", pady=4)
        self.swatches = []
        for i in range(av_mod.MAX_PAL):
            b = tk.Button(sw, width=2, relief="solid", bd=1, cursor="hand2", command=lambda i=i: self.choose(i))
            b.grid(row=i // 4, column=i % 4, padx=2, pady=2)
            self.swatches.append(b)
        tk.Button(side, text="Change this colour...", command=self.change_swatch, bg=th.PANEL2, fg=th.TEXT,
                  relief="flat", bd=0, padx=8, pady=3).pack(anchor="w", pady=(4, 2))
        tk.Button(side, text="Clear picture", command=self.clear_picture, bg=th.PANEL2, fg=th.TEXT, relief="flat",
                  bd=0, padx=8, pady=3).pack(anchor="w", pady=(0, 10))
        tk.Button(side, text="Import PNG / JPG...", command=self.import_picture, bg=th.ACCENT, fg=th.ON_ACCENT,
                  relief="flat", bd=0, padx=8, pady=4, font=(th.FONT, 10, "bold")).pack(anchor="w")
        tk.Label(side, text=f"Fitted to {w_} x {h_} pixels and\n16 colours. PNG keeps see-through\nparts; JPG gets soft. Pixel art that\n"
                            f"is {w_} or a multiple of {w_} pixels\nwide comes out exactly.", bg=th.PANEL, fg=th.DIM,
                 font=(th.FONT, 8), justify="left").pack(anchor="w", pady=(4, 0))
        self.cells = []
        for i in range(w_ * h_):
            x, y = (i % w_) * CELL, (i // w_) * CELL
            self.cells.append(self.grid_c.create_rectangle(x, y, x + CELL, y + CELL, outline="", width=1))
        self.apply_grid()
        self.refresh_grid()

    def apply_grid(self):
        """Grid lines on: easy to paint exact pixels. Off: the picture shows as it will look, with no lines over it."""
        line = th.LINE if self.show_grid.get() else ""
        for cid in self.cells:
            self.grid_c.itemconfigure(cid, outline=line)

    def set_base(self, c):
        self.base.set(c)
        self.refresh_grid()

    def pick_base(self):
        c = colorchooser.askcolor(color=self.base.get(), parent=self)[1]
        if c:
            self.set_base(c.lower())

    def cur_tex(self):
        return self.tex[self.part.get()]

    def cell_color(self, t, i):
        ch = t["px"][i]
        return self.base.get() if ch == "." else t["pal"][av_mod.PAL_CHARS.index(ch)]

    def refresh_grid(self):
        t = self.cur_tex()
        for i, cid in enumerate(self.cells):
            self.grid_c.itemconfigure(cid, fill=self.cell_color(t, i))
        for i, b in enumerate(self.swatches):
            b.configure(bg=t["pal"][i], activebackground=t["pal"][i],
                        relief="solid" if i != self.cur else "sunken", bd=3 if i == self.cur else 1)
        self.redraw_preview()

    def choose(self, i):
        self.cur = i
        self.refresh_grid()

    def paint(self, e, on, first=False):
        w_, h_ = SIZES[self.part.get()]
        x, y = e.x // CELL, e.y // CELL
        if not (0 <= x < w_ and 0 <= y < h_):
            return
        t, i = self.cur_tex(), y * w_ + x
        tool = self.tool.get() if on else "erase"
        if tool == "pick":
            if first and t["px"][i] != ".":
                self.cur = av_mod.PAL_CHARS.index(t["px"][i])
                self.tool.set("paint")
                self.refresh_grid()
            return
        if tool == "fill":
            if first:
                self.flood(t, w_, h_, i, av_mod.PAL_CHARS[self.cur])
            return
        ch = av_mod.PAL_CHARS[self.cur] if tool == "paint" else "."
        if t["px"][i] != ch:
            t["px"][i] = ch
            self.grid_c.itemconfigure(self.cells[i], fill=self.cell_color(t, i))
            self.soon_preview()

    def flood(self, t, w_, h_, start, ch):
        """Bucket fill: every connected pixel of the clicked colour (or empty) becomes the current colour."""
        old = t["px"][start]
        if old == ch:
            return
        todo, seen = [start], {start}
        while todo:
            i = todo.pop()
            t["px"][i] = ch
            x, y = i % w_, i // w_
            for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if 0 <= nx < w_ and 0 <= ny < h_:
                    j = ny * w_ + nx
                    if j not in seen and t["px"][j] == old:
                        seen.add(j)
                        todo.append(j)
        self.refresh_grid()

    def change_swatch(self):
        t = self.cur_tex()
        c = colorchooser.askcolor(color=t["pal"][self.cur], parent=self)[1]
        if c:
            t["pal"][self.cur] = c.lower()
            self.refresh_grid()

    def clear_picture(self):
        t = self.cur_tex()
        t["px"] = ["."] * len(t["px"])
        self.refresh_grid()

    def import_picture(self):
        path = filedialog.askopenfilename(
            parent=self, title="Choose a picture",
            filetypes=[("Pictures", " ".join("*" + e for e in pictureio.EXTS)), ("All files", "*.*")])
        if not path:
            return
        w_, h_ = SIZES[self.part.get()]
        try:
            t = pictureio.to_texture(path, w_, h_)
        except pictureio.PictureError as e:
            self.say(str(e), True)
            return
        cur = self.cur_tex()
        cur["pal"] = (t["pal"] + PICTURE_COLORS)[:av_mod.MAX_PAL]  # unused slots keep the usual paint colours
        cur["px"] = list(t["px"])
        self.cur = 0
        self.refresh_grid()
        self.say(f"Imported. {len(t['pal'])} colour{'s' if len(t['pal']) != 1 else ''}; fix any pixel by painting over it.")

    # ------------------------------------------------------------ accessory
    def build_acc(self, parent):
        top = tk.Frame(parent, bg=th.PANEL)
        top.pack(fill="x")
        tk.Label(top, text="Worn on", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 10, "bold")).pack(side="left")
        staff = getattr(self.app, "is_staff", lambda: False)()   # only staff can make Headless / Legless items
        tk.OptionMenu(top, self.slot, *(av_mod.ALL_SLOTS if staff else av_mod.SLOTS),
                      command=lambda _v: self.slot_changed()).pack(side="left", padx=8)
        tk.Button(top, text="Import 3D model...", command=self.import_model, bg=th.ACCENT, fg=th.ON_ACCENT, relief="flat",
                  bd=0, padx=10, pady=3, font=(th.FONT, 10, "bold")).pack(side="left", padx=(18, 0))
        tk.Label(top, text="OBJ, STL, PLY, GLB, glTF", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).pack(side="left", padx=8)
        self.slot_hint = tk.Label(parent, text="", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 9), anchor="w")
        self.slot_hint.pack(fill="x", pady=(4, 0))
        mid = tk.Frame(parent, bg=th.PANEL)
        mid.pack(fill="both", expand=True, pady=8)
        lf = tk.Frame(mid, bg=th.PANEL)
        lf.pack(side="left", anchor="n")
        self.lb = tk.Listbox(lf, height=9, width=22, bg=th.BG, fg=th.TEXT, selectbackground=th.ACCENT,
                             selectforeground=th.ON_ACCENT, relief="flat", exportselection=False, font=(th.FONT, 10))
        self.lb.pack()
        self.lb.bind("<<ListboxSelect>>", self.on_select)
        bf = tk.Frame(lf, bg=th.PANEL)
        bf.pack(fill="x", pady=4)
        tk.Button(bf, text="Add box", command=self.add_box, bg=th.PANEL2, fg=th.TEXT, relief="flat", bd=0, padx=8,
                  pady=3).pack(side="left")
        tk.Button(bf, text="Remove", command=self.remove_box, bg=th.PANEL2, fg=th.TEXT, relief="flat", bd=0, padx=8,
                  pady=3).pack(side="left", padx=4)
        form = tk.Frame(mid, bg=th.PANEL)
        form.pack(side="left", padx=18, anchor="n")
        self.f = {}
        rows = (("x", "Left/right (x)"), ("y", "Height (y)"), ("z", "Front/back (z)"),
                ("w", "Width"), ("h", "Height"), ("d", "Depth"))
        for i, (k, label) in enumerate(rows):
            tk.Label(form, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).grid(row=i, column=0, sticky="w", pady=2)
            e = tk.Spinbox(form, width=7, from_=-3.0, to=3.0, increment=0.05, format="%.2f", bg=th.BG, fg=th.TEXT,
                           insertbackground=th.TEXT, relief="flat", buttonbackground=th.PANEL2,
                           command=self.apply_form)
            e.grid(row=i, column=1, padx=8)
            e.bind("<KeyRelease>", lambda _e: self.apply_form())
            self.f[k] = e
        tk.Label(form, text="Colour", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).grid(row=6, column=0, sticky="w", pady=2)
        self.col_btn = tk.Button(form, width=8, relief="solid", bd=1, command=self.pick_box_color)
        self.col_btn.grid(row=6, column=1, padx=8, pady=2)
        tk.Label(parent, text="Feet are at height 0, the head is at about 1.85, the front is +z. Up to 8 boxes. The "
                              "preview is flat; in the game the boxes are 3D.", bg=th.PANEL, fg=th.DIM,
                 font=(th.FONT, 8), wraplength=520, justify="left").pack(anchor="w")
        self.build_model_panel(parent)
        self.refresh_boxes()

    # ------------------------------------------------------------ imported 3D model
    def build_model_panel(self, parent):
        box = tk.LabelFrame(parent, text=" 3D model ", bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9, "bold"), bd=1,
                            relief="solid", padx=10, pady=6)
        box.pack(fill="x", pady=(10, 0))
        self.minfo = tk.Label(box, text="", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 9), anchor="w", justify="left",
                              wraplength=520)
        self.minfo.pack(fill="x")
        self.mctl = tk.Frame(box, bg=th.PANEL)
        self.mctl.pack(fill="x", pady=(4, 0))
        self.mspin = {}
        for i, (k, label, lo, hi, step) in enumerate((("size", "Size", 0.05, 2.0, 0.05), ("yaw", "Turn (deg)", -360, 360, 15),
                                                      ("dx", "Move left/right", -1.0, 1.0, 0.05),
                                                      ("dy", "Move up/down", -1.0, 1.0, 0.05),
                                                      ("dz", "Move front/back", -1.0, 1.0, 0.05))):
            tk.Label(self.mctl, text=label, bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9)).grid(row=i // 3 * 2, column=i % 3, sticky="w", padx=(0, 10))
            e = tk.Spinbox(self.mctl, width=7, from_=lo, to=hi, increment=step, textvariable=self.mv[k], bg=th.BG, fg=th.TEXT,
                           insertbackground=th.TEXT, relief="flat", buttonbackground=th.PANEL2, command=self.replace_mesh)
            e.grid(row=i // 3 * 2 + 1, column=i % 3, sticky="w", padx=(0, 10), pady=(0, 4))
            e.bind("<KeyRelease>", lambda _e: self.replace_mesh())
            self.mspin[k] = e
        tk.Checkbutton(self.mctl, text="Model is Z-up (Blender / CAD)", variable=self.mv["zup"], command=self.replace_mesh,
                       bg=th.PANEL, fg=th.TEXT, selectcolor=th.PANEL2, activebackground=th.PANEL,
                       activeforeground=th.TEXT, font=(th.FONT, 9)).grid(row=2, column=2, sticky="w", pady=(0, 4))
        row = tk.Frame(box, bg=th.PANEL)
        row.pack(fill="x")
        self.mcol_btn = tk.Button(row, text="Plain colour", command=self.pick_mesh_color, bg=th.PANEL2, fg=th.TEXT,
                                  relief="flat", bd=0, padx=8, pady=3)
        self.mcol_btn.pack(side="left")
        tk.Label(row, text="(used when the file has no colours of its own)", bg=th.PANEL, fg=th.DIM,
                 font=(th.FONT, 8)).pack(side="left", padx=8)
        tk.Button(row, text="Remove model", command=self.remove_model, bg=th.PANEL2, fg=th.TEXT, relief="flat", bd=0,
                  padx=8, pady=3).pack(side="right")
        self.refresh_model_panel()

    def refresh_model_panel(self):
        if not getattr(self, "minfo", None) or not self.minfo.winfo_exists():
            return
        b = self.mbase
        if not b:
            self.minfo.configure(text="No model. Import one to add it to your boxes (staff review every model).", fg=th.DIM)
            for e in self.mspin.values():
                e.configure(state="disabled")
            return
        for e in self.mspin.values():
            e.configure(state="normal")
        txt = f"{b.name}: {len(b.tris)} triangles"
        if b.simplified:
            txt += f" (simplified from {b.original_tris:,}; the limit is {av_mod.MAX_TRIS})"
        if any(b.cols):
            txt += ", colours from the file"
        self.minfo.configure(text=txt, fg=th.CYAN)
        if any(b.cols):
            self.mcol_btn.configure(bg=th.PANEL2, fg=th.TEXT)
        else:
            lum = sum(int(self.mcolor[i:i + 2], 16) * w for i, w in ((1, .3), (3, .59), (5, .11)))
            self.mcol_btn.configure(bg=self.mcolor, fg="#000000" if lum > 140 else "#ffffff")

    def import_model(self):
        path = filedialog.askopenfilename(
            parent=self, title="Choose a 3D model",
            filetypes=[("3D models", " ".join("*" + e for e in meshio.EXTS)), ("All files", "*.*")])
        if not path:
            return
        self.say("Reading the model...")

        def done(base, err):
            if not self.winfo_exists():
                return
            if err:
                self.say(err, True)
                return
            self.mbase = base
            self.reset_placement()
            self.replace_mesh()
            self.say("Model added. Turn it or move it until it sits right on the preview.")
        self.app.bg(lambda: meshio.load(path), done)

    def reset_placement(self):
        self.mv["size"].set(f"{meshio.SIZE[self.slot.get()]:.2f}")
        self.mv["yaw"].set("0")
        self.mv["zup"].set(0)
        for k in ("dx", "dy", "dz"):
            self.mv[k].set("0")

    def replace_mesh(self):
        """Put the model where the settings say. Ignores half-typed numbers."""
        if not self.mbase:
            self.mesh = None
            self.refresh_model_panel()
            self.redraw_preview()
            return
        if self.slot.get() not in meshio.ANCHOR:   # a body item (Headless / Legless) has no model to place
            self.redraw_preview()
            return
        try:
            v = {k: float(self.mv[k].get()) for k in ("size", "yaw", "dx", "dy", "dz")}
        except ValueError:
            return
        self.mesh = meshio.place(self.mbase, self.slot.get(), size=v["size"], yaw=v["yaw"], z_up=bool(self.mv["zup"].get()),
                                 dx=v["dx"], dy=v["dy"], dz=v["dz"], color=self.mcolor)
        self.refresh_model_panel()
        self.redraw_preview()

    def pick_mesh_color(self):
        c = colorchooser.askcolor(color=self.mcolor, parent=self)[1]
        if c:
            self.mcolor = c.lower()
            self.replace_mesh()

    def remove_model(self):
        self.mbase = self.mesh = None
        self.refresh_model_panel()
        self.redraw_preview()

    HIDE_HINT = {"nohead": "Staff body item: wearing it hides the head. Looks only. No boxes needed.",
                 "noleftleg": "Staff body item: wearing it hides the left leg. Looks only. No boxes needed.",
                 "norightleg": "Staff body item: wearing it hides the right leg. Looks only. No boxes needed."}

    def slot_changed(self):
        h = getattr(self, "slot_hint", None)
        if h is not None and h.winfo_exists():
            h.configure(text=self.HIDE_HINT.get(self.slot.get(), ""))
        if self.mbase and self.slot.get() in meshio.ANCHOR:
            self.reset_placement()
            self.replace_mesh()
        else:
            self.redraw_preview()

    def refresh_boxes(self):
        self.lb.delete(0, "end")
        for i, b in enumerate(self.boxes):
            self.lb.insert("end", f"Box {i + 1}  {b['c']}")
        if self.sel is not None and self.sel < len(self.boxes):
            self.lb.selection_set(self.sel)
        self.fill_form()
        self.redraw_preview()

    def on_select(self, _e=None):
        s = self.lb.curselection()
        self.sel = s[0] if s else None
        self.fill_form()

    def fill_form(self):
        self._loading = True
        b = self.boxes[self.sel] if self.sel is not None and self.sel < len(self.boxes) else None
        vals = (b["p"] + b["s"]) if b else [0, 0, 0, 0, 0, 0]
        for (k, e), v in zip(self.f.items(), vals):
            e.configure(state="normal")
            e.delete(0, "end")
            e.insert(0, f"{v:.2f}")
        self.col_btn.configure(bg=b["c"] if b else th.PANEL2, activebackground=b["c"] if b else th.PANEL2)
        self._loading = False

    def apply_form(self):
        if self._loading or self.sel is None or self.sel >= len(self.boxes):
            return
        try:
            v = [float(self.f[k].get()) for k in "xyzwhd"]
        except ValueError:
            return
        b = self.boxes[self.sel]
        b["p"], b["s"] = v[:3], [max(0.05, x) for x in v[3:]]
        self.redraw_preview()

    def add_box(self):
        if len(self.boxes) >= av_mod.MAX_BOXES:
            self.say(f"An accessory can have up to {av_mod.MAX_BOXES} boxes.", True)
            return
        self.boxes.append({"p": [0.0, 2.2, 0.0], "s": [0.3, 0.3, 0.3], "c": "#ffcc00"})
        self.sel = len(self.boxes) - 1
        self.refresh_boxes()

    def remove_box(self):
        if self.sel is not None and self.sel < len(self.boxes):
            del self.boxes[self.sel]
            self.sel = min(self.sel, len(self.boxes) - 1) if self.boxes else None
            self.refresh_boxes()

    def pick_box_color(self):
        if self.sel is None or self.sel >= len(self.boxes):
            return
        c = colorchooser.askcolor(color=self.boxes[self.sel]["c"], parent=self)[1]
        if c:
            self.boxes[self.sel]["c"] = c.lower()
            self.refresh_boxes()

    # ------------------------------------------------------------ send
    def submit(self):
        k = self.kind.get()
        name = " ".join(self.name.get().split())
        try:
            price = int(self.price.get().replace(",", ""))
        except ValueError:
            self.say("The price must be a whole number of Nexei.", True)
            return
        fields = {"kind": k, "name": name, "price": price}
        if k == "acc":
            cleaned = av_mod.clean_acc({"slot": self.slot.get(), "boxes": self.boxes, "mesh": self.mesh})
            if not cleaned:
                self.say("Add at least one box or import a 3D model first.", True)
                return
            fields.update(slot=cleaned["slot"], boxes=cleaned["boxes"])
            if cleaned.get("mesh"):
                fields["mesh"] = cleaned["mesh"]
        else:
            fields["color"] = self.base.get()
            tex = self.texture()
            if tex:
                fields["tex"] = tex
            if k == "shirt":
                sl = self.sleeve_texture()
                if sl:
                    fields["sleeve"] = sl
        if not name:
            self.say("Give it a name.", True)
            return
        self.say("Sending...")
        app = self.app

        def done(res, err):
            if not self.winfo_exists():
                return
            if err:
                self.say(err, True)
                return
            self.say("It's in the Shop!" if res["status"] == "approved" else
                     "Sent! Staff will look at it, and when it's approved it goes on sale. Your Nexei payout is 70% of every sale.")
            if self.on_done:
                self.on_done()
        app.bg(lambda: app.net.make_item(**fields), done)
