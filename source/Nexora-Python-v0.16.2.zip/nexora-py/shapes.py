"""Shapes for parts besides the box and the sphere: cylinder, cone and wedge.

Each one is a list of flat faces (normal, [points]) in unit space: the part's box spans -0.5..0.5 on every side, y is up.
The Studio viewport draws these faces; the game turns them into triangles (`mesh_data`). Size is applied on top.
"""
import math

SEGMENTS = 14


def _norm(v):
    n = math.sqrt(sum(c * c for c in v)) or 1.0
    return tuple(c / n for c in v)


def cylinder(seg=SEGMENTS):
    faces = []
    ring = [(0.5 * math.cos(2 * math.pi * i / seg), 0.5 * math.sin(2 * math.pi * i / seg)) for i in range(seg)]
    faces.append(((0, 1, 0), [(x, 0.5, z) for x, z in ring]))
    faces.append(((0, -1, 0), [(x, -0.5, z) for x, z in reversed(ring)]))
    for i in range(seg):
        (x0, z0), (x1, z1) = ring[i], ring[(i + 1) % seg]
        n = _norm(((x0 + x1) / 2, 0, (z0 + z1) / 2))
        faces.append((n, [(x0, -0.5, z0), (x1, -0.5, z1), (x1, 0.5, z1), (x0, 0.5, z0)]))
    return faces


def cone(seg=SEGMENTS):
    faces = []
    ring = [(0.5 * math.cos(2 * math.pi * i / seg), 0.5 * math.sin(2 * math.pi * i / seg)) for i in range(seg)]
    faces.append(((0, -1, 0), [(x, -0.5, z) for x, z in reversed(ring)]))
    for i in range(seg):
        (x0, z0), (x1, z1) = ring[i], ring[(i + 1) % seg]
        n = _norm(((x0 + x1) / 2, 0.5, (z0 + z1) / 2))
        faces.append((n, [(x0, -0.5, z0), (x1, -0.5, z1), (0, 0.5, 0)]))
    return faces


def wedge():
    """A ramp: tall at the back (+z), sloping down to the front (-z)."""
    a, b, c, d = (-0.5, -0.5, -0.5), (0.5, -0.5, -0.5), (0.5, -0.5, 0.5), (-0.5, -0.5, 0.5)
    e, f = (-0.5, 0.5, 0.5), (0.5, 0.5, 0.5)
    slope = _norm((0, 1, -1))
    return [((0, -1, 0), [a, d, c, b]), ((0, 0, 1), [d, c, f, e]), (slope, [a, b, f, e]),
            ((-1, 0, 0), [a, e, d]), ((1, 0, 0), [b, c, f])]


_SHAPES = {"cylinder": cylinder, "cone": cone, "wedge": wedge}
_cache = {}


def faces(shape):
    if shape not in _cache:
        _cache[shape] = _SHAPES[shape]()
    return _cache[shape]


def mesh_data(shape):
    """(vertices, triangles, normals) for the game: every face is a fan of triangles with its own flat normal."""
    verts, tris, norms = [], [], []
    for n, poly in faces(shape):
        base = len(verts)
        verts += poly
        norms += [n] * len(poly)
        for i in range(1, len(poly) - 1):
            tris += [(base, base + i, base + i + 1)]
    return verts, tris, norms
