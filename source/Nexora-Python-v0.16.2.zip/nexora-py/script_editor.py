"""A small Python code editor for Nexora Studio: line numbers, colours, auto-indent, error marking."""
import keyword
import re
import tkinter as tk

import theme as th

_KW = r"\b(?:%s)\b" % "|".join(k for k in keyword.kwlist)
_RULES = [  # applied in order; later tags sit on top
    ("number", re.compile(r"\b\d+(?:\.\d+)?\b")),
    ("keyword", re.compile(_KW)),
    ("builtin", re.compile(r"\b(?:game|part|player|math|random|distance|rgb|print|range|len|min|max|abs|round|int|float|str)\b")),
    ("defname", re.compile(r"(?<=def )\w+")),
    ("string", re.compile(r"(\"\"\"[\s\S]*?\"\"\"|'''[\s\S]*?'''|\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*')")),
    ("comment", re.compile(r"#[^\n]*")),
]


class ScriptEditor(tk.Frame):
    def __init__(self, parent, source="", on_edit=None, mono="Consolas"):
        super().__init__(parent, bg=th.PANEL)
        self.on_edit = on_edit or (lambda text: None)
        self.font = (mono, 11)
        self.gutter = tk.Canvas(self, width=46, bg=th.PANEL2, highlightthickness=0)
        self.gutter.pack(side="left", fill="y")
        self.text = tk.Text(self, wrap="none", undo=True, maxundo=500, bg=th.BG, fg=th.TEXT, insertbackground=th.TEXT,
                            selectbackground=th.ACCENT, selectforeground=th.ON_ACCENT, relief="flat", font=self.font,
                            padx=8, pady=6, tabs=("1c",), highlightthickness=0)
        ys = tk.Scrollbar(self, command=self._yview)
        xs = tk.Scrollbar(self, orient="horizontal", command=self.text.xview)
        self.text.configure(yscrollcommand=lambda a, b: (ys.set(a, b), self.draw_gutter()),
                            xscrollcommand=xs.set)
        ys.pack(side="right", fill="y")
        xs.pack(side="bottom", fill="x")
        self.text.pack(side="left", fill="both", expand=True)
        for tag, col in (("keyword", "#c792ea"), ("builtin", th.CYAN), ("number", "#f78c6c"), ("string", "#c3e88d"),
                         ("comment", th.DIM), ("defname", "#82aaff")):
            self.text.tag_configure(tag, foreground=col)
        self.text.tag_configure("error", background="#7a1d33")
        self.text.insert("1.0", source)
        self.text.edit_reset()
        self._job = None
        t = self.text
        t.bind("<<Modified>>", self._modified)
        t.bind("<Return>", self._return)
        t.bind("<Tab>", self._tab)
        t.bind("<Shift-Tab>", self._untab)
        t.bind("<BackSpace>", self._backspace)
        t.bind("<Configure>", lambda e: self.draw_gutter())
        t.bind("<MouseWheel>", lambda e: self.after_idle(self.draw_gutter))
        self.highlight()
        self.after(50, self.draw_gutter)

    # ---- content
    def get(self) -> str:
        return self.text.get("1.0", "end-1c")

    def set(self, source: str) -> None:
        self.text.delete("1.0", "end")
        self.text.insert("1.0", source)
        self.text.edit_reset()
        self.highlight()

    def mark_errors(self, lines) -> None:
        self.text.tag_remove("error", "1.0", "end")
        for n in lines:
            self.text.tag_add("error", f"{n}.0", f"{n}.0 lineend+1c")
        if lines:
            self.text.see(f"{lines[0]}.0")

    def goto(self, line: int) -> None:
        self.text.mark_set("insert", f"{line}.0")
        self.text.see(f"{line}.0")
        self.text.focus_set()

    # ---- display
    def _yview(self, *a):
        self.text.yview(*a)
        self.draw_gutter()

    def draw_gutter(self):
        g = self.gutter
        g.delete("all")
        i = self.text.index("@0,0")
        while True:
            info = self.text.dlineinfo(i)
            if info is None:
                break
            g.create_text(40, info[1] + 2, anchor="ne", text=i.split(".")[0], fill=th.DIM, font=self.font)
            i = self.text.index(f"{i}+1line")
            if i == self.text.index("end"):
                break

    def highlight(self):
        t = self.text
        src = self.get()
        for tag, _ in _RULES:
            t.tag_remove(tag, "1.0", "end")
        for tag, rx in _RULES:
            for m in rx.finditer(src):
                t.tag_add(tag, f"1.0+{m.start()}c", f"1.0+{m.end()}c")
        self.draw_gutter()

    def _modified(self, _e=None):
        if not self.text.edit_modified():
            return
        self.text.edit_modified(False)
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(150, self._changed)

    def _changed(self):
        self._job = None
        self.text.tag_remove("error", "1.0", "end")
        self.highlight()
        self.on_edit(self.get())

    # ---- typing helpers
    def _return(self, _e):
        line = self.text.get("insert linestart", "insert")
        indent = re.match(r"[ \t]*", line).group(0)
        if line.rstrip().endswith(":"):
            indent += "    "
        self.text.insert("insert", "\n" + indent)
        self.text.see("insert")
        return "break"

    def _tab(self, _e):
        if self.text.tag_ranges("sel"):
            a = int(self.text.index("sel.first").split(".")[0])
            b = int(self.text.index("sel.last").split(".")[0])
            for n in range(a, b + 1):
                self.text.insert(f"{n}.0", "    ")
        else:
            self.text.insert("insert", "    ")
        return "break"

    def _untab(self, _e):
        a, b = (self.text.index("sel.first"), self.text.index("sel.last")) if self.text.tag_ranges("sel") \
            else (self.text.index("insert"), self.text.index("insert"))
        for n in range(int(a.split(".")[0]), int(b.split(".")[0]) + 1):
            head = self.text.get(f"{n}.0", f"{n}.4")
            k = len(head) - len(head.lstrip(" "))
            if k:
                self.text.delete(f"{n}.0", f"{n}.{k}")
        return "break"

    def _backspace(self, _e):
        if self.text.tag_ranges("sel"):
            return None
        before = self.text.get("insert linestart", "insert")
        if before and before.strip() == "" and len(before) % 4 == 0:  # delete a whole indent step
            self.text.delete("insert-4c", "insert")
            return "break"
        return None
