"""First-run helper for running Nexora from source: if a needed package is missing, show a small window with a
progress bar and install it with pip, instead of crashing with an import error.
The packaged .exe files already contain everything, so this does nothing there."""
import importlib.util
import subprocess
import sys

# import name -> pip name
REQUIRED = {"ursina": "ursina>=7.0", "websockets": "websockets>=12", "pypresence": "pypresence>=4.3"}


def missing(required=None) -> list:
    req = REQUIRED if required is None else required
    return [pip for mod, pip in req.items() if importlib.util.find_spec(mod) is None]


def ensure_dependencies(title="Nexora", required=None) -> bool:
    """Returns True when everything is installed (after installing it if needed)."""
    if getattr(sys, "frozen", False):
        return True
    todo = missing(required)
    if not todo:
        return True
    try:
        import tkinter as tk
        from tkinter import ttk
    except ImportError:  # no window possible: say what to do in the console
        print("Missing packages: " + ", ".join(todo) + "\nRun: " + sys.executable + " -m pip install " + " ".join(todo))
        return False
    root = tk.Tk()
    root.title(f"{title} - setting up")
    root.geometry("460x210")
    root.resizable(False, False)
    root.configure(bg="#0b0b14")
    tk.Label(root, text="Downloading dependencies", bg="#0b0b14", fg="#ecebff", font=("Segoe UI", 14, "bold")).pack(
        pady=(20, 4))
    status = tk.Label(root, text="Getting ready…", bg="#0b0b14", fg="#9a98c8", font=("Segoe UI", 10), wraplength=420)
    status.pack()
    bar = ttk.Progressbar(root, mode="determinate", length=400, maximum=len(todo) * 100)
    bar.pack(pady=14)
    note = tk.Label(root, text="This only happens the first time. It can take a few minutes.", bg="#0b0b14",
                    fg="#9a98c8", font=("Segoe UI", 9))
    note.pack()
    state = {"i": 0, "proc": None, "ok": True, "err": "", "done": False}

    def start_next():
        if state["i"] >= len(todo):
            state["done"] = True
            root.destroy()
            return
        pkg = todo[state["i"]]
        status.config(text=f"Installing {pkg} ({state['i'] + 1} of {len(todo)})…")
        try:
            state["proc"] = subprocess.Popen([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", pkg],
                                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        except OSError as e:
            fail(str(e))
            return
        root.after(150, poll)

    def poll():
        p = state["proc"]
        # nudge the bar while pip works (pip doesn't report a percentage), up to 90% of this package's share
        base = state["i"] * 100
        bar["value"] = min(base + 90, bar["value"] + 1.2) if bar["value"] >= base else base
        if p.poll() is None:
            root.after(150, poll)
            return
        out = p.stdout.read() if p.stdout else ""
        if p.returncode != 0:
            fail(out.strip().splitlines()[-1] if out.strip() else f"pip exited with code {p.returncode}")
            return
        state["i"] += 1
        bar["value"] = state["i"] * 100
        start_next()

    def fail(msg):
        state["ok"], state["err"] = False, msg
        status.config(text="Couldn't install: " + msg, fg="#ff5c7c")
        note.config(text="Check your internet connection and try again. Close this window to exit.")
        bar.stop()

    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.after(200, start_next)
    root.mainloop()
    return state["done"] and state["ok"]


def close_splash() -> None:
    """Hide the PyInstaller loading picture (only exists in the packaged one-file exe)."""
    try:
        import pyi_splash  # type: ignore[import-not-found]
        pyi_splash.close()
    except Exception:  # noqa: BLE001 - no splash, or it was already closed
        pass
