@echo off
title Build NexoraStudio.exe
cd /d "%~dp0"
echo Installing build tools...
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
  echo Install failed. Make sure Python 3.10+ is installed: https://python.org
  pause
  exit /b 1
)
echo.
echo Building NexoraStudio.exe (this takes a few minutes)...
python -m PyInstaller --noconfirm --clean --windowed --name NexoraStudio --icon assets\studio.ico ^
  --add-data "assets;assets" ^
  --hidden-import runner --hidden-import network --hidden-import games --hidden-import project ^
  --hidden-import version --hidden-import scripting --hidden-import viewport3d --hidden-import script_editor --hidden-import online --hidden-import websockets ^
  --collect-all ursina --collect-all panda3d --collect-all panda3d_gltf --collect-all panda3d_simplepbr ^
  studio.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Done: dist\NexoraStudio\NexoraStudio.exe  (keep the whole dist\NexoraStudio folder together)
pause
