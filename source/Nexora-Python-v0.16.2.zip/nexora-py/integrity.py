"""Quietly tells the server which Nexora files this copy has, so the server can notice a modified install.

Nothing is shown to the player and nothing is blocked: the app keeps working either way. Only the file hashes and the
version are sent (never file contents). The server compares them with the official release and, if they differ,
notifies staff. Staff accounts are ignored on the server. Set NEXORA_NO_INTEGRITY=1 to switch this off while developing.
"""
import hashlib
import os
from pathlib import Path

from version import VERSION

CODE_EXT = (".py", ".pyd", ".dll", ".so", ".pth")
_done = set()


def file_hashes(folder=None) -> dict:
    """sha256 of every code file next to this one (.py, .pyd, .dll, .so, .pth), line endings ignored so Windows and
    Linux copies match. A code file the release doesn't have counts as a change too."""
    folder = Path(folder or Path(__file__).resolve().parent)
    out = {}
    for p in sorted(folder.iterdir()):
        if p.suffix.lower() not in CODE_EXT or not p.is_file() or p.name == "make_manifest.py":
            continue
        try:
            out[p.name] = hashlib.sha256(p.read_bytes().replace(b"\r", b"")).hexdigest()
        except OSError:
            pass
    return out


def report(net, username) -> None:
    """Send the hashes once per run. Never raises, never shows anything."""
    if os.environ.get("NEXORA_NO_INTEGRITY") == "1" or username in _done:
        return
    _done.add(username)
    try:
        files = file_hashes()
        if not files:   # packaged build: no .py files to look at
            return
        net.request("POST", "/api/integrity", {"version": VERSION, "files": files})
    except Exception:   # noqa: BLE001 - this check must never get in the player's way
        pass


def report_game() -> None:
    """Same check when a game process starts (online games get the signed-in token from the launcher)."""
    token = os.environ.get("NEXORA_TOKEN", "")
    if not token:
        return
    try:
        import online
        net = online.Session()
        net.token = token
        report(net, "game")
    except Exception:   # noqa: BLE001
        pass
