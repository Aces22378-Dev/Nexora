"""Nexora multiplayer: a small relay server, LAN discovery and the client used by games.

Protocol: TCP, one JSON object per line.
  client -> server  {"t":"info"}                                   (server list / ping, then closes)
                    {"t":"join","v":1,"user":..,"avatar":{..}}
                    {"t":"state","p":[x,y,z],"r":rot,"w":walking}  (about 15x per second)
                    {"t":"chat","m":"hello"}
                    {"t":"bye"}
  server -> client  {"t":"info",...} | {"t":"deny","reason":..} | {"t":"welcome","id":..,"game":..,"players":[..]}
                    {"t":"joined","p":{..}} | {"t":"left","id":..} | {"t":"states","s":{"<id>":[x,y,z,rot,walk]}}
                    {"t":"chat","id":..,"user":..,"m":..}    (sent to everyone, including the sender)
Servers also answer a UDP discovery ping on the same port number, which is how the LAN list works.

The server relays positions only. Usernames are NOT verified between PCs yet.
"""
import asyncio
import json
import math
import queue
import random
import re
import socket
import threading
import time

import avatar as avatar_mod

PROTOCOL = 1
DEFAULT_PORT = 7777
PORT_RANGE = range(7777, 7788)  # ports the launcher scans / picks from
MAGIC = b"NEXORA_DISCOVER_V1"
TICK = 1 / 15

NAME_RE = re.compile(r"[A-Za-z0-9_]{3,20}")
HEX_RE = re.compile(r"#[0-9a-fA-F]{6}")
ADDR_RE = re.compile(r"([A-Za-z0-9_.\-]{1,100})(?::(\d{1,5}))?")


clean_avatar = avatar_mod.clean  # see avatar.py


def _coord(v, limit=5000.0):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ValueError("bad number")
    return max(-limit, min(limit, float(v)))


def parse_address(text: str, default_port: int = DEFAULT_PORT):
    """'host:port' or 'host' -> (host, port), or None if it isn't a valid address."""
    m = ADDR_RE.fullmatch((text or "").strip())
    if not m:
        return None
    port = int(m.group(2)) if m.group(2) else default_port
    return (m.group(1), port) if 1 <= port <= 65535 else None


CHAT_MAX = 120
CHAT_GAP = 0.6  # seconds between messages from one player


def clean_chat(text) -> str:
    """One line of chat: text only, no control characters, trimmed, at most CHAT_MAX characters."""
    if not isinstance(text, str):
        return ""
    return "".join(ch for ch in text if ch.isprintable()).strip()[:CHAT_MAX]


# ---------------------------------------------------------------- server
class GameServer:
    def __init__(self, game_id, name, max_players=8, port=DEFAULT_PORT, owner="", host="0.0.0.0"):
        self.game_id = game_id
        self.name = (name or "Nexora server")[:40]
        self.max_players = max(2, min(32, int(max_players)))
        self.port = int(port)
        self.owner = owner
        self.host = host
        self.players = {}
        self.next_id = 1
        self.token = "%08x" % random.getrandbits(32)

    def info(self) -> dict:
        return {"t": "info", "v": PROTOCOL, "id": self.token, "name": self.name, "game": self.game_id,
                "players": len(self.players), "max": self.max_players, "port": self.port, "owner": self.owner}

    @staticmethod
    def _line(obj) -> bytes:
        return (json.dumps(obj, separators=(",", ":")) + "\n").encode()

    @staticmethod
    def _pub(p) -> dict:
        return {"id": p["id"], "user": p["user"], "avatar": p["avatar"], "pos": p["pos"],
                "rot": p["rot"], "walk": p["walk"]}

    def _send(self, p, data: bytes):
        try:
            w = p["writer"]
            if w.transport.is_closing():
                return
            if w.transport.get_write_buffer_size() > 1_000_000:  # client can't keep up: drop it
                w.close()
                return
            w.write(data)
        except Exception:
            pass

    def _broadcast(self, obj, skip=None):
        data = self._line(obj)
        for pid, p in list(self.players.items()):
            if pid != skip:
                self._send(p, data)

    async def _handle(self, reader, writer):
        pid = None
        try:
            msg = json.loads(await asyncio.wait_for(reader.readline(), 5))
            if msg.get("t") == "info":
                writer.write(self._line(self.info()))
                await writer.drain()
                return
            reason = None
            user = str(msg.get("user", ""))
            if msg.get("t") != "join" or msg.get("v") != PROTOCOL:
                reason = "Version mismatch - update Nexora."
            elif not NAME_RE.fullmatch(user):
                reason = "Invalid username."
            elif any(p["user"].lower() == user.lower() for p in self.players.values()):
                reason = "That username is already in this server."
            elif len(self.players) >= self.max_players:
                reason = "Server is full."
            if reason:
                writer.write(self._line({"t": "deny", "reason": reason}))
                await writer.drain()
                return

            pid = self.next_id
            self.next_id += 1
            me = {"id": pid, "user": user, "avatar": clean_avatar(msg.get("avatar")),
                  "pos": [0.0, 0.0, 0.0], "rot": 0.0, "walk": False, "writer": writer}
            welcome = {"t": "welcome", "id": pid, "game": self.game_id, "name": self.name,
                       "max": self.max_players, "players": [self._pub(p) for p in self.players.values()]}
            self.players[pid] = me
            writer.write(self._line(welcome))
            self._broadcast({"t": "joined", "p": self._pub(me)}, skip=pid)
            print(f"[{self.name}] {user} joined ({len(self.players)}/{self.max_players})", flush=True)

            while True:
                line = await asyncio.wait_for(reader.readline(), 30)
                if not line:
                    break
                m = json.loads(line)
                t = m.get("t")
                if t == "state":
                    x, y, z = (_coord(v) for v in m["p"])
                    me["pos"] = [round(x, 2), round(y, 2), round(z, 2)]
                    me["rot"] = round(_coord(m.get("r", 0.0), 100000.0), 1)
                    me["walk"] = bool(m.get("w"))
                elif t == "chat":
                    text = clean_chat(m.get("m"))
                    now = time.monotonic()
                    if text and now - me.get("last_chat", 0.0) >= CHAT_GAP:  # too-fast messages are dropped
                        me["last_chat"] = now
                        self._broadcast({"t": "chat", "id": pid, "user": me["user"], "m": text})
                elif t == "bye":
                    break
        except Exception:
            pass  # bad data, timeout or disconnect: just drop this client
        finally:
            if pid in self.players:
                user = self.players.pop(pid)["user"]
                self._broadcast({"t": "left", "id": pid})
                print(f"[{self.name}] {user} left ({len(self.players)}/{self.max_players})", flush=True)
            try:
                writer.close()
            except Exception:
                pass

    async def _ticker(self):
        while True:
            await asyncio.sleep(TICK)
            if len(self.players) >= 2:
                self._broadcast({"t": "states", "s": {
                    str(pid): [*p["pos"], p["rot"], p["walk"]] for pid, p in self.players.items()}})

    async def serve(self):
        server = await asyncio.start_server(self._handle, self.host, self.port)
        outer = self

        class Discovery(asyncio.DatagramProtocol):
            def connection_made(self, transport):
                self.transport = transport

            def datagram_received(self, data, addr):
                if data.startswith(MAGIC):
                    self.transport.sendto(json.dumps(outer.info()).encode(), addr)

        try:
            await asyncio.get_running_loop().create_datagram_endpoint(Discovery, local_addr=(self.host, self.port))
        except OSError as e:
            print(f"LAN discovery unavailable: {e}", flush=True)
        asyncio.create_task(self._ticker())
        print(f"Nexora server '{self.name}' ({self.game_id}) listening on port {self.port}", flush=True)
        async with server:
            await server.serve_forever()


def run_server(game_id, name, max_players=8, port=DEFAULT_PORT, owner=""):
    try:
        asyncio.run(GameServer(game_id, name, max_players, port, owner).serve())
    except KeyboardInterrupt:
        pass


def find_free_port():
    """First port in PORT_RANGE that is free for both TCP and UDP, or None."""
    for port in PORT_RANGE:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as t, \
                    socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as u:
                t.bind(("0.0.0.0", port))
                u.bind(("0.0.0.0", port))
            return port
        except OSError:
            continue
    return None


# ---------------------------------------------------------------- finding servers (blocking: call from a thread)
def _local_broadcasts():
    out = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
        a, b, c, _ = ip.split(".")
        out.append(f"{a}.{b}.{c}.255")
    except OSError:
        pass
    return out


def discover_lan(timeout: float = 1.0, ports=PORT_RANGE) -> list:
    """Servers answering on this PC or the local network."""
    found = {}
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.2)
    except OSError:
        return []
    try:  # Windows reports "port unreachable" from earlier sends as a receive error; don't let that end the scan
        sock.ioctl(socket.SIO_UDP_CONNRESET, False)
    except (AttributeError, OSError, ValueError):
        pass
    try:
        for target in ["255.255.255.255", "127.0.0.1"] + _local_broadcasts():
            for port in ports:
                try:
                    sock.sendto(MAGIC, (target, port))
                except OSError:
                    pass
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except ConnectionResetError:
                continue  # an earlier datagram hit a closed port; keep listening
            except OSError:
                break
            try:
                info = json.loads(data)
            except ValueError:
                continue
            if not isinstance(info, dict) or info.get("t") != "info" or "id" not in info:
                continue
            old = found.get(info["id"])
            if old is None:
                info["host"] = addr[0]
                found[info["id"]] = info
            elif old["host"].startswith("127.") and not addr[0].startswith("127."):
                old["host"] = addr[0]  # prefer the address other PCs can use
    finally:
        sock.close()
    return list(found.values())


def query_server(host: str, port: int, timeout: float = 1.5):
    """Ask one server for its info. Returns the info dict, or None if it didn't answer."""
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall(b'{"t":"info"}\n')
            buf = b""
            while b"\n" not in buf and len(buf) < 65536:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf += chunk
        info = json.loads(buf.split(b"\n")[0])
        if isinstance(info, dict) and info.get("t") == "info":
            info["host"], info["port"] = host, port
            return info
    except (OSError, ValueError):
        pass
    return None


# ---------------------------------------------------------------- client (used inside a game)
class Client:
    def __init__(self, host, port, user, avatar):
        self.host, self.port, self.user, self.avatar = host, port, user, avatar
        self.sock = None
        self.file = None
        self.q = queue.Queue()
        self.closed = False
        self.id = None
        self.welcome = None
        self._lock = threading.Lock()

    def connect(self, timeout: float = 5.0):
        """Returns None on success, otherwise a message explaining why joining failed."""
        try:
            self.sock = socket.create_connection((self.host, self.port), timeout=timeout)
        except OSError as e:
            return f"Couldn't connect to {self.host}:{self.port} ({e.strerror or e})."
        try:
            self.sock.settimeout(timeout)
            self.file = self.sock.makefile("rb")
            self._send({"t": "join", "v": PROTOCOL, "user": self.user, "avatar": self.avatar})
            msg = json.loads(self.file.readline())
        except (OSError, ValueError):
            self.close()
            return "The server didn't answer properly."
        if msg.get("t") == "deny":
            self.close()
            return msg.get("reason", "The server refused the connection.")
        if msg.get("t") != "welcome":
            self.close()
            return "Unexpected reply from the server."
        self.welcome, self.id = msg, msg["id"]
        self.sock.settimeout(None)
        threading.Thread(target=self._reader, daemon=True).start()
        return None

    def _reader(self):
        try:
            for line in self.file:
                try:
                    self.q.put(json.loads(line))
                except ValueError:
                    pass
        except OSError:
            pass
        self.closed = True
        self.q.put({"t": "closed"})

    def _send(self, obj):
        data = (json.dumps(obj, separators=(",", ":")) + "\n").encode()
        with self._lock:
            self.sock.sendall(data)

    def send_state(self, pos, rot, walking):
        if self.closed:
            return
        try:
            self._send({"t": "state", "p": [round(float(v), 2) for v in pos], "r": round(float(rot), 1),
                        "w": bool(walking)})
        except OSError:
            self.closed = True

    def send_chat(self, text: str):
        text = clean_chat(text)
        if text and not self.closed:
            try:
                self._send({"t": "chat", "m": text})
            except OSError:
                self.closed = True

    def poll(self) -> list:
        out = []
        while True:
            try:
                out.append(self.q.get_nowait())
            except queue.Empty:
                return out

    def close(self):
        try:
            if self.sock and not self.closed:
                self._send({"t": "bye"})
        except OSError:
            pass
        self.closed = True
        for obj in (self.file, self.sock):
            try:
                if obj:
                    obj.close()
            except OSError:
                pass


class WSClient(Client):
    """Same as Client, but over a WebSocket to the Nexora online server. The server knows who you are from your
    token, so there is no username in the join message."""

    def __init__(self, url, user, avatar):
        super().__init__("", 0, user, avatar)
        self.url = url
        self.ws = None

    def connect(self, timeout: float = 10.0):
        try:
            from websockets.sync.client import connect
        except ImportError:
            return "Nexora needs the 'websockets' package for online play. Run: py -m pip install websockets"
        try:
            self.ws = connect(self.url, open_timeout=timeout, max_size=2 ** 20)
        except Exception as e:  # noqa: BLE001 - any failure to connect is shown as a message
            return f"Couldn't connect to the Nexora server ({e})."
        try:
            self._send({"t": "join", "v": PROTOCOL, "avatar": self.avatar})
            msg = json.loads(self.ws.recv(timeout=timeout))
        except Exception:  # noqa: BLE001
            self.close()
            return "The server didn't answer properly."
        if msg.get("t") == "deny":
            self.close()
            return msg.get("reason", "The server refused the connection.")
        if msg.get("t") != "welcome":
            self.close()
            return "Unexpected reply from the server."
        self.welcome, self.id = msg, msg["id"]
        threading.Thread(target=self._reader, daemon=True).start()
        return None

    def _reader(self):
        try:
            for raw in self.ws:
                try:
                    self.q.put(json.loads(raw))
                except ValueError:
                    pass
        except Exception:  # noqa: BLE001 - connection closed
            pass
        self.closed = True
        self.q.put({"t": "closed"})

    def _send(self, obj):
        with self._lock:
            try:
                self.ws.send(json.dumps(obj, separators=(",", ":")))
            except Exception as e:  # noqa: BLE001
                raise OSError(str(e)) from None

    def close(self):
        try:
            if self.ws and not self.closed:
                self._send({"t": "bye"})
        except OSError:
            pass
        self.closed = True
        try:
            if self.ws:
                self.ws.close()
        except Exception:  # noqa: BLE001
            pass
