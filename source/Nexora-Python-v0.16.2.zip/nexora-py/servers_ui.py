"""Servers page: browse (LAN + saved addresses), host, and join. Mixed into App in main.py."""
import subprocess
import sys
import threading
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor

import accounts
import network
import theme as th
import games as game_db
from widgets import ScrollFrame

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


class ServersMixin:
    # ---------- helpers ----------
    def online_blocked(self) -> bool:
        return accounts.parental_status(self.user["username"])["restrict_join"]

    def server_alive(self) -> bool:
        return bool(self.server_proc and self.server_proc.poll() is None)

    def stop_hosting(self):
        p, self.server_proc, self.server_info = self.server_proc, None, None
        if p and p.poll() is None:
            p.terminate()
            try:
                p.wait(2)
            except subprocess.TimeoutExpired:
                p.kill()

    # ---------- page ----------
    def page_servers(self):
        tk.Label(self.body, text="Servers", bg=th.BG, fg=th.TEXT, font=(th.FONT, 18, "bold")).pack(anchor="w")
        if self.online_blocked():
            tk.Label(self.body, text="Parental controls are on: online play is turned off for this account.",
                     bg=th.BG, fg=th.DIM, font=(th.FONT, 11)).pack(anchor="w", pady=12)
            return
        tk.Label(self.body, text="Servers on your network and the ones you've saved. Type in the search box to filter.",
                 bg=th.BG, fg=th.DIM, font=(th.FONT, 10)).pack(anchor="w", pady=(0, 8))
        bar = tk.Frame(self.body, bg=th.BG)
        bar.pack(fill="x", pady=(0, 8))
        self.button(bar, "Host a server", self.host_dialog, primary=True).pack(side="left")
        self.button(bar, "Join by address", self.join_dialog).pack(side="left", padx=8)
        self.button(bar, "Refresh", self.refresh_servers).pack(side="left")
        self.host_banner = tk.Frame(self.body, bg=th.BG)
        self.host_banner.pack(fill="x")
        self.srv_status = tk.Label(self.body, text="", bg=th.BG, fg=th.DIM, font=(th.FONT, 10))
        self.srv_status.pack(anchor="w", pady=(4, 0))
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True, pady=(4, 0))
        self.srv_host = sf.inner
        self.srv_rows = []
        self.draw_host_banner()
        self.refresh_servers()

    def draw_host_banner(self):
        for w in self.host_banner.winfo_children():
            w.destroy()
        if not self.server_alive():
            return
        i = self.server_info
        box = tk.Frame(self.host_banner, bg=th.PANEL, padx=12, pady=8, highlightthickness=1,
                       highlightbackground=th.ACCENT)
        box.pack(fill="x", pady=(0, 6))
        tk.Label(box, text=f"You're hosting \"{i['name']}\" on port {i['port']}. It keeps running until you stop it "
                           f"or close Nexora.", bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 10), wraplength=700,
                 justify="left").pack(side="left")
        self.button(box, "Stop server", lambda: (self.stop_hosting(), self.draw_host_banner(),
                                                 self.refresh_servers())).pack(side="right")

    # ---------- finding servers ----------
    def refresh_servers(self):
        self._srv_token = getattr(self, "_srv_token", 0) + 1
        token = self._srv_token
        saved = list(accounts.get_settings(self.user["username"])["saved_servers"])
        self.srv_status.configure(text="Looking for servers...")
        self._srv_result = None

        def work():
            rows = {}
            for info in network.discover_lan(1.0):
                rows[info["id"]] = dict(info, online=True, saved=False)
            with ThreadPoolExecutor(max_workers=8) as pool:
                futures = []
                for addr in saved:
                    host, port = network.parse_address(addr)
                    futures.append((addr, host, port, pool.submit(network.query_server, host, port, 1.2)))
                offline = []
                for addr, host, port, fut in futures:
                    info = fut.result()
                    if info:
                        prev = rows.get(info["id"])
                        if prev:
                            prev["saved"], prev["addr"] = True, addr
                        else:
                            rows[info["id"]] = dict(info, online=True, saved=True, addr=addr)
                    else:
                        offline.append({"t": "info", "id": "saved:" + addr, "name": addr, "game": "", "players": 0,
                                        "max": 0, "host": host, "port": port, "owner": "", "online": False,
                                        "saved": True, "addr": addr})
            self._srv_result = (token, list(rows.values()) + offline)

        threading.Thread(target=work, daemon=True).start()
        self.after(150, lambda: self._poll_servers(token))

    def _poll_servers(self, token):
        if token != self._srv_token or self.page != "servers":
            return
        if self._srv_result and self._srv_result[0] == token:
            self.srv_rows = self._srv_result[1]
            self.render_servers()
            return
        self.after(150, lambda: self._poll_servers(token))

    def render_servers(self):
        for w in self.srv_host.winfo_children():
            w.destroy()
        q = self.search_var.get().strip().lower()
        rows = [r for r in self.srv_rows
                if not q or q in r["name"].lower() or q in r.get("owner", "").lower()
                or q in (game_db.get_game(r["game"]) or {}).get("name", "").lower()]
        rows.sort(key=lambda r: (not r["online"], -r["players"], r["name"].lower()))
        live = sum(1 for r in rows if r["online"])
        if not self.srv_rows:
            self.srv_status.configure(text="No servers found. Host one, or use Join by address.")
        else:
            self.srv_status.configure(text=f"{live} server{'s' if live != 1 else ''} online")
        for r in rows:
            g = game_db.get_game(r["game"])
            row = tk.Frame(self.srv_host, bg=th.PANEL, padx=12, pady=10, highlightthickness=1,
                           highlightbackground=th.LINE)
            row.pack(fill="x", pady=4)
            tk.Label(row, text=g["emoji"] if g else "?", bg=g["thumb"] if g else th.PANEL2, fg="white",
                     font=("Segoe UI Emoji", 20), width=3).pack(side="left", padx=(0, 12))
            info = tk.Frame(row, bg=th.PANEL)
            info.pack(side="left", fill="x", expand=True)
            tk.Label(info, text=r["name"] + ("   (offline)" if not r["online"] else ""), bg=th.PANEL,
                     fg=th.TEXT if r["online"] else th.DIM, font=(th.FONT, 12, "bold"), anchor="w").pack(fill="x")
            sub = [g["name"] if g else "Unknown game"] if r["online"] else ["Saved address"]
            if r.get("owner"):
                sub.append("hosted by " + r["owner"])
            if r["online"]:
                sub.append(f"{r['host']}:{r['port']}")
            if r.get("saved") and r["online"]:
                sub.append("saved")
            tk.Label(info, text="  ·  ".join(sub), bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9), anchor="w").pack(fill="x")
            if r.get("saved"):
                self.button(row, "Forget", lambda a=r["addr"]: self.forget_server(a)).pack(side="right", padx=(6, 0))
            if r["online"]:
                full = r["players"] >= r["max"]
                self.button(row, "Full" if full else "Join",
                            (lambda r=r: self.launch(r["game"], join=(r["host"], r["port"]))) if not full else (lambda: None),
                            primary=not full).pack(side="right", padx=6)
                tk.Label(row, text=f"{r['players']}/{r['max']}", bg=th.PANEL, fg=th.CYAN,
                         font=(th.FONT, 12, "bold")).pack(side="right", padx=8)

    def forget_server(self, addr):
        cur = [a for a in accounts.get_settings(self.user["username"])["saved_servers"] if a != addr]
        accounts.set_settings(self.user["username"], {"saved_servers": cur})
        self.refresh_servers()

    # ---------- dialogs ----------
    def _dialog(self, title, w=420, h=300):
        win = tk.Toplevel(self)
        win.title(title)
        win.configure(bg=th.PANEL, padx=22, pady=18)
        win.geometry(f"{w}x{h}")
        win.transient(self)
        win.grab_set()
        return win

    def _lbl(self, parent, text, dim=False, bold=False, **kw):
        return tk.Label(parent, text=text, bg=th.PANEL, fg=th.DIM if dim else th.TEXT, anchor="w", justify="left",
                        font=(th.FONT, 10 if dim else 11, "bold" if bold else "normal"), **kw)

    def host_dialog(self):
        if self.server_alive():
            self.set_status("You're already hosting a server. Stop it first.")
            return
        win = self._dialog("Host a server", 460, 400)
        self._lbl(win, "Game", bold=True).pack(fill="x")
        all_g = game_db.all_games()
        game_var = tk.StringVar(value=all_g[0]["name"])
        om = tk.OptionMenu(win, game_var, *[g["name"] for g in all_g])
        om.configure(bg=th.PANEL2, fg=th.TEXT, activebackground=th.PANEL2, activeforeground=th.TEXT,
                     highlightthickness=0, relief="flat", font=(th.FONT, 11))
        om["menu"].configure(bg=th.PANEL2, fg=th.TEXT)
        om.pack(fill="x", pady=(2, 10))
        self._lbl(win, "Server name", bold=True).pack(fill="x")
        name = self.entry(win)
        name.insert(0, f"{self.user['username']}'s server")
        name.pack(fill="x", ipady=6, pady=(2, 10))
        self._lbl(win, "Max players (2-32)", bold=True).pack(fill="x")
        maxv = tk.StringVar(value="8")
        sp = tk.Spinbox(win, from_=2, to=32, textvariable=maxv, width=6, bg=th.BG, fg=th.TEXT,
                        insertbackground=th.TEXT, buttonbackground=th.PANEL2, relief="flat", font=(th.FONT, 12))
        sp.pack(anchor="w", pady=(2, 10), ipady=4)
        self._lbl(win, "Anyone on your network sees it in the list. For friends elsewhere, forward the port shown "
                       "after starting (TCP and UDP) and send them your IP:port. Windows may ask to allow Nexora "
                       "through the firewall.", dim=True, wraplength=410).pack(fill="x")
        err = tk.Label(win, text="", bg=th.PANEL, fg=th.DANGER, font=(th.FONT, 10), anchor="w")
        err.pack(fill="x", pady=(6, 0))

        def go():
            try:
                n = int(maxv.get())
                if not 2 <= n <= 32:
                    raise ValueError
            except ValueError:
                err.configure(text="Max players must be a number from 2 to 32.")
                return
            title = name.get().strip()
            if not title:
                err.configure(text="Give the server a name.")
                return
            gid = next(g["id"] for g in all_g if g["name"] == game_var.get())
            win.destroy()
            self.start_hosting(gid, title, n)

        self.button(win, "Start and play", go, primary=True).pack(side="bottom", fill="x")

    def join_dialog(self):
        win = self._dialog("Join by address", 440, 250)
        self._lbl(win, "Server address (IP or name, optionally :port)", bold=True).pack(fill="x")
        addr = self.entry(win)
        addr.pack(fill="x", ipady=6, pady=(2, 8))
        addr.insert(0, "127.0.0.1:%d" % network.DEFAULT_PORT)
        addr.focus_set()
        save = tk.BooleanVar(value=True)
        tk.Checkbutton(win, text="Save to my server list", variable=save, bg=th.PANEL, fg=th.TEXT,
                       selectcolor=th.PANEL2, activebackground=th.PANEL, activeforeground=th.TEXT,
                       font=(th.FONT, 10)).pack(anchor="w")
        err = tk.Label(win, text="", bg=th.PANEL, fg=th.DANGER, font=(th.FONT, 10), anchor="w")
        err.pack(fill="x", pady=4)

        def go(_e=None):
            parsed = network.parse_address(addr.get())
            if not parsed:
                err.configure(text="That doesn't look like a valid address.")
                return
            host, port = parsed
            if save.get():
                cur = accounts.get_settings(self.user["username"])["saved_servers"]
                entry = f"{host}:{port}"
                if entry not in cur:
                    accounts.set_settings(self.user["username"], {"saved_servers": cur + [entry]})
            win.destroy()
            self.launch("", join=(host, port))

        addr.bind("<Return>", go)
        self.button(win, "Join", go, primary=True).pack(side="bottom", fill="x")

    # ---------- hosting ----------
    def start_hosting(self, game_id, name, max_players):
        if self.online_blocked():
            self.set_status("Parental controls: online play is turned off.")
            return
        if self.proc and self.proc.poll() is None:
            self.set_status("A game is already running.")
            return
        port = network.find_free_port()
        if port is None:
            self.set_status(f"No free port in {network.PORT_RANGE.start}-{network.PORT_RANGE.stop - 1}. "
                            f"Stop another server first.")
            return
        cmd = self.self_cmd() + ["--serve", game_id, "--name", name, "--max", str(max_players),
                                 "--port", str(port), "--owner", self.user["username"]]
        try:
            self.server_proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                                stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
        except OSError as e:
            self.set_status(f"Couldn't start the server: {e.strerror or e}")
            return
        self.server_info = {"name": name, "port": port, "game": game_id}
        self.set_status("Starting server...")
        self._wait_host(port, game_id, 0)

    def _wait_host(self, port, game_id, tries):
        if not self.server_alive():
            self.server_proc = self.server_info = None
            self.set_status("The server stopped right after starting. Try again.")
            return
        if network.query_server("127.0.0.1", port, timeout=0.3):
            self.launch(game_id, join=("127.0.0.1", port))
            if self.page == "servers":
                self.draw_host_banner()
            return
        if tries >= 24:
            self.stop_hosting()
            self.set_status("The server didn't start in time. Try again.")
            return
        self.after(250, lambda: self._wait_host(port, game_id, tries + 1))
