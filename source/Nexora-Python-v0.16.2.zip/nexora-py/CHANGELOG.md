# Changelog

All notable changes to Nexora and Nexora Studio are recorded in this file.
The format follows Keep a Changelog, and each entry is grouped as
**Added**, **Changed**, **Fixed**, **Removed** or **Security**.

**Status: alpha.** The project has not yet been tested on a physical Windows PC, against the live Cloudflare
deployment, or against the live Discord client. Items marked **Server** require the Cloudflare Worker to be redeployed.

Versions are listed newest first. `version.py` and this file are updated together for every release.

---

## 0.16.2

### Added
- **Client checks** tab on the admin page: every modified-client check the server received and what it decided (clean,
  modified and reported, ignored because the account is staff or the version is not in the manifest, and so on), plus a
  button that sends a real test message to both Discord webhooks and shows what Discord answered. Failed webhook
  posts are now written to the server log.
- **Server:** the Cloudflare Worker only (`index.js`, `admin.js`, `admin_page.js`).

---

## 0.16.1

### Changed
- The modified-client check also runs when an online game starts, not only when the launcher signs in. A copy that
  starts a game directly (without the launcher sign-in) is now checked too.

---

## 0.16.0

### Added
- **Live updates in the launcher:** while signed in to the server, the launcher refreshes itself every 20 seconds
  without restarting or changing pages.
  - The staff announcement banner appears, changes and disappears as staff post or clear it.
  - The games list picks up newly published and removed games.
  - Accounts deleted on the server are removed from People and from friend lists on this PC. Only local copies of
    server accounts are removed. Accounts that exist only on this PC are never touched.
  - An account that was banned or deleted is signed out with the ban reason shown on the sign-in screen.
- **Server:** `POST /api/users/exist` (Worker and Python server) tells the launcher which usernames still exist.

### Changed
- **Discord report formats.** Modified-client reports read `Modified client: <user>` and `Version: Nexora <version>`.
  Moderation posts list Punishment, Moderator, Affected, Reason and Notes, for example:
  `Punishment: Account Deletion`, `Moderator: Aces22378`, `Affected: <user>`, `Reason: Hackin`,
  `Notes: (0 games removed)`. Announcements are recorded in the admin log only.
- Moderation actions on the admin page take an optional reason, which is included in the Discord post.
- Banning no longer ends the player's saved sessions. Every request is refused while the ban lasts, and lifting the
  ban restores access without signing in again.

---

## 0.15.1

### Changed
- Moderation actions and modified-client reports now use separate Discord webhooks, so each can post to its own
  channel: `NEXORA_MOD_WEBHOOK` for moderation actions and `NEXORA_TAMPER_WEBHOOK` for modified-client reports. The
  earlier fallback from the moderation webhook to the modified-client webhook was removed. Without
  `NEXORA_MOD_WEBHOOK`, moderation actions are logged on the admin page only.

---

## 0.15.0

### Added
- **Staff admin page** at `/admin` on the Nexora server (mobile friendly, staff sign-in required). Actions: ban, timed
  ban and unban; mute (timed or permanent) and unmute; kick from a live server; give or take Nexei; delete an account;
  post a launcher announcement; list active bans and mutes; and an audit log of every action. Staff accounts cannot be
  moderated.
  - Banned players cannot sign in, existing sessions are ended, and they are removed from live servers. Muted players
    can still play but their chat messages are not delivered (the server enforces it).
  - Moderation actions are posted to a staff Discord channel through the secret `NEXORA_MOD_WEBHOOK`.
- **Announcement banner** in the launcher while a staff announcement is active.
- **Delete my account** for online accounts (Settings > Danger zone), confirmed with the password. It removes the
  account, its published games and its purchases. Items the player created stay in the shop under a neutral name.
  Staff accounts cannot be deleted this way.
- Sign-in error messages for banned accounts state the reason and the end of the ban.
- **Server:** the Cloudflare Worker only (`index.js`, `admin.js`, `admin_page.js`, `room.js`). The tables it needs are
  created automatically. The Python reference server does not include these tools.

---

## 0.14.4

### Changed
- **Modified-client detection** also reports an extra code file (`.py`, `.pyd`, `.dll`, `.so` or `.pth`) placed in the
  Nexora folder, in addition to changed files. Other file types, such as images, are not checked.
  - **Server:** `index.js` (Worker) and `nexora_server.py`.

---

## 0.14.3

### Changed
- The sign-up form now states the username rules ("3-20 letters, numbers or underscores. No spaces.") and rejects an
  invalid username immediately with a clear message, before contacting the server.

---

## 0.14.2

### Fixed
- Sign-in and sign-up error messages were cut off on both sides (for example "Username must be 3-20 letters, numbers or
  underscores."). Messages now wrap onto a second line.

---

## 0.14.1

### Added
- **Modified-client detection:** after sign-in, the launcher sends the version and a SHA-256 hash of each of its Python
  files to the server (no file contents). The server compares them with the official release and, if they differ,
  posts the username and version to a staff Discord channel through a webhook. The check is silent: it does not warn,
  block or sign out the player, and the server always gives the same response.
  - Staff accounts are ignored. Each player is reported at most once per version per week. Extra files added to the
    folder are not treated as a modification. Versions without a recorded manifest are ignored.
  - The webhook URL is stored as the server secret `NEXORA_TAMPER_WEBHOOK` and never ships with the app.
  - `make_manifest.py` records the official hashes for a release. It must be run after `version.py` is updated and
    before packaging.
  - Packaged executables contain no `.py` files, so they are not checked yet. `NEXORA_NO_INTEGRITY=1` disables the
    check for development.
  - **Server:** `index.js` and `manifest.json` (Worker), `nexora_server.py` and `integrity_manifest.json` (Python).

---

## 0.14.0

### Added
- **Favorites:** a star on every game card and a Favorite button on the game page. Favorited games appear in a
  Favorites section at the top of the Games page.
- **Continue:** the three most recently played games appear in a Continue section above Favorites.
- **Recommended:** a section below Favorites. Games are ranked by likes, plays and players online, with a boost for
  creators of games the player has favorited or played. Games already shown above are excluded.
- The Games page now scrolls to accommodate the additional sections.

### Changed
- Favorites and recently played games are stored per account in the account settings. They are not yet synchronised
  between computers.

---

## 0.13.0

### Added
- **Part shapes:** Cylinder, Cone and Wedge (ramp), in addition to Box and Sphere. Available from the Insert menu, the
  toolbar and the Shape property. Rendered in Studio and in games with mesh collision. Scripts can create them with
  `spawn_part(shape="cylinder")`.
- **World settings** (Edit > Game settings > World): fog density and fog colour, gravity, walk speed and jump height.
  Stored in the game file and applied for every player.
- **Studio settings tab** (toolbar gear button or Edit > Studio settings): field of view, orbit, zoom and fly speed,
  inverted orbit, ground grid visibility and spacing, default snap increment and autosave interval. Settings are stored
  per user, not per game, and open in a tab rather than a separate window.

### Changed
- **Studio viewport performance:** part geometry is calculated once and reused while the camera moves, distant spheres
  use fewer faces, and faces outside the view are skipped. Measured frame time with 150 parts decreased from about
  131 ms to 37 ms.
- **Server:** game validation (`project.js`) accepts the new shapes and the world settings.

---

## 0.12.0

### Added
- **In-game menu:** a Menu button in the top-left corner, also opened with Esc. Pages: Resume, Players, Settings (mouse
  sensitivity and field of view, persisted) and Leave game. The game continues to run while the menu is open. Holding
  Alt releases the mouse cursor so that the button can be clicked.
- **Badges in the player list:** the Verified or Staff icon is shown beside each name in the top-right list and on the
  menu's Players page.

### Changed
- Esc opens the menu instead of leaving the game immediately.
- The title, score and health bar are positioned below the Menu button.

---

## 0.11.1

### Added
- The signed-in user's own Staff badge is displayed even when the badge list cannot be retrieved from the server.

### Changed
- **Clothing textures in games:** if the primary method of building a shirt or pants texture fails, two fallback methods
  are attempted (a Panda3D image, then a temporary PNG file). The failure reason is written to the error output instead
  of silently falling back to the plain colour.

---

## 0.11.0

### Added
- **Verified and Staff badges** displayed beside usernames. Staff is the higher rank: a user holding both badges is shown
  with the Staff badge only.
  - Locations: launcher top bar, People, profiles, game cards and pages (owner and developers), Shop creator lines,
    in-game name tags and in-game chat (`[Staff]` / `[Verified]` prefix).
  - Staff status follows the staff list. Verified status follows `NEXORA_VERIFIED` (comma-separated; default
    `Aces22378,Ivy`). The combined list is public at `GET /api/badges`.
  - **Server:** `index.js` and `nexora_server.py` expose the endpoint.
  - Nexora Studio does not display badges yet.

### Fixed
- The 0.10.2 package contained an empty `version.py`, which prevented Nexora Studio from starting.

---

## 0.10.2

### Added
- **Owned Accessories tab** in the Shop. Owned accessories are listed there, with Wear and Take off actions, and are no
  longer shown in the other Shop lists.
- **Body options** on the Avatar page: male or female body, height and width (85% to 115%), a size reset and a custom
  skin colour picker.
  - The female body has a slimmer torso and arms, eyelashes and coloured lips.
  - Height and width scale the full avatar from the feet, including accessories, in the launcher and in 3D games.
  - **Server:** values are validated and clamped (`avatar.js`, `avatar.py`).

---

## 0.10.1

### Changed
- **Headless** costs 31,000 Nexei.
- **Legless** is a single bundle costing 17,000 Nexei. Purchasing it grants a Left and a Right leg item.
  - The leg items have no price, cannot be purchased individually, and appear in the Shop only after the bundle is
    owned (labelled "Included with Legless").
  - Only one leg item can be worn at a time. Wearing one replaces the other. The server enforces this rule.
  - The bundle itself cannot be worn.
- Servers using the previous default prices (200 and 100) migrate automatically. Prices changed manually in the database
  are preserved, and existing owners of the earlier separate leg items keep them.
- **Server:** `index.js` and `avatar.js`.

---

## 0.10.0

### Added
- **Headless and Legless** cosmetic items (appearance only, no gameplay effect), sold by Nexora.
  - Headless removes the head. Legless (Left) and Legless (Right) each remove one leg ("left" is the avatar's own left
    as seen from behind).
  - Accessories remain in place, and pants textures remain on the visible leg.
  - Shown in the launcher preview, in 3D games and to other players in the room. Walking animation is unaffected.
  - Only staff can create body items. The official items are created automatically.
  - **Server:** `index.js` and `avatar.js`.

---

## 0.9.4

### Added
- **Extended Discord presence:** two lines of text, a player count and two buttons ("Get Nexora" and "Join our Discord").
  - Nexora: "Browsing games", then the game name with "On an online server" (including the player count, refreshed every
    20 seconds), "On a server" (LAN) or "Playing alone".
  - Studio: "Choosing a project", "Editing <project>" and "Testing <project>".
  - Large images require the `nexora_logo` and `studio_logo` assets to be uploaded to each Discord application.

---

## 0.9.3

### Changed
- Discord presence includes the Application IDs for Nexora and Nexora Studio, so no setup is required (Discord desktop
  app running, activity sharing enabled).

---

## 0.9.2

### Added
- **Discord Rich Presence** (`discordrpc.py`): "Playing Nexora" and "Playing Nexora Studio" with an elapsed timer.
  Reconnects automatically when Discord starts or restarts. Disabled with `NEXORA_NO_DISCORD=1`. Adds the `pypresence`
  dependency. Verified against a simulated Discord connection only.

---

## 0.9.1

### Added
- **Grid toggle** in the Workshop picture editor. With the grid off, the picture is shown exactly as it will appear. The
  setting persists when switching between Front and Sleeves.

---

## 0.9.0

### Added
- **Sleeves:** shirts have a second 16 x 32 picture for the sleeves, edited in the Workshop's Shirt tab. Displayed in the
  launcher and in 3D games.
- Editor tools: Fill, Pick colour and right-click erase. Import PNG / JPG fits the image to the selected part.

### Changed
- Shirt and pants pictures are 32 x 32 pixels (previously 8 x 8) with up to 16 colours (previously 8). Existing 8 x 8
  items remain supported.
- **Server:** every picture's size and palette are re-validated, and sleeves are accepted only from an owned shirt
  (`index.js`, `avatar.js`).

### Known limitations
- The same sleeve picture is used on both arms.
- Pictures cannot yet be applied to the back or sides of the torso, and the two legs cannot show different pictures.

---

## 0.8.0

### Added
- **3D model accessories:** import OBJ, STL, PLY, GLB and glTF files in the Workshop. Models can be rotated, scaled and
  positioned, and can be combined with boxes. File colours are preserved (up to 8). Models above 1,000 triangles are
  simplified automatically. Textures, animation and bones are ignored. Staff review models before sale.
- **PNG / JPG import** for shirts and pants. PNG transparency is preserved.

### Changed
- **Fixed official server:** Nexora and Studio always connect to the official server, and the "Server..." button was
  removed. Developers can override this with `NEXORA_ALLOW_SERVER_CHANGE=1` or `NEXORA_SERVER`. This is an application
  setting only. Ownership and permissions are enforced by the server.
- Worker `schema.sql` no longer contains `--` comments, so it can be pasted into the Cloudflare D1 console.
- **Server:** point and triangle limits, numeric validity and coordinate bounds are checked for every model.

### Removed
- Accessory presets (Top hat, Cap, Glasses, Backpack, Scarf).

---

## 0.7.1

### Added
- **Cloudflare Worker server** (`worker/`): a port of the online server to Workers, D1 and Durable Objects, covering
  accounts, games, likes, Nexei, the Shop, Workshop review, gamepasses, live rooms and chat. Tested locally against the
  same test suites as the Python server. Not deployed to Cloudflare as part of this release.
- The Python server and the Worker can share a single D1 database (the Python server accepts the Worker's password
  hashes).

### Changed
- Published games larger than about 1.8 MB are rejected on the Worker (D1 row-size limit).

---

## 0.7.0

### Added
- **Workshop:** any user can design shirts and pants (base colour and pixel picture) or accessories (up to 8 coloured
  boxes) and sell them for Nexei. The creator receives 70% of each sale.
- **Review queue:** items from non-staff users require staff approval (Shop > Review). Staff items are published
  immediately.
- Shop tabs (Shirts, Pants, Accessories, My items, Review), Wear / Take off actions and avatar previews.
- Pictures and accessories are displayed in the launcher and in 3D games for all players in the room.

### Changed
- **Server:** the worn appearance is resolved from the account and the user's purchases rather than from the game client,
  so unowned items cannot be worn.

### Known limitations
- No automated moderation beyond staff review, and no trading.

---

## 0.6.1

### Added
- Optional **Cloudflare D1 backup** for the online server (`d1_mirror.py`), so that accounts, Nexei, purchases, games and
  likes survive restarts on free hosting. Configured with `CF_ACCOUNT_ID`, `CF_D1_DATABASE_ID` and `CF_API_TOKEN`.
  Disabled by default.

### Fixed
- Studio: adding a gamepass no longer crashes the dialog's background thread.

---

## 0.6.0

### Added
- **Nexei:** the in-app currency, with a wallet in the top bar and a new Shop page.
- Free daily claim of 100 Nexei every 24 hours. There is no real-money purchase of Nexei.
- **Clothing:** staff add shirts and pants to the Shop. The server permits only free colours or owned items.
- **Gamepasses:** creators and developers add passes in Studio (Game settings > Gamepasses). Players purchase them on the
  game's page and the creator receives 70%. Scripts check ownership with `player.has_pass("Name")`.
- **Staff accounts** (Aces22378, Ivy) have unlimited Nexei. Their names can be registered only with the server's staff
  code.

### Changed
- The Shop requires an online server, because purchases are stored and validated server-side.

---

## 0.5.3

### Added
- Single-file builds: `build_exe_onefile.bat` (`dist\Nexora.exe`) and `build_studio_exe_onefile.bat`
  (`dist\NexoraStudio.exe`), including in the GitHub workflow.
- Splash image while the executable starts.
- A "Downloading dependencies" window with a progress bar when running from source and packages are missing.

### Known limitations
- A single-file executable unpacks itself on every start, so launching a game is slower than with the folder build.

---

## 0.5.2

### Added
- Nexora Studio logo and icon (window, sign-in screen and `NexoraStudio.exe`).

---

## 0.5.1

### Added
- This changelog and `version.py`. Studio's Help > About displays the version.

---

## 0.5.0

### Added
- **Health:** `player.health`, `max_health`, `regen`, `damage(n)`, `heal(n)`, `alive` and the `on_died(player)` event.
  A player at 0 health respawns at the spawn point, and a health bar is shown while damaged.
- GitHub workflow (`.github/workflows/build.yml`) that builds `Nexora.exe` and `NexoraStudio.exe` on Windows.

### Fixed
- Studio 3D view: parts standing on large flat parts (such as the baseplate) are no longer hidden or jagged. Draw order
  uses true distance and smaller tiles.

---

## 0.4.0

### Added
- **Online server** (`nexora_server.py`): accounts, game publishing, likes, play counts, live rooms and chat. Players join
  a server with free space or a new one is created, and names come from the account.
- Game page: thumbnails, description, plays, likes, live servers, Like and Play.
- Studio online sign-in, publishing, and thumbnails captured from the 3D view.
- Render deployment files (`Dockerfile`, `render.yaml`).

### Changed
- Scripts from other creators are disabled by default (Settings > Gameplay).

---

## 0.3.0

### Added
- Studio requires sign-in. Games have an owner and developers, and only they can open or publish the game.
- [DEV] badge beside owners and developers (player list, name tags and chat).
- In-game text chat with a permission setting (everyone, friends or off).

### Fixed
- Studio visual issues (borders, labels and size checks).

---

## 0.2.0

### Added
- **Nexora Studio** as a separate application: 3D editor (select, move, scale and rotate, with snapping), Explorer,
  Properties, Python script editor, Play Test, Publish and undo/redo. Scripts are written in Python.

---

## 0.1.0

### Added
- Nexora launcher: accounts, games, servers (host, join and LAN discovery), people and friends, avatars, settings
  (11 categories) and parental controls. Third-person games built on Ursina.
