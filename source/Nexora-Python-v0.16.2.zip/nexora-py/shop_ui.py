"""Nexei: the wallet in the top bar, the Shop page (clothing, free daily Nexei) and gamepasses on a game's page.
Everything is checked by the server; this file only shows it and asks."""
import tkinter as tk

import accounts
import badges
import avatar as av_mod
import online
import theme as th
from widgets import ScrollFrame, draw_avatar

COIN = "◈"


class ShopMixin:
    wallet = None  # last wallet the server told us about

    # ------------------------------------------------------------ wallet label
    def wallet_text(self) -> str:
        return f"{COIN} " + (online.nexei_text(self.wallet) if self.wallet else "…")

    def refresh_wallet(self):
        if not self.online_ready():
            return

        def done(w, err):
            if w:
                self.set_wallet(w)
        self.bg(lambda: self.net.wallet(), done)

    def set_wallet(self, w):
        self.wallet = w
        for name in ("wallet_lbl", "shop_wallet"):
            lbl = getattr(self, name, None)
            try:
                if lbl is not None and lbl.winfo_exists():
                    lbl.configure(text=self.wallet_text())
            except tk.TclError:
                pass

    # ------------------------------------------------------------ Shop page
    FILTERS = (("all", "All"), ("shirt", "Shirts"), ("pants", "Pants"), ("acc", "Accessories"), ("owned", "Owned Accessories"), ("mine", "My items"))

    def page_shop(self):
        tk.Label(self.body, text="Shop", bg=th.BG, fg=th.TEXT, font=(th.FONT, 18, "bold")).pack(anchor="w")
        if not self.online_ready():
            tk.Label(self.body, text="The Shop needs the Nexora server, and you are not connected to it. Sign in again.",
                     bg=th.BG, fg=th.DIM, font=(th.FONT, 11)).pack(anchor="w", pady=10)
            return
        self.shop_filter = getattr(self, "shop_filter", "all")
        self.shop_items = []
        top = tk.Frame(self.body, bg=th.BG)
        top.pack(fill="x", pady=(2, 10))
        self.shop_wallet = tk.Label(top, text=self.wallet_text(), bg=th.BG, fg=th.CYAN, font=(th.FONT, 14, "bold"))
        self.shop_wallet.pack(side="left")
        self.daily_btn = self.button(top, "Claim free Nexei", self.claim_daily)
        self.daily_btn.pack(side="left", padx=16)
        self.button(top, "✎  Workshop: make clothing", self.open_workshop, primary=True).pack(side="left", padx=(16, 0))
        self.shop_msg = tk.Label(self.body, text="", bg=th.BG, fg=th.CYAN, font=(th.FONT, 10), anchor="w")
        self.shop_msg.pack(fill="x")
        tk.Label(self.body, text="Nexei is the currency of Nexora. You can't buy it with real money yet: claim free "
                                 "Nexei once a day, and earn it when people buy your gamepasses and clothing.",
                 bg=th.BG, fg=th.DIM, font=(th.FONT, 10), anchor="w", justify="left", wraplength=800).pack(fill="x")
        self.filter_row = tk.Frame(self.body, bg=th.BG)
        self.filter_row.pack(fill="x", pady=(10, 0))
        sf = ScrollFrame(self.body)
        sf.pack(fill="both", expand=True, pady=(8, 0))
        self.shop_host = sf.inner
        self.draw_filters()
        self.load_shop()
        self.refresh_wallet_for_shop()

    def is_staff(self) -> bool:
        return bool(self.wallet and self.wallet.get("infinite"))

    def draw_filters(self):
        for w in self.filter_row.winfo_children():
            w.destroy()
        pending = sum(1 for i in getattr(self, "review_items", []))
        filters = list(self.FILTERS) + ([("review", f"Review ({pending})")] if self.is_staff() else [])
        for key, label in filters:
            on = key == self.shop_filter
            tk.Button(self.filter_row, text=label, relief="flat", bd=0, cursor="hand2", font=(th.FONT, 10, "bold"),
                      padx=12, pady=5, bg=th.PANEL2 if on else th.BG, fg=th.TEXT if on else th.DIM,
                      activebackground=th.PANEL2, activeforeground=th.TEXT,
                      command=lambda k=key: self.set_filter(k)).pack(side="left", padx=(0, 4))

    def set_filter(self, key):
        self.shop_filter = key
        self.draw_filters()
        self.render_shop()

    def open_workshop(self):
        from workshop_ui import Workshop
        Workshop(self, on_done=self.load_shop)

    def refresh_wallet_for_shop(self):
        def done(w, err):
            if w and getattr(self, "page", "") == "shop":
                had = self.is_staff()
                self.set_wallet(w)
                self.update_daily_button()
                if self.is_staff() != had:
                    self.draw_filters()
                    self.load_shop()
        self.bg(lambda: self.net.wallet(), done)

    def update_daily_button(self):
        w, b = self.wallet or {}, getattr(self, "daily_btn", None)
        try:
            if b is None or not b.winfo_exists():
                return
            if w.get("infinite"):
                b.pack_forget()
            elif w.get("daily_in", 0) > 0:
                b.configure(state="disabled", text=f"Free Nexei in {w['daily_in'] // 3600}h {w['daily_in'] % 3600 // 60}m")
            else:
                b.configure(state="normal", text=f"Claim {w.get('daily', 100)} free Nexei")
        except tk.TclError:
            pass

    def claim_daily(self):
        def done(w, err):
            if err:
                self.shop_msg.configure(text=err, fg=th.DANGER)
                return
            self.set_wallet(w)
            self.update_daily_button()
            self.shop_msg.configure(text="Claimed! Come back tomorrow for more.", fg=th.CYAN)
        self.bg(lambda: self.net.daily(), done)

    def load_shop(self):
        def work():
            items = self.net.shop()
            review = self.net.review_list() if self.is_staff() else []
            return items, review

        def done(res, err):
            if getattr(self, "page", "") != "shop":
                return
            if err:
                self.shop_msg.configure(text=err, fg=th.DANGER)
                return
            self.shop_items, self.review_items = res
            self.draw_filters()
            self.render_shop()
        self.bg(work, done)

    def item_preview(self, it) -> dict:
        look = av_mod.clean(self.user["avatar"])
        if it["kind"] in ("shirt", "pants"):
            look[it["kind"]] = it["color"]
            look[it["kind"] + "_tex"] = it.get("tex")
            if it["kind"] == "shirt":
                look["sleeve_tex"] = av_mod.clean_sleeve(it.get("sleeve"))
        elif it.get("acc"):
            a = av_mod.clean_acc({"slot": it["acc"]["slot"], "boxes": it["acc"].get("boxes"), "mesh": it["acc"].get("mesh")})
            look["acc"] = [x for x in look["acc"] if a and x["slot"] != a["slot"]] + ([a] if a else [])
        return look

    def worn_ids(self) -> set:
        look = av_mod.clean(self.user["avatar"])
        return {look["shirt_item"], look["pants_item"], *[a["id"] for a in look["acc"]]} - {None}

    def render_shop(self):
        host = getattr(self, "shop_host", None)
        if host is None or not host.winfo_exists():
            return
        for w in host.winfo_children():
            w.destroy()
        f = self.shop_filter
        if f == "review":
            items = self.review_items
        elif f == "mine":
            items = [i for i in self.shop_items if i["mine"]]
        elif f == "owned":   # accessories you own live here, not in the shop lists
            items = [i for i in self.shop_items if i["kind"] == "acc" and i["owned"] and i["status"] == "approved"]
        elif f == "all":
            items = [i for i in self.shop_items if i["status"] == "approved" and not (i["kind"] == "acc" and i["owned"])]
        else:
            items = [i for i in self.shop_items if i["kind"] == f and i["status"] == "approved"
                     and not (f == "acc" and i["owned"])]
        if not items:
            tk.Label(host, text={"mine": "You haven't made anything yet. Press Workshop above!",
                                 "review": "Nothing is waiting for review.",
                                 "owned": "You don't own any accessories yet."}.get(f, "Nothing here yet."),
                     bg=th.BG, fg=th.DIM, font=(th.FONT, 11)).pack(anchor="w", pady=10)
        worn, staff = self.worn_ids(), self.is_staff()
        for it in items:
            row = tk.Frame(host, bg=th.PANEL, padx=12, pady=8, highlightthickness=1, highlightbackground=th.LINE)
            row.pack(fill="x", pady=4)
            c = tk.Canvas(row, width=34, height=68, bg=th.PANEL, highlightthickness=0)
            c.pack(side="left")
            draw_avatar(c, self.item_preview(it), s=2, ox=1, oy=2, top=4)
            info = tk.Frame(row, bg=th.PANEL)
            info.pack(side="left", padx=12)
            tk.Label(info, text=it["name"], bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 12, "bold"), anchor="w").pack(fill="x")
            kind = {"acc": "Accessory"}.get(it["kind"], it["kind"].title())
            extra = {"pending": "  ·  waiting for review", "rejected": "  ·  not approved"}.get(it["status"], "")
            cost = "Included with Legless" if it.get("hidden") else f"{COIN} {it['price']:,} Nexei"
            by = it["creator"] or "Nexora"
            badges.name_row(info, by, th.PANEL, th.DIM, (th.FONT, 10), prefix=f"{kind}  ·  {cost}  ·  by ",
                            suffix=extra, anchor="w")
            if f == "review":
                self.button(row, "Reject", lambda i=it: self.review_item(i, False)).pack(side="right", padx=4)
                self.button(row, "Approve", lambda i=it: self.review_item(i, True), primary=True).pack(side="right", padx=4)
                continue
            if staff or it["mine"]:
                self.button(row, "Remove", lambda i=it: self.remove_item(i)).pack(side="right", padx=4)
            if it["status"] != "approved":
                continue
            if it.get("bundle"):   # a bundle hands out its parts: nothing to wear on the bundle itself
                if it["owned"]:
                    tk.Label(row, text="Owned", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 10, "bold")).pack(side="right", padx=8)
                else:
                    self.button(row, "Buy", lambda i=it: self.buy_item(i), primary=True).pack(side="right", padx=4)
                continue
            if it["owned"]:
                if it["id"] in worn:
                    self.button(row, "Take off", lambda i=it: self.wear(i, False)).pack(side="right", padx=4)
                else:
                    self.button(row, "Wear", lambda i=it: self.wear(i, True), primary=True).pack(side="right", padx=4)
            else:
                self.button(row, "Buy", lambda i=it: self.buy_item(i), primary=True).pack(side="right", padx=4)

    def buy_item(self, it):
        def done(res, err):
            if err:
                self.set_msg(err, True)
                return
            self.set_wallet(res["wallet"])
            self.set_msg(f"You got {it['name']}!", False)
            if getattr(self, "page", "") == "shop":
                self.load_shop()
            elif getattr(self, "page", "") == "game":
                self.load_passes()
        self.bg(lambda: self.net.buy(it["id"]), done)

    def set_msg(self, text, bad):
        for name in ("shop_msg", "d_msg"):
            lbl = getattr(self, name, None)
            try:
                if lbl is not None and lbl.winfo_exists():
                    lbl.configure(text=text, fg=th.DANGER if bad else th.CYAN)
            except tk.TclError:
                pass

    def wear(self, it, on=True):
        """Put an item on (or take it off). The server decides what you may wear and sends back your new look."""
        cur = av_mod.clean(self.user["avatar"])
        req = {"skin": cur["skin"], "shirt": cur["shirt"], "pants": cur["pants"], "shirt_item": cur["shirt_item"],
               "pants_item": cur["pants_item"], "acc": [{"id": a["id"]} for a in cur["acc"]]}
        if it["kind"] in ("shirt", "pants"):
            req[it["kind"] + "_item"] = it["id"] if on else None
            if not on:
                req[it["kind"]] = av_mod.DEFAULT[it["kind"]]
        else:
            req["acc"] = [a for a in req["acc"] if a["id"] != it["id"]]
            if on:
                slot = (it.get("acc") or {}).get("slot")
                req["acc"] = [a for a in req["acc"] if next((x["slot"] for x in cur["acc"] if x["id"] == a["id"]), None) != slot]
                req["acc"].append({"id": it["id"]})
                if slot in av_mod.LEG_SLOTS:   # one leg item at a time
                    leg_ids = {x["id"] for x in cur["acc"] if x["slot"] in av_mod.LEG_SLOTS}
                    req["acc"] = [a for a in req["acc"] if a["id"] not in leg_ids or a["id"] == it["id"]]

        def done(res, err):
            if err:
                self.shop_msg.configure(text=err, fg=th.DANGER)
                return
            out = accounts.set_avatar(self.user["username"], res)
            if out["ok"]:
                self.user = out["user"]
            self.shop_msg.configure(text=f"Now wearing {it['name']}." if on else f"Took off {it['name']}.", fg=th.CYAN)
            self.render_shop()
        self.bg(lambda: self.net.set_avatar(req), done)

    def remove_item(self, it):
        def done(_r, err):
            if err:
                self.shop_msg.configure(text=err, fg=th.DANGER)
            else:
                self.load_shop()
        self.bg(lambda: self.net.remove_item(it["id"]), done)

    def review_item(self, it, approve):
        def done(_r, err):
            self.shop_msg.configure(text=err or f"{'Approved' if approve else 'Rejected'}: {it['name']}",
                                    fg=th.DANGER if err else th.CYAN)
            self.load_shop()
        self.bg(lambda: self.net.review(it["id"], approve), done)

    # ------------------------------------------------------------ gamepasses on a game's page
    def build_passes_box(self, parent):
        tk.Label(parent, text="GAMEPASSES", bg=th.BG, fg=th.DIM, font=(th.FONT, 9, "bold"), anchor="w").pack(
            fill="x", pady=(16, 4))
        self.d_passes = tk.Frame(parent, bg=th.BG)
        self.d_passes.pack(fill="x")
        if self.online_ready() and self.detail.get("official") is not True and self.detail["id"] not in ("plaza", "skyrun"):
            self.load_passes()

    def load_passes(self):
        gid = self.detail["id"]

        def done(res, err):
            if getattr(self, "page", "") != "game" or self.detail["id"] != gid or err:
                return
            self.render_passes(res["passes"])
        self.bg(lambda: self.net.passes(gid), done)

    def render_passes(self, passes):
        for w in self.d_passes.winfo_children():
            w.destroy()
        if not passes:
            tk.Label(self.d_passes, text="This game has no gamepasses.", bg=th.BG, fg=th.DIM,
                     font=(th.FONT, 10)).pack(anchor="w")
        for p in passes:
            row = tk.Frame(self.d_passes, bg=th.PANEL, padx=12, pady=8, highlightthickness=1,
                           highlightbackground=th.LINE)
            row.pack(fill="x", pady=3)
            info = tk.Frame(row, bg=th.PANEL)
            info.pack(side="left")
            tk.Label(info, text=p["name"], bg=th.PANEL, fg=th.TEXT, font=(th.FONT, 11, "bold"), anchor="w").pack(fill="x")
            if p["desc"]:
                tk.Label(info, text=p["desc"], bg=th.PANEL, fg=th.DIM, font=(th.FONT, 9), anchor="w", justify="left",
                         wraplength=300).pack(fill="x")
            if p["owned"]:
                tk.Label(row, text="✔ Owned", bg=th.PANEL, fg=th.CYAN, font=(th.FONT, 10, "bold")).pack(side="right")
            else:
                self.button(row, f"{COIN} {p['price']:,}", lambda p=p: self.buy_item(p)).pack(side="right")
