@echo off
title Build Nexora.exe (single file)
cd /d "%~dp0"
echo Installing build tools...
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
  echo Install failed. Make sure Python 3.10+ is installed: https://python.org
  pause
  exit /b 1
)
echo.
echo Building a single Nexora.exe (a few minutes, needs ~5 GB free disk)...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name Nexora --icon assets\icon.ico ^
  --splash assets\splash.png ^
  --add-data "assets;assets" ^
  --hidden-import bootstrap --hidden-import runner --hidden-import network --hidden-import servers_ui --hidden-import settings_ui --hidden-import online_ui --hidden-import online --hidden-import websockets --hidden-import games --hidden-import project --hidden-import scripting ^
  --collect-all ursina --collect-all panda3d --collect-all panda3d_gltf --collect-all panda3d_simplepbr ^
  main.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Done: dist\Nexora.exe  (one file - you can move it anywhere)
pause
