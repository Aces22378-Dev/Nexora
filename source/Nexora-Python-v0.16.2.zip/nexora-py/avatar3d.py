"""The 3D avatar: a blocky character from cubes, with shirt/pants pictures and accessory boxes (see avatar.py)."""
from ursina import Entity, color

from avatar import hidden_slots
from meshshade import mesh_shades


tex_cache = {}

def _pixel_texture(im):
    """A small RGB picture as a crisp (nearest-neighbour) ursina Texture. Tries three ways, because which one works
    depends on the ursina / Panda3D / Pillow versions: the picture itself, a Panda3D image, a temporary PNG file."""
    from ursina import Texture
    errors = []
    for how in ("pil", "panda", "file"):
        try:
            if how == "pil":
                tx = Texture(im)
            elif how == "panda":
                from panda3d.core import PNMImage, Texture as PandaTexture
                w, h = im.size
                pn = PNMImage(w, h, 3)
                for y in range(h):
                    for x in range(w):
                        r, g, b = im.getpixel((x, y))
                        pn.setXel(x, y, r / 255, g / 255, b / 255)
                pt = PandaTexture()
                pt.load(pn)
                tx = Texture(pt)
            else:
                import os
                import tempfile
                path = os.path.join(tempfile.gettempdir(), f"nexora_tex_{os.getpid()}_{len(tex_cache)}.png")
                im.save(path)
                tx = Texture(path)
            tx.filtering = None  # nearest: keep the pixels sharp
            return tx
        except Exception as e:  # noqa: BLE001
            errors.append(f"{how}: {type(e).__name__}: {e}")
    import sys
    print("Nexora: couldn't make a clothing texture (" + "; ".join(errors) + ")", file=sys.stderr)
    return None


def avatar_texture(t, base):
    """A picture (drawn over the garment colour) as a crisp pixel texture. None if it can't be made."""
    key = (t["px"], tuple(t["pal"]), base)
    if key not in tex_cache:
        try:
            import avatar as av
            from PIL import Image
            w, h = (av.TEX_SIZES | av.SLEEVE_SIZES)[len(t["px"])]
            rgb = lambda h_: tuple(int(h_[i:i + 2], 16) for i in (1, 3, 5))  # noqa: E731
            im = Image.new("RGB", (w, h), rgb(base))
            for i, ch in enumerate(t["px"]):
                if ch != ".":
                    im.putpixel((i % w, i // w), rgb(t["pal"][av.PAL_CHARS.index(ch)]))
            tex_cache[key] = _pixel_texture(im)
        except Exception as e:  # noqa: BLE001 - a picture that fails to load just shows the plain colour
            import sys
            print(f"Nexora: clothing picture failed ({type(e).__name__}: {e})", file=sys.stderr)
            tex_cache[key] = None
    return tex_cache[key]


def mesh_entity(parent, m):
    """An imported 3D accessory as one flat-shaded entity (two-sided, so a model with flipped faces still shows)."""
    from ursina import Mesh, Vec3
    verts, cols = [], []
    for p, q, r, c in mesh_shades(m):
        for pt in (p, q, r):
            verts.append(Vec3(*pt))
            cols.append(color.rgb(*c))
    e = Entity(parent=parent, model=Mesh(vertices=verts, colors=cols, mode="triangle", static=True))
    e.double_sided = True
    return e


def build_avatar(parent, look):
    """Blocky character from cubes, feet at y=0, front facing +z. Returns (legs, arms) for animation.
    Height and width (Body section of the avatar editor) scale everything from the feet up; the female body has a
    slimmer torso and arms, lashes and pink lips."""
    skin, shirt, pants = (color.hex(look[k]) for k in ("skin", "shirt", "pants"))
    female = look.get("body") == "female"
    parent = Entity(parent=parent, scale=(look.get("width") or 1.0, look.get("height") or 1.0, look.get("width") or 1.0))
    tw = 0.7 if female else 0.8                  # torso width
    aw, ax0 = (0.26, 0.5) if female else (0.3, 0.58)   # arm thickness and distance from the middle
    Entity(parent=parent, model="cube", color=shirt, position=(0, 1.2, 0), scale=(tw, 0.8, 0.4))
    st = look.get("shirt_tex") and avatar_texture(look["shirt_tex"], look["shirt"])
    if st:
        Entity(parent=parent, model="quad", texture=st, color=color.white, position=(0, 1.2, 0.202),
               scale=(-tw, 0.8))
    hidden = hidden_slots(look.get("acc"))   # "Headless" / "Legless" items take a part away
    if "nohead" not in hidden:
        Entity(parent=parent, model="cube", color=skin, position=(0, 1.85, 0), scale=(0.5, 0.5, 0.5))
        for ex in (-0.12, 0.12):
            Entity(parent=parent, model="cube", color=color.black, position=(ex, 1.9, 0.26),
                   scale=(0.07, 0.07, 0.02))
            if female:
                Entity(parent=parent, model="cube", color=color.black, position=(ex, 1.96, 0.26),
                       scale=(0.1, 0.02, 0.02))
        if female:
            Entity(parent=parent, model="cube", color=color.hex("#d6567a"), position=(0, 1.72, 0.26),
                   scale=(0.14, 0.03, 0.02))
    pt = look.get("pants_tex") and avatar_texture(look["pants_tex"], look["pants"])
    legs, arms = [], []
    for lx in (-0.2, 0.2):
        hip = Entity(parent=parent, position=(lx, 0.8, 0))
        if ("noleftleg" if lx < 0 else "norightleg") in hidden:
            legs.append(hip)  # the leg is gone, but the (empty) hip stays so walking animation code still works
            continue
        Entity(parent=hip, model="cube", color=pants, y=-0.4, scale=(0.38, 0.8, 0.38))
        if pt:  # the picture runs across both legs: the viewer's left leg (+x) shows its left half
            q = Entity(parent=hip, model="quad", texture=pt, color=color.white, y=-0.4, z=0.192,
                       scale=(-0.38, 0.8))
            q.texture_scale = (0.5, 1)
            q.texture_offset = (0.0 if lx > 0 else 0.5, 0)
        legs.append(hip)
    sl = look.get("sleeve_tex") and avatar_texture(look["sleeve_tex"], look["shirt"])
    for ax in (-ax0, ax0):
        shoulder = Entity(parent=parent, position=(ax, 1.55, 0))
        Entity(parent=shoulder, model="cube", color=shirt, y=-0.3, scale=(aw, 0.6, aw))
        Entity(parent=shoulder, model="cube", color=skin, y=-0.7, scale=(aw, 0.2, aw))
        if sl:  # the sleeve picture on the front of the arm (the same picture on both arms)
            Entity(parent=shoulder, model="quad", texture=sl, color=color.white, y=-0.3, z=aw / 2 + 0.002, scale=(-aw, 0.6))
        arms.append(shoulder)
    for a in look.get("acc") or []:  # accessories: little boxes placed relative to the feet
        for b in a["boxes"]:
            Entity(parent=parent, model="cube", color=color.hex(b["c"]), position=tuple(b["p"]), scale=tuple(b["s"]))
        if a.get("mesh"):
            mesh_entity(parent, a["mesh"])
    return legs, arms

