"""3D game runner (Ursina / Panda3D), third person, single player or online.
Started by main.py as: main.py --play <id> --user <name> [--join host:port] [--project file.json]

Lines printed to stdout (script print() output and script errors) are shown in Nexora Studio's Output window."""
import copy
import math
import json
import os
import sys

import accounts
import games
import network
import project as pj
import scripting
import avatar3d
import badges


def emit(text: str) -> None:
    """Script output and errors. Goes to the console, and to the file Studio is watching (NEXORA_LOG), because a
    packaged windowed .exe has no console to print to."""
    try:
        print(text, flush=True)
    except (OSError, ValueError):
        pass  # nobody is listening (no console): that's fine
    log = os.environ.get("NEXORA_LOG")
    if log:
        try:
            with open(log, "a", encoding="utf-8") as f:
                f.write(str(text).replace("\n", " \u23ce ") + "\n")
        except OSError:
            pass


def fail(msg: str, code: int = 2):
    """Leave without opening a window; the launcher shows `msg`."""
    emit("ERROR " + msg)
    accounts.set_last_error(msg)
    sys.exit(code)


def run(game_id: str, username: str, join=None, project_path=None, room=None, allow_scripts=True) -> None:
    try:  # gamepasses this player owns in this game (the launcher looks them up); "*" = all (Studio play test)
        _p = json.loads(os.environ.get("NEXORA_PASSES", "[]"))
        PASSES = "*" if _p == "*" else {str(x) for x in _p} if isinstance(_p, list) else set()
    except ValueError:
        PASSES = set()
    cfg = accounts.get_settings(username)
    me = accounts.get_user(username)
    av = me["user"]["avatar"] if me["ok"] else dict(accounts.DEFAULT_AVATAR)
    preview = bool(project_path) and not room  # a Studio test run doesn't count as a play

    # ---- connect before any window opens, so a refusal never flashes a game screen ----
    client = None
    if join:
        client = network.Client(join[0], join[1], username, av)
        err = client.connect()
        if err:
            fail(err)
        game_id = client.welcome["game"]
    if room:  # a room on the Nexora online server: the account token comes from the launcher's environment
        import online
        client = network.WSClient(online.ws_url(f"/ws/{room}") + "?token=" + os.environ.get("NEXORA_TOKEN", ""),
                                  username, av)
        err = client.connect()
        if err:
            fail(err)
        game_id = client.welcome["game"]
    if project_path:
        try:
            gdef = pj.to_game(pj.Project.load(project_path).to_dict())
        except (OSError, ValueError) as e:
            fail(f"Couldn't open the game: {e}")
    else:
        gdef = games.get_game(game_id)
        if gdef is None:
            if client:
                client.close()
            fail("That game isn't on this PC. Nexora can't download games from servers yet.")
    game_id = gdef["id"]
    if room and not allow_scripts and gdef.get("scripts"):
        gdef = dict(gdef, scripts=[])
        emit("Scripts in this game are turned off (Settings > Gameplay > Run scripts from other creators).")

    from ursina import (Button, Entity, Text, Ursina, Vec2, Vec3, application, camera, color, destroy, held_keys, raycast,
                        scene, window, time as utime)
    from ursina.prefabs.first_person_controller import FirstPersonController
    from ursina.prefabs.input_field import InputField
    from ursina import mouse, invoke

    app = Ursina(title=f"Nexora - {gdef['name']}", borderless=False, development_mode=False,
                 fullscreen=cfg["fullscreen"], vsync=cfg["vsync"])
    import bootstrap
    bootstrap.close_splash()  # the window exists now: hide the loading picture of the packaged exe
    window.color = color.hex(gdef["sky"])
    wd = gdef.get("world") or {}   # world settings from Studio (Game settings)
    if wd.get("fog"):   # things fade into the fog colour with distance
        try:
            from ursina.shaders import unlit_with_fog_shader as fog_shader
            fog_shader = getattr(fog_shader, "unlit_with_fog_shader", fog_shader)   # some versions give the module
            Entity.default_shader = fog_shader
        except Exception as e:  # noqa: BLE001 - no fog shader here: the game just has no fog
            emit(f"Fog isn't available on this PC ({type(e).__name__}).")
        fog_col = color.hex(wd.get("fog_color") or gdef["sky"])
        fog_far = 20 + (1 - wd["fog"]) * 380   # fog setting 0..1 -> the distance where things are fully lost in the fog
        fog_near = fog_far * 0.15
        scene.fog_color = fog_col
        scene.fog_density = (fog_near, fog_far)
    window.exit_button.visible = False
    window.fps_counter.enabled = False  # Ursina's own counter only exists in its developer UI; we draw ours

    # ---------- world: one Ursina entity per part ----------
    world = {}  # part id -> {"rec": dict, "ent": Entity}

    def apply_collider(w):
        rec, ent = w["rec"], w["ent"]
        if rec["collide"] and rec["kind"] != "coin":
            ent.collider = {"sphere": "sphere", "box": "box"}.get(rec["shape"], "mesh")
        else:
            ent.collider = None

    shape_models = {}

    def shape_model(name):
        if name not in shape_models:
            import shapes
            from ursina import Mesh
            v, t, n = shapes.mesh_data(name)
            shape_models[name] = Mesh(vertices=v, triangles=t, normals=n, mode="triangle")
        return shape_models[name]

    def make_part(rec):
        sh = rec["shape"]
        if sh in ("box", "sphere"):
            model, tex = ("sphere", None) if sh == "sphere" else ("cube", "white_cube")
        else:   # cylinder, cone, wedge: built from the shared flat faces in shapes.py
            model, tex = shape_model(sh), None
        ent = Entity(model=model, texture=tex,
                     color=color.hex(rec["color"]), position=tuple(rec["pos"]), scale=tuple(rec["size"]),
                     rotation_y=rec["rot_y"], visible=rec.get("visible", True))
        if wd.get("fog"):   # Ursina only gives fog to things that exist when it is set, so set it on each part
            try:
                ent.set_shader_input("fog_color", fog_col)
                ent.set_shader_input("fog_start", fog_near)
                ent.set_shader_input("fog_end", fog_far)
            except Exception:  # noqa: BLE001
                pass
        w = {"rec": rec, "ent": ent, "inside": False}
        apply_collider(w)
        world[rec["id"]] = w
        return w

    recs = [copy.deepcopy(p) for p in gdef["parts"]]
    for rec in recs:
        make_part(rec)
    total_coins = sum(1 for r in recs if r["kind"] == "coin")

    build_avatar = avatar3d.build_avatar

    def animate(legs, arms, swing):
        legs[0].rotation_x, legs[1].rotation_x = swing, -swing
        arms[0].rotation_x, arms[1].rotation_x = -swing, swing

    # ---------- local player ----------
    sx, sy, sz = gdef["spawn"]
    walk_speed = wd.get("walk_speed", 9)
    player = FirstPersonController(position=(sx, sy, sz), speed=walk_speed, jump_height=wd.get("jump_height", 2.2))
    player.gravity = wd.get("gravity", 1.0)
    if getattr(player, "cursor", None):
        player.cursor.enabled = False
    player.mouse_sensitivity = Vec2(40 * cfg["mouse_sens"] / 50 * (-1 if cfg["invert_y"] else 1),
                                    40 * cfg["mouse_sens"] / 50)
    camera.fov = cfg["fov"]
    pivot = player.camera_pivot
    _player_input = player.input

    def player_input(key):  # no jumping while typing a chat message
        if not state["typing"] and not menu["open"]:
            _player_input(key)
    player.input = player_input
    pivot.y = 1.8
    pivot.rotation_x = 15
    checkpoint = Vec3(sx, sy, sz)
    my_legs, my_arms = build_avatar(player, av)

    # ---------- other players ----------
    remotes = {}  # id -> dict(root, legs, arms, label, target, rot, walk, user)

    dev_names = {n.lower() for n in [gdef.get("owner", ""), *gdef.get("devs", [])] if n}

    def disp(name: str) -> str:
        """Name as shown in the game. Owners and developers of this game get a [DEV] badge."""
        return ("<cyan>[DEV]<default> " + name) if name.lower() in dev_names else name

    if room:   # who has a Verified / Staff badge (best effort: no answer means no badges)
        badges.load(timeout=3)
    for pair in filter(None, os.environ.get("NEXORA_TEST_BADGES", "").split(",")):   # dev/test only: "name:staff,..."
        n_, k_ = pair.split(":")
        badges._map[n_.lower()] = k_
    badge_tex = {}

    def badge_texture(k):
        if k not in badge_tex:
            try:
                from PIL import Image
                from ursina import Texture
                badge_tex[k] = Texture(Image.open(badges._asset(f"assets/badge_{k}_128.png")))
            except Exception:
                badge_tex[k] = None
        return badge_tex[k]

    def chat_tag(name: str) -> str:
        return {"staff": "<yellow>[Staff]<default> ", "verified": "<cyan>[Verified]<default> "}.get(badges.kind(name), "")

    def hidden(name: str) -> bool:
        return accounts.blocked_between(username, name)

    def add_remote(info):
        if info["id"] in remotes or (client and info["id"] == client.id):
            return
        if hidden(info["user"]):
            remotes[info["id"]] = {"hidden": True, "user": info["user"]}
            return
        root = Entity(position=tuple(info["pos"]))
        legs, arms = build_avatar(root, network.clean_avatar(info["avatar"]))
        label = Text(disp(info["user"]), parent=scene, scale=9, billboard=True, origin=(0, 0), color=color.white)
        bk = badges.kind(info["user"])
        icon = None
        if bk and badge_texture(bk):   # the badge floats just above the name
            icon = Entity(parent=scene, model="quad", texture=badge_texture(bk), billboard=True, scale=0.42,
                          position=(root.x, root.y + 2.95, root.z))
        remotes[info["id"]] = {"root": root, "legs": legs, "arms": arms, "label": label, "user": info["user"], "icon": icon,
                               "target": Vec3(*info["pos"]), "rot": info["rot"], "walk": info["walk"],
                               "phase": 0.0}

    def drop_remote(pid):
        r = remotes.pop(pid, None)
        if r and not r.get("hidden"):
            destroy(r["root"])
            destroy(r["label"])
            if r.get("icon"):
                destroy(r["icon"])

    # ---------- HUD ----------
    state = {"score": 0, "score_used": False, "coins_taken": 0, "finished": False, "msg_until": 0.0, "t": 0.0,
             "cam": float(cfg["cam_distance"]), "walk": 0.0, "last": Vec3(sx, sy, sz), "list_open": True,
             "hp": {"health": 100.0, "max_health": 100.0, "regen": 1.0}, "dead_until": 0.0, "send": 0.0, "frame": 0, "closing": 0.0, "touch_t": 0.0, "touchable": []}
    online = client is not None
    max_players = client.welcome.get("max", 0) if online else 1

    top_left = (-0.5, 0.5)
    title_text = Text(client.welcome["name"] if online else gdef["name"], origin=top_left, scale=1.6,
                      color=color.white)
    score_text = Text("", origin=top_left, scale=1.3, color=color.cyan)
    msg_text = Text("", origin=(0, 0), position=(0, 0.25), scale=2.5, color=color.white)
    help_text = Text("WASD move | Space jump | Scroll zoom | Tab players | " +
                     ("Enter chat | " if online and cfg.get("chat", "everyone") != "off" else "") + "Esc menu | Hold Alt for the mouse", origin=(-0.5, -0.5),
                     scale=1, color=color.white)
    hp_back = Entity(parent=camera.ui, model="quad", color=color.black66, origin=(-0.5, 0.5), scale=(0.25, 0.024),
                     enabled=False)
    hp_fill = Entity(parent=camera.ui, model="quad", color=color.lime, origin=(-0.5, 0.5), scale=(0.25, 0.02),
                     enabled=False, z=-0.01)
    hp_text = Text("", origin=(0, 0), scale=0.9, color=color.white, enabled=False, z=-0.02)
    list_bg = Entity(parent=camera.ui, model="quad", color=color.black66, origin=(0.5, 0.5), scale=(0.3, 0.1))
    list_rows = Entity(parent=camera.ui)   # the Players list: one Text per row, so a badge picture can sit on its row
    fps_text = Text("", origin=(0.5, 0.5), scale=1.1, color=color.yellow, enabled=cfg["show_fps"])
    state["fps_t"] = 0.0
    state["fps_n"] = 0
    state["list_w"] = 0.3
    state["aspect"] = 0.0

    # ---------- chat (online only) ----------
    chat_mode = cfg.get("chat", "everyone") if online else "off"
    chat_lines = []  # (time, text)
    chat_text = Text("", origin=(-0.5, -0.5), scale=1.1, color=color.white)
    chat_field = InputField(default_value="", character_limit=network.CHAT_MAX, active=False, scale_x=0.7,
                            enabled=False, z=-1)
    chat_field.submit_on = ["enter"]
    state.update(typing=False, chat_closed=-9.0)

    def esc_chat(s: str) -> str:
        return s.replace("<", "\u2039").replace(">", "\u203a")  # so nobody can inject colour tags

    def show_chat(now=None):
        now = state["t"] if now is None else now
        keep = chat_lines[-8:] if state["typing"] else [l for l in chat_lines[-8:] if now - l[0] < 12]
        chat_text.text = "\n".join(l[1] for l in keep)

    def add_chat(user: str, text: str):
        if chat_mode == "off" or hidden(user):
            return
        if user != username and chat_mode == "friends" and not accounts.is_friend(username, user):
            return
        chat_lines.append((state["t"], f"{chat_tag(user)}{disp(user)}: {esc_chat(text)}"))
        del chat_lines[:-30]
        show_chat()

    def open_chat():
        if state["typing"] or chat_mode == "off" or not online:
            return
        state["typing"] = True
        chat_field.text = ""
        chat_field.enabled = True
        chat_field.active = True
        mouse.locked = False
        mouse.visible = False
        player.speed = 0
        player.mouse_sensitivity = Vec2(0, 0)
        show_chat()

    def close_chat():
        if not state["typing"]:
            return
        state["typing"] = False
        state["chat_closed"] = state["t"]
        chat_field.active = False
        chat_field.enabled = False
        player.speed = walk_speed
        player.mouse_sensitivity = Vec2(40 * cfg["mouse_sens"] / 50 * (-1 if cfg["invert_y"] else 1),
                                        40 * cfg["mouse_sens"] / 50)
        mouse.locked = True
        show_chat()

    def submit_chat():
        text = chat_field.text.strip()
        if text and client:
            client.send_chat(text)
        close_chat()

    chat_field.on_submit = submit_chat

    # ---------- in-game menu: the Menu button (top left) or Esc ----------
    menu = {"open": False, "page": "main"}
    menu_btn = Button(text="Menu", parent=camera.ui, scale=(0.12, 0.05), origin=(-0.5, 0.5), color=color.black66,
                      highlight_color=color.gray, z=-1)
    menu_root = Entity(parent=camera.ui, enabled=False, z=-5)
    Entity(parent=menu_root, model="quad", color=color.rgba(0, 0, 0, 0.6), scale=(4, 3))
    Entity(parent=menu_root, model="quad", color=color.hex("#141426"), scale=(0.64, 0.74))
    menu_title = Text("Menu", parent=menu_root, origin=(0, 0), position=(0, 0.31, -0.2), scale=2, color=color.white)
    menu_pages = {k: Entity(parent=menu_root, z=-0.1) for k in ("main", "players", "settings")}

    def mbutton(page, text, y, cmd, col=None, w=0.42):
        return Button(text=text, parent=menu_pages[page], scale=(w, 0.07), position=(0, y), on_click=cmd,
                      color=col or color.hex("#28284a"), highlight_color=color.hex("#463c82"), z=-0.1)

    def menu_goto(page):
        menu["page"] = page
        for k, e in menu_pages.items():
            e.enabled = k == page
        menu_title.text = {"main": "Menu", "players": "Players", "settings": "Settings"}[page]

    def look_settings():
        player.mouse_sensitivity = Vec2(40 * cfg["mouse_sens"] / 50 * (-1 if cfg["invert_y"] else 1),
                                        40 * cfg["mouse_sens"] / 50)
        camera.fov = cfg["fov"]

    def free_mouse():
        player.speed = 0
        player.mouse_sensitivity = Vec2(0, 0)
        mouse.locked = False
        mouse.visible = True

    def grab_mouse():
        player.speed = walk_speed
        look_settings()
        mouse.locked = True
        mouse.visible = False

    def open_menu():
        if menu["open"] or state["typing"]:
            return
        menu["open"] = True
        menu_goto("main")
        menu_root.enabled = True
        free_mouse()

    def close_menu():
        if not menu["open"]:
            return
        menu["open"] = False
        menu_root.enabled = False
        grab_mouse()

    mbutton("main", "Resume", 0.17, close_menu)
    mbutton("main", "Players", 0.08, lambda: menu_goto("players"))
    mbutton("main", "Settings", -0.01, lambda: menu_goto("settings"))
    mbutton("main", "Leave game", -0.2, lambda: finish(), col=color.hex("#782832"))
    menu_rows = Entity(parent=menu_pages["players"], position=(-0.27, 0.25), z=-0.1)
    mbutton("players", "Back", -0.31, lambda: menu_goto("main"))

    def refresh_menu_players(names):
        shown = names[:14]
        head = f"Players ({len(names)}/{max_players})" if online else f"Players ({len(names)})"
        lines = [(None, head)] + [(n, disp(n) + ("  (you)" if n == username else "")) for n in shown]
        if len(names) > len(shown):
            lines.append((None, f"+ {len(names) - len(shown)} more"))
        fill_rows(menu_rows, lines)
    state["refresh_menu_players"] = refresh_menu_players

    setting_labels = {}

    def adjust(key, delta, lo, hi, label, unit=""):
        cfg[key] = max(lo, min(hi, cfg[key] + delta))
        setting_labels[key].text = f"{label}: {cfg[key]}{unit}"
        if not menu["open"]:
            look_settings()
        else:
            camera.fov = cfg["fov"]
        try:   # remember it for next time (ignored when settings are locked)
            accounts.set_settings(username, {key: cfg[key]})
        except Exception:  # noqa: BLE001
            pass

    for i, (key, label, lo, hi, step, unit) in enumerate((("mouse_sens", "Mouse sensitivity", 10, 100, 5, ""),
                                                           ("fov", "Field of view", 60, 110, 5, " degrees"))):
        y = 0.15 - i * 0.12
        setting_labels[key] = Text(f"{label}: {cfg[key]}{unit}", parent=menu_pages["settings"], origin=(0, 0),
                                   position=(0, y + 0.045), scale=1.2, color=color.white)
        Button(text="-", parent=menu_pages["settings"], scale=(0.08, 0.06), position=(-0.2, y - 0.015), z=-0.1,
               on_click=lambda k=key, lb=label, l=lo, h=hi, s=step, u=unit: adjust(k, -s, l, h, lb, u),
               color=color.hex("#28284a"), highlight_color=color.hex("#463c82"))
        Button(text="+", parent=menu_pages["settings"], scale=(0.08, 0.06), position=(0.2, y - 0.015), z=-0.1,
               on_click=lambda k=key, lb=label, l=lo, h=hi, s=step, u=unit: adjust(k, s, l, h, lb, u),
               color=color.hex("#28284a"), highlight_color=color.hex("#463c82"))
    mbutton("settings", "Back", -0.31, lambda: menu_goto("main"))
    menu_btn.on_click = open_menu
    menu_goto("main")

    def layout():
        """Pin the HUD to the real window corners, whatever shape the window is."""
        tl, tr, bl = window.top_left, window.top_right, window.bottom_left
        state["aspect"] = window.aspect_ratio
        menu_btn.position = (tl.x + 0.02, tl.y - 0.02)
        title_text.position = (tl.x + 0.02, tl.y - 0.09)
        score_text.position = (tl.x + 0.02, tl.y - 0.145)
        hp_back.position = (tl.x + 0.02, tl.y - 0.195)
        hp_fill.position = (tl.x + 0.02, tl.y - 0.197)
        hp_text.position = (tl.x + 0.02 + 0.125, tl.y - 0.207)
        help_text.position = (bl.x + 0.02, bl.y + 0.02)
        chat_text.position = (bl.x + 0.02, bl.y + 0.13)
        chat_field.position = (bl.x + 0.02 + 0.35, bl.y + 0.075)
        fps_text.position = (tr.x - 0.02, tr.y - 0.02)
        top = tr.y - 0.02 - (0.05 if cfg["show_fps"] else 0)  # leave room for the FPS counter
        list_bg.position = (tr.x - 0.02, top)
        list_rows.position = (tr.x - 0.02 - state["list_w"] + 0.015, top - 0.015)

    ROW = 0.045   # height of one row in the player list

    def fill_rows(holder, lines, indent=0.04):
        """Rebuild a player list inside `holder`. lines: (name or None, text). A name with a badge gets its picture at
        the left of the row; the text of every named row is indented to leave room for it."""
        for ch in list(holder.children):
            destroy(ch)
        for i, (n, text) in enumerate(lines):
            Text(text, parent=holder, origin=(-0.5, 0.5), position=(indent if n else 0, -i * ROW), scale=1.1,
                 color=color.white)
            bk = badges.kind(n) if n else None
            if bk and badge_texture(bk):
                Entity(parent=holder, model="quad", texture=badge_texture(bk), scale=0.032,
                       position=(indent / 2 - 0.004, -i * ROW - 0.0215), z=-0.01)

    def visible_names():
        return [username] + sorted((r["user"] for r in remotes.values() if not r.get("hidden")), key=str.lower)

    def refresh_players():
        names = visible_names()
        shown = names[:14]
        head = f"Players ({len(names)}/{max_players})" if online else f"Players ({len(names)})"
        lines = [(None, head)] + [(n, disp(n) + ("  (you)" if n == username else "")) for n in shown]
        plain = [head] + ["    " + ("[DEV] " if n.lower() in dev_names else "") + n + ("  (you)" if n == username else "")
                          for n in shown]
        if len(names) > len(shown):
            lines.append((None, f"+ {len(names) - len(shown)} more"))
        fill_rows(list_rows, lines)
        state["list_w"] = max(0.3, 0.0125 * max(len(x) for x in plain) + 0.04)  # wide enough for long names
        list_bg.scale = (state["list_w"], 0.035 + 0.045 * len(lines))
        layout()
        if "refresh_menu_players" in state:
            state["refresh_menu_players"](names)

    def set_list_visible(v: bool):
        state["list_open"] = v
        list_bg.enabled = v
        list_rows.enabled = v

    def refresh_score():
        bits = []
        if total_coins:
            bits.append(f"Coins: {state['coins_taken']} / {total_coins}")
        if state["score_used"] or (state["score"] and not total_coins):
            bits.append(f"Score: {state['score']}")
        score_text.text = "   ".join(bits)

    def show(msg: str, secs: float = 2.0):
        msg_text.text = msg
        state["msg_until"] = state["t"] + secs

    def win(text):
        if not state["finished"]:
            state["finished"] = True
        show(text, 4.0)

    # ---------- scripts ----------
    class Adapter:
        """Lets the script engine reach the real game."""
        def log(self, text):
            emit(text)
            if text.startswith("ERROR") and not state.get("err_shown"):
                state["err_shown"] = True
                show("A script has an error (see the Output window)", 4.0)

        def say(self, text, secs): show(text, secs)
        def win(self, text): win(text)
        def get_score(self): return state["score"]

        def set_score(self, v):
            state["score"], state["score_used"] = v, True
            refresh_score()

        def player_name(self): return username
        def player_passes(self): return PASSES
        def player_pos(self): return (round(player.x, 3), round(player.y, 3), round(player.z, 3))
        def player_grounded(self): return player.grounded
        def get_player(self, key):
            if key in state["hp"]:
                return float(state["hp"][key])
            return float(getattr(player, key))

        def set_player(self, key, value):
            if key in state["hp"]:
                state["hp"][key] = value
                if key == "max_health":
                    state["hp"]["health"] = min(state["hp"]["health"], value)
                return
            setattr(player, key, value)

        def teleport(self, pos):
            player.position = Vec3(*pos)
            player.air_time = 0
            checkpoint.x, checkpoint.y, checkpoint.z = pos

        def part_changed(self, rec, field):
            w = world.get(rec["id"])
            if not w:
                return
            e = w["ent"]
            if field == "pos":
                e.position = tuple(rec["pos"])
            elif field == "size":
                e.scale = tuple(rec["size"])
            elif field == "rot":
                e.rotation_y = rec["rot_y"]
            elif field == "color":
                e.color = color.hex(rec["color"])
            elif field == "visible":
                e.visible = rec["visible"]
            elif field == "collide":
                apply_collider(w)

        def part_destroyed(self, rec):
            w = world.pop(rec["id"], None)
            if w:
                destroy(w["ent"])
            if rec in recs:
                recs.remove(rec)

        def part_created(self, rec):
            recs.append(rec)
            make_part(rec)

    host = scripting.ScriptHost(Adapter())
    problems = host.load(copy.deepcopy(gdef["scripts"]), recs)
    for line in problems:
        emit("ERROR " + line)
    if problems:
        show("Some scripts have errors (see the Output window)", 5.0)

    def touchable():
        return [rid for rid, w in world.items() if w["rec"]["kind"] == "goal" or host.has_touch(rid)]

    def touching(rec):
        px, py, pz = player.x, player.y, player.z
        hx, hy, hz = rec["size"][0] / 2, rec["size"][1] / 2, rec["size"][2] / 2
        r = math.radians(rec["rot_y"])
        c, s = abs(math.cos(r)), abs(math.sin(r))
        ex, ez, pad = c * hx + s * hz, s * hx + c * hz, 0.12
        x, y, z = rec["pos"]
        return (abs(px - x) <= ex + 0.4 + pad and abs(pz - z) <= ez + 0.4 + pad
                and y - hy - pad <= py + 1.8 and py <= y + hy + pad)

    if online:
        for info in client.welcome["players"]:
            add_remote(info)
    refresh_players()
    refresh_score()

    def finish():
        if client:
            client.close()
        for r in remotes.values():
            if not r.get("hidden"):
                r["label"].enabled = False
                if r.get("icon"):
                    r["icon"].enabled = False
        if not preview:
            accounts.record_play(username, game_id, state["score"])
        application.quit()

    if os.environ.get("NEXORA_TEST_MENU"):   # dev/test only: open the menu on this page at the start
        open_menu()
        menu_goto(os.environ["NEXORA_TEST_MENU"])
    test_shot = os.environ.get("NEXORA_TEST_SHOT")  # dev/test only: "path:frames" saves a screenshot and exits
    host.start()

    # ---------- per-frame ----------
    def update():
        dt = utime.dt
        state["t"] += dt
        state["frame"] += 1

        if cfg["show_fps"]:
            state["fps_t"] += dt
            state["fps_n"] += 1
            if state["fps_t"] >= 0.5:
                fps_text.text = f"{round(state['fps_n'] / state['fps_t'])} FPS"
                state["fps_t"], state["fps_n"] = 0.0, 0
        if abs(window.aspect_ratio - state["aspect"]) > 1e-3:
            layout()  # window was resized
        tc = os.environ.get("NEXORA_TEST_CHAT")  # dev/test only: "text:frame" sends a chat message through the UI path
        if tc and state["frame"] == int(tc.rsplit(":", 1)[1]):
            open_chat()
            chat_field.text = tc.rsplit(":", 1)[0]
            submit_chat()
        if os.environ.get("NEXORA_TEST_WALK"):
            held_keys["w"] = 1
        if test_shot:
            path, frames = test_shot.rsplit(":", 1)
            if state["frame"] == int(frames):
                app.screenshot(path, defaultFilename=False)
                finish()

        host.update(dt)

        if player.grounded:
            checkpoint.x, checkpoint.y, checkpoint.z = player.x, player.y + 0.5, player.z
        if player.y < gdef["kill_y"]:
            player.position = Vec3(*checkpoint)
            show("Oops! Back to the last platform")

        # health: slow regeneration, death, and the health bar (shown when hurt)
        hp = state["hp"]
        if 0 < hp["health"] < hp["max_health"] and hp["regen"] > 0:
            hp["health"] = min(hp["max_health"], hp["health"] + hp["regen"] * dt)
        if hp["health"] <= 0 and state["t"] > state["dead_until"]:
            state["dead_until"] = state["t"] + 1.0
            show("You died", 2.0)
            host.died()
            player.position = Vec3(sx, sy, sz)
            player.air_time = 0
            checkpoint.x, checkpoint.y, checkpoint.z = sx, sy, sz
            hp["health"] = hp["max_health"]
        hurt = hp["health"] < hp["max_health"] - 1e-6
        for e in (hp_back, hp_fill, hp_text):
            e.enabled = hurt
        if hurt:
            frac = max(0.0, min(1.0, hp["health"] / hp["max_health"]))
            hp_fill.scale_x = max(0.0001, 0.25 * frac)
            hp_fill.color = color.hsv(120 * frac, 0.8, 0.9)
            hp_text.text = f"{math.ceil(hp['health'])} / {math.ceil(hp['max_health'])}"

        moved = math.hypot(player.x - state["last"].x, player.z - state["last"].z)
        state["last"] = Vec3(player.x, player.y, player.z)
        walking = moved > 0.002 and player.grounded
        if walking:
            state["walk"] += dt * 10
        animate(my_legs, my_arms, math.sin(state["walk"]) * 40 if walking else 0)

        # network: send our state ~15x/s, apply everyone else's
        if client:
            state["send"] += dt
            if state["send"] >= 1 / 15:
                state["send"] = 0.0
                client.send_state((player.x, player.y, player.z), player.rotation_y, walking)
            for m in client.poll():
                t = m.get("t")
                if t == "joined":
                    add_remote(m["p"])
                    refresh_players()
                elif t == "left":
                    drop_remote(m["id"])
                    refresh_players()
                elif t == "states":
                    for key, v in m["s"].items():
                        r = remotes.get(int(key))
                        if r and not r.get("hidden"):
                            r["target"], r["rot"], r["walk"] = Vec3(v[0], v[1], v[2]), v[3], bool(v[4])
                elif t == "chat":
                    add_chat(str(m.get("user", "?"))[:20], network.clean_chat(m.get("m")))
                elif t == "closed" and not state["closing"]:
                    show("Disconnected from the server", 3)
                    state["closing"] = state["t"] + 3
            if state["closing"] and state["t"] > state["closing"]:
                finish()

        for r in remotes.values():
            if r.get("hidden"):
                continue
            k = min(1.0, dt * 12)
            root = r["root"]
            root.position += (r["target"] - root.position) * k
            diff = (r["rot"] - root.rotation_y + 180) % 360 - 180
            root.rotation_y += diff * k
            r["phase"] += dt * 10 if r["walk"] else 0
            animate(r["legs"], r["arms"], math.sin(r["phase"]) * 40 if r["walk"] else 0)
            r["label"].position = (root.x, root.y + 2.5, root.z)
            if r.get("icon"):
                r["icon"].position = (root.x, root.y + 2.95, root.z)

        # third-person camera: pull back, but stop in front of walls
        hit = raycast(pivot.world_position, pivot.back, distance=state["cam"], ignore=[player])
        camera.z = -(max(1.5, min(state["cam"], hit.distance - 0.4)) if hit.hit else state["cam"])

        # coins, goal pads and touch events
        state["touch_t"] += dt
        if state["touch_t"] > 0.25:
            state["touch_t"] = 0.0
            state["touchable"] = touchable()
        for rid in state["touchable"]:
            w = world.get(rid)
            if not w:
                continue
            rec = w["rec"]
            now = touching(rec) and rec.get("visible", True)
            if now and not w["inside"]:
                w["inside"] = True
                if rec["kind"] == "goal" and not state["finished"]:
                    win("You made it!")
                    state["score"] = max(state["score"], 1)
                    refresh_score()
                host.touch(rid)
            elif not now:
                w["inside"] = False

        for rid, w in list(world.items()):
            rec, ent = w["rec"], w["ent"]
            if rec["kind"] == "coin" and ent.enabled and rec.get("visible", True):
                ent.rotation_y += 120 * dt
                reach = 1.0 + max(rec["size"]) * 0.6
                if (ent.position - player.position - Vec3(0, 1, 0)).length() < reach:
                    ent.enabled = False
                    rec["visible"] = False
                    state["score"] += rec.get("value", 1)
                    state["coins_taken"] += 1
                    refresh_score()
                    if state["coins_taken"] >= total_coins and not state["finished"]:
                        win("All coins collected!")
            elif rec["kind"] == "goal" and ent.enabled:
                ent.rotation_y += 60 * dt

        if chat_lines and not state["typing"]:
            show_chat()
        if msg_text.text and state["t"] > state["msg_until"]:
            msg_text.text = ""

    def input(key):
        if state["typing"]:
            if key == "escape":
                close_chat()
            return
        if menu["open"] and key not in ("escape",):
            return
        if key == "enter" and state["t"] - state["chat_closed"] > 0.3:
            invoke(open_chat, delay=0.05)
        elif key == "escape":
            if not menu["open"]:
                open_menu()
            elif menu["page"] != "main":
                menu_goto("main")
            else:
                close_menu()
        elif key == "left alt" and not menu["open"]:   # a free cursor, to click the Menu button
            mouse.locked = False
            mouse.visible = True
        elif key == "left alt up" and not menu["open"]:
            mouse.locked = True
            mouse.visible = False
        elif key == "tab":
            set_list_visible(not state["list_open"])
        elif key == "scroll up":
            state["cam"] = max(3.0, state["cam"] - 1)
        elif key == "scroll down":
            state["cam"] = min(18.0, state["cam"] + 1)

    # Ursina calls update()/input() on every entity that defines them.
    controller = Entity()
    controller.update = update
    controller.input = input
    app.run()
