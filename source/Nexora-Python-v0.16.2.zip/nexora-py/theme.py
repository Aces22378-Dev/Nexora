"""Launcher colours. Other files read th.BG etc. at call time, so apply() takes effect on the next redraw."""

FONT = "Segoe UI"

THEMES = {
    "midnight": dict(BG="#0b0b14", PANEL="#14142a", PANEL2="#1c1c3a", LINE="#2a2a52", TEXT="#ecebff",
                     DIM="#9a98c8", ACCENT="#7c5cff", ON_ACCENT="#ffffff", CYAN="#22d3ee", DANGER="#ff5c7c"),
    "ocean": dict(BG="#071a24", PANEL="#0c2a3a", PANEL2="#133a50", LINE="#1f5573", TEXT="#e6f6ff",
                  DIM="#8fb8cc", ACCENT="#0ea5e9", ON_ACCENT="#021019", CYAN="#5eead4", DANGER="#ff6b81"),
    "sunset": dict(BG="#1a0c14", PANEL="#2a1220", PANEL2="#3a182b", LINE="#5a2a45", TEXT="#fff0f0",
                   DIM="#d0a0b0", ACCENT="#f97316", ON_ACCENT="#1a0a02", CYAN="#fbbf24", DANGER="#ff6b81"),
    "forest": dict(BG="#0a140e", PANEL="#12241a", PANEL2="#1a3324", LINE="#2a5238", TEXT="#eafbee",
                   DIM="#98c0a4", ACCENT="#22c55e", ON_ACCENT="#03130a", CYAN="#a3e635", DANGER="#ff6b81"),
    "light": dict(BG="#eef0f7", PANEL="#ffffff", PANEL2="#e1e5f2", LINE="#c3c9de", TEXT="#16192e",
                  DIM="#5b6180", ACCENT="#5b3df5", ON_ACCENT="#ffffff", CYAN="#0369a1", DANGER="#c81e4a"),
    "contrast": dict(BG="#000000", PANEL="#000000", PANEL2="#1a1a1a", LINE="#ffffff", TEXT="#ffffff",
                     DIM="#e0e0e0", ACCENT="#ffe600", ON_ACCENT="#000000", CYAN="#00e5ff", DANGER="#ff6b6b"),
}

TEXT_SCALE = {"small": 0.88, "normal": 1.0, "large": 1.2}

BG = PANEL = PANEL2 = LINE = TEXT = DIM = ACCENT = ON_ACCENT = CYAN = DANGER = ""
current = "midnight"


def apply(name: str) -> None:
    global current
    current = name if name in THEMES else "midnight"
    globals().update(THEMES[current])


apply("midnight")
